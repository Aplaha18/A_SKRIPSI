 <div class="row">
    <div class="col-lg-12">
      <div class="card" style="background: url('../front/img/bg-banner.jpg');">
        <div class="card-body app-heading" style="background-color: RGBA(12, 11, 11, 0.82);">
          <img class="profile-img" src="../assets/images/<?php echo $data['foto'] ?>">
          <div class="app-title">
            <div class="title"><span class="highlight"><?php echo $data['nama_dosen'] ?></span></div>
            <div class="description" style="color: #fff;">NIK. <?php echo $data['nip'] ?></div>
            <!-- Pemb2 -->
                <?php 
                $mhs = mysqli_query($con,"SELECT * FROM tb_pembtwo
                INNER JOIN tb_mhs ON tb_pembtwo.id_mhs=tb_mhs.id_mhs
                INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
                INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
                WHERE tb_pembtwo.id_dsn='$data[id_dsn]'") or die(mysqli_error($con)) ;
                $jum2 = mysqli_num_rows($mhs);
                  $mhs1 = mysqli_query($con,"SELECT * FROM tb_pembone
                  INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
                  INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
                  INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
                  WHERE tb_pembone.id_dsn='$data[id_dsn]'") or die(mysqli_error($con)) ;
                  $jum1 = mysqli_num_rows($mhs1);

                ?>
                <?php $total= $jum1+$jum2;?>
            <p><h4 style="color: #fff"> Mahasiswa Bimbingan <span class="badge badge-default"><b style="font-size: 23px;"><?php echo $total; ?></b></span> Orang
                                
           </h4> </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">

    <!-- Tabs -->
    <div class="col-sm-12 col-xs-12">
      <div class="card">
     <!--    <div class="card-header">
          Tab & Step
        </div> -->
        <div class="card-body">
            <div class="section-body">
              <div class="step">
    <ul class="nav nav-tabs nav-justified" role="tablist">
        <li role="step" class="active">
            <a href="#step2" role="tab" id="step2-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-home"></div>
                <div class="heading">
                    <div class="title"> Halaman Utama Dosen</div>
                    <div class="description">Informasi Utama</div>
                </div>
            </a>
        </li>
       <!--  <li role="step">
            <a href="#step3" role="tab" id="step3-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-users"></div>
                <div class="heading">
                    <div class="title">Mahasiswa Bimbingan</div>
                    <div class="description">Mahasiswa Bimbingan</div>
                </div>
            </a>
        </li>
        <li role="step">
            <a href="#step4" role="tab" id="step4-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-truck "></div>
                <div class="heading">
                    <div class="title">Purchase Successfully</div>
                    <div class="description">Wait for us shipping</div>
                </div>
            </a>
        </li> -->
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="step2">
            <!-- <b>Informasi Utama</b>: -->
            <!-- <hr> -->
            <div class="row">
              <div class="col-md-8">
                <!-- Informasi Untuk PA -->
                    <?php
                      $mhs = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul INNER JOIN tb_mhs ON tb_pengajuanjudul.id_mhs=tb_mhs.id_mhs WHERE tb_pengajuanjudul.id_dsn='$data[id_dsn]' AND status_proposal='Belum Dibaca' GROUP BY tb_pengajuanjudul.id_mhs DESC ");
                      while ($d= mysqli_fetch_array($mhs)) { ?>

                          <div class="alert alert-warning alert-dismissible fade in" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">x</span></button>
                            <img class="img-circle" src="../assets/img-mhs/<?php echo $d['fotomhs'] ?>" width="30" height="30"style="border-radius: 100%;"> <strong><?php echo $d['nama'] ?> </strong>! Ingin Mengusulkan Topik Skripsi!
                            <a href="?page=pengajuan&mhs=<?php echo $d['id_mhs']; ?>" class="btn btn-info btn-xs"><i class="fa fa-check"></i> Lihat</a>
                            <p>
                            
                            </p>
                            </div> 
                      <?php }
                       ?>
                       <!-- end PA -->

                    <!-- Infor Pembimbing 1 -->
                        <?php
                        $pem1 = mysqli_query($con,"SELECT * FROM tb_pembone
                        INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
                        WHERE  tb_pembone.ket_one='Belum Konfir' AND tb_pembone.id_dsn='$data[id_dsn]' ");
                        while ($p1= mysqli_fetch_array($pem1)) { ?>
                              <div class="alert alert-info alert-dismissible fade in" role="alert">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">x</span></button>

                            <b>Info! </b> Mohon Kesediaan Jadi Pembimbing ! 
                            <a href="?page=confirm&pemb=<?php echo $p1['id_pembone']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-check"></i>Konfirmasi !</a>
                              </div>

                        <?php } ?>

                    <!-- end pembimbing 1 -->

                    <!-- Infor Pembimbing 2 -->
                         <?php
                        $pem2 = mysqli_query($con,"SELECT * FROM tb_pembtwo
                        -- INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
                        INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
                        WHERE  tb_pembtwo.ket_two='Belum Konfir' AND tb_pembtwo.id_dsn='$data[id_dsn]' ");
                        while ($p2= mysqli_fetch_array($pem2)) { ?>
                              <div class="alert alert-info alert-dismissible fade in" role="alert">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">x</span></button>
                             <!--  <h4 id="oh-snap!-you-got-an-error!">  --><b>Info! </b> Mohon Kesediaan Jadi Pembimbing ! <a href="?page=confirm&act=two&pembtwo=<?php echo $p2['id_pembtwo']; ?>" class="btn btn-default btn-xs"><i class="fa fa-check"></i>Konfirmasi !</a><!--  <small><?php echo date('d F Y',strtotime($p2['tgl_penetapan_two'])); ?></small><a class="anchorjs-link" href="#oh-snap!-you-got-an-error!"><span class="anchorjs-icon"></span></a></h4> -->
                            <!--   <p>
                                <b>"<?php echo $p2['judul_proposal']; ?> " </b>
                              </p>
                              <p>
                              <a href="?page=confirm&act=two&pembtwo=<?php echo $p2['id_pembtwo']; ?>" class="btn btn-default btn-xs"><i class="fa fa-check"></i> Lihat & Konfirmasi !</a>
                              </p> -->
                              </div>

                        <?php } ?>
                    
                    <!-- end pembimbing 2 -->

              </div> 
              <div class="col-md-4">

                 <!-- Informasi Bimbingan 1 --> 
                    <?php
                    $query_daftar_pesan = mysqli_query($con,"SELECT * FROM tb_pesanpembone
                    INNER JOIN tb_pembone ON tb_pesanpembone.id_pembone=tb_pembone.id_pembone
                    INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs 
                    WHERE tb_pesanpembone.id_penerima='$data[id_dsn]'
                    AND tb_pesanpembone.status_pesan='belum'
                    ORDER BY id_pesan DESC ");
                    while ($pesan=mysqli_fetch_array($query_daftar_pesan)) { ?>

                    <a href="?page=bimbingan1&act=riwayat2&id_mhs=<?php echo $pesan['id_mhs'] ?>">
                      <div class="alert alert-warning alert-dismissible" role="alert">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     
                      <img class="img-circle" src="../assets/img-mhs/<?php echo $pesan['fotomhs'] ?>" width="35" height="35" style="border-radius: 100%;">
                       <strong><?php echo $pesan['nama'] ?>!</strong> <i class="fa fa-envelope-o"></i> Mengirim Pesan
                      </div>
                    </a>
                    <?php 
                    } 
                    ?>
                    <!-- Informasi pesan sebagai pembimbing 2 -->
                     <?php
                    $daftar_pesan = mysqli_query($con,"SELECT * FROM tb_pesan
                    INNER JOIN tb_pembtwo ON tb_pesan.id_pembtwo=tb_pembtwo.id_pembtwo
                    INNER JOIN tb_mhs ON tb_pembtwo.id_mhs=tb_mhs.id_mhs 
                    WHERE tb_pesan.id_penerima='$data[id_dsn]'
                    AND tb_pesan.status_pesan='belum'
                    ORDER BY id_pesan DESC ");
                    while ($pesan2=mysqli_fetch_array($daftar_pesan)) { ?>

                    <a href="?page=bimbingan&act=riwayat2&id_mhs=<?php echo $pesan2['id_mhs'] ?>">
                      <div class="alert alert-success alert-dismissible" role="alert">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     
                      <img class="img-circle" src="../assets/img-mhs/<?php echo $pesan2['fotomhs'] ?>" width="35" height="35" style="border-radius: 100%;">
                       <strong><?php echo $pesan2['nama'] ?>!</strong> <i class="fa fa-envelope-o"></i> Mengirim Pesan
                      </div>
                    </a>
                    <?php 
                    } 
                    ?>





              </div>              
            </div>

        </div>
        <div role="tabpanel" class="tab-pane" id="step3">
            <b>Step3</b> : Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum
        </div>
        <div role="tabpanel" class="tab-pane" id="step4">
            <b>Step4</b> : Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequa
        </div>
    </div>
</div>
            </div>
          </div>
        </div>
      </div>

    <!-- end tabs -->

  </div>

    