<div class="row">
	<div class="col-md-12">
		<h3><i class="fa fa-cog"></i> Buat Prosedur Bimbingan</h3>


<form action="" method="POST" accept-charset="utf-8">
	<div class="form-group">
		<!-- <label>Form Peraturan</label> -->
		<input type="hidden" name="id_dsn" value="<?php echo $data['id_dsn']; ?>">
		<textarea id="ckedtor1" name="isi"><h2><span style="font-family:Comic Sans MS,cursive"><span style="color:#E91E63"><strong>Tuliskan sesuatu disini ....</strong></span></span></h2></textarea>
	</div>
	<br>
	<div class="form-group">
		<center>
			<button type="submit" name="set" class="btn btn-primary"> <i class="fa fa-save"></i> Simpan</button>
		<a href="javascript:history.back()" class="btn btn-danger"> <i class="fa fa-chevron-left"></i> Batal</a>
		</center>
	</div>
</form>	
				<?php 
				if (isset($_POST['set'])) {
					$id_dsn = $_POST['id_dsn'];
					$isi = $_POST['isi'];
					$tgl = date('Y-m-d');
					mysqli_query($con,"INSERT INTO tb_peraturan VALUES(NULL,'$id_dsn','$isi','$tgl') ") or die(mysqli_error($con)) ;
					?>
					<script type='text/javascript'>
						setTimeout(function () {
						swal({
						title: 'SUKSES Prosedur Bimbingan',
						text:  'Berhasil Membuat Prosedur Bimbingan !',
						type: 'success',
						timer: 3000,
						showConfirmButton: true
						});     
						},10);  
						window.setTimeout(function(){ 
						window.location.replace('?page=set');
						} ,3000);   
						</script>
					<?php
				}


				 ?>						
	</div>	
</div>