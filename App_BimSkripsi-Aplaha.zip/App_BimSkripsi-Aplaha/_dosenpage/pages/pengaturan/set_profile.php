<div class="row">
	<div class="col-lg-4 col-md-4 col-md-12 col-xs-12 col-lg-offset-3">
		<div class="card">
			<div class="card-body">				
				<form action="" method="POST" enctype="multipart/form-data">
					<center>
					<img src="../assets/images/<?php echo $data['foto'] ?>" class="img-thumbnail" width="90" height="90">
				</center>
				
				<div class="form-group">
					<label>NIK</label>
					<input type="text" name="nip" class="form-control" value="<?php echo $data['nip'] ?>" disabled>	
					<input type="hidden" name="id" class="form-control" value="<?php echo $data['id_dsn'] ?>">				
				</div>
				<div class="form-group">
					<label>Nama Lengkap</label>
					<input type="text" name="nama" class="form-control" value="<?php echo $data['nama_dosen'] ?>">				
				</div>
				<div class="form-group">
					<label>Jabatan</label>
					<input type="text" name="jabatan" class="form-control" value="<?php echo $data['jabatan'] ?>">				
				</div>
				<div class="form-group">
					<label>Username</label>
					<input type="text" name="username" class="form-control" value="<?php echo $data['username'] ?>">				
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="text" name="password" class="form-control" value="<?php echo $data['secondpass'] ?>">				
				</div>
				<div class="form-group">
					<label>Foto Profile</label>
					<input type="file" name="foto" class="form-control">				
				</div>
				<div class="form-group">
					<button type="submit" name="set" class="btn btn-primary"><i class="fa fa-pencil"></i> Update</button>
					<a href="javascript:history.back()" class="btn btn-danger"><i class="fa fa-times"></i> Batal</a>				
				</div>
				</form>	
				<?php
				if (isset($_POST['set'])) {
				$id = $_POST['id'];
				$nama = $_POST['nama'];
				$jabatan = $_POST['jabatan'];
				$username = $_POST['username'];
				$password = md5($_POST['password']);
				$second = $_POST['password'];

				$gambar = @$_FILES['foto']['name'];
				if (!empty($gambar)) {
				move_uploaded_file($_FILES['foto']['tmp_name'],"../assets/images/$gambar");
				$ganti = mysqli_query($con,"UPDATE tb_dsn SET foto='$gambar' WHERE id_dsn='$id' ");
				}
				mysqli_query($con,"UPDATE tb_dsn SET nama_dosen='$nama',jabatan='$jabatan',username='$username',password='$password',secondpass='$second' WHERE id_dsn='$id' ") or die (mysqli_error($con));
				?>
				<script type='text/javascript'>
				setTimeout(function () {
				swal({
				title: 'DATA DIUBAH',
				text:  'Berhasil Mengubah Data !',
				type: 'success',
				timer: 3000,
				showConfirmButton: true
				});     
				},10);  
				window.setTimeout(function(){ 
				window.location.replace('index.php');
				} ,3000);   
				</script>
				<?php
				}
				  ?>							
			</div>						
		</div>			
	</div>	
</div>