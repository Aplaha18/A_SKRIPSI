<div class="row">
	<div class="col-md-12">
		<h3><i class="fa fa-cog"></i> Buat Prosedur Bimbingan</h3>
<?php 
$id = $_GET['id'];
$sql=mysqli_query($con,"SELECT * FROM tb_peraturan WHERE id_peraturan='$id' ");
$data1 = mysqli_fetch_array($sql);
 ?>

<form action="" method="POST" accept-charset="utf-8">
	<div class="form-group">
		<!-- <label>Form Peraturan</label> -->
		<input type="hidden" name="id_dsn" value="<?php echo $data['id_dsn']; ?>">
		<input type="hidden" name="idp" value="<?php echo $data1['id_peraturan']; ?>">
		<textarea id="ckedtor1" name="isi"><?php echo $data1['isi_peraturan'] ?></textarea>
	</div>
	<br>
	<div class="form-group">
		<center>
			<button type="submit" name="set" class="btn btn-primary"> <i class="fa fa-save"></i> Simpan</button>
		<a href="javascript:history.back()" class="btn btn-danger"> <i class="fa fa-chevron-left"></i> Batal</a>
		</center>
	</div>
</form>	
				<?php 
				if (isset($_POST['set'])) {
					$idp = $_POST['idp'];
					$id_dsn = $_POST['id_dsn'];
					$isi = $_POST['isi'];
					$tgl = date('Y-m-d');
					mysqli_query($con,"UPDATE tb_peraturan SET isi_peraturan='$isi' WHERE id_peraturan='$idp' ") or die(mysqli_error($con)) ;
					?>
					<script type='text/javascript'>
						setTimeout(function () {
						swal({
						title: 'SUKSES',
						text:  'Berhasil Membuat Prosedur Bimbingan !',
						type: 'success',
						timer: 3000,
						showConfirmButton: true
						});     
						},10);  
						window.setTimeout(function(){ 
						window.location.replace('?page=set');
						} ,3000);   
						</script>
					<?php
				}


				 ?>						
	</div>	
</div>