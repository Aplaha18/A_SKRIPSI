<?php 
$id = $_GET['id'];
$sql=mysqli_query($con,"DELETE FROM tb_peraturan WHERE id_peraturan='$id' ");
if ($sql) {
		?>
		<script type='text/javascript'>
			setTimeout(function () {
			swal({
			title: 'TERHAPUS',
			text:  'Data Terhapus!',
			type: 'success',
			timer: 3000,
			showConfirmButton: true
			});     
			},10);  
			window.setTimeout(function(){ 
			window.location.replace('?page=set');
			} ,3000);   
		</script>
		<?php
}
 ?>