<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<h3><i class="fa fa-cog"></i> Prosedur Bimbingan</h3>
				<!-- <a href="" class="btn btn-default pull-right"> <i class="fa fa-plus"></i> Tambah</a> -->
			</div>
			<div class="card-body">
				<table class="datatable table table-condensed table-hover">
					<thead>
						<tr>
							<th>No.</th>
							<th>Tanggal Setting</th>
							<th>Prosedur</th>
							<th align="center">
								<a href="?page=set&act=addprosedur" class="btn btn-primary btn-block"> <i class="fa fa-plus"></i> Tambah</a>
							</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$no=1;
						$set = mysqli_query($con,"SELECT * FROM tb_peraturan WHERE id_dsn='$data[id_dsn]' ORDER BY id_peraturan DESC");
						foreach ($set as $data) { ?>
						<tr>
							<td><?php echo $no++; ?></td>
							<td><?php echo date('d F Y',strtotime($data['tgl_set'])); ?></td>
							<td><?php echo $data['isi_peraturan']; ?></td>
							<td align="center">
								<a href="?page=set&act=edit&id=<?php echo $data['id_peraturan']; ?>" class="btn btn-info"> <i class="fa fa-search"></i> Lihat & Ubah</a>
								<a href="?page=set&act=del&id=<?php echo $data['id_peraturan']; ?>" class="btn btn-danger" onclick="return confirm('Yakin Akan Hapus Data !')" > <i class="fa fa-trash"></i></a>
							</td>
						</tr>
					<?php } ?>

					</tbody>
				</table>

						
			</div>			
		</div>
	</div>	
</div>
