<?php 
$id_mhs = $_GET['id_mhs'];
$riwayat2 = mysqli_query($con,"SELECT * FROM 
tb_pembone
INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
WHERE tb_pembone.id_mhs='$id_mhs'");
$mhs = mysqli_fetch_array($riwayat2);
 ?> 
<div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body app-heading">
            <?php
            if (empty($mhs['fotomhs'])) {
            }else{
            ?>
            <img class="profile-img" src="../assets/img-mhs/<?php echo $mhs['fotomhs'] ?>">
            <?php
            }
            ?>
          <div class="app-title">
            <div class="title">
              <small>Mahasiswa</small> <br><span class="highlight"><?php echo $mhs['nama'] ?></span> | <small>"<?php echo $mhs['judul_proposal'] ?>"</small></div>
            <div class="description">NIM.<?php echo $mhs['nim'] ?></div>
            <b>Anda : Pembimbing I</b>
          </div>
        </div>

      </div>
    </div>    
  </div>

 <div class="row">
  <div class="col-md-4">
    <div class="card"style="overflow:scroll;height:700px;">
        <div class="card-body">
          <p>
            <h4>
              <b><i class="fa fa-history"></i></b> Riwayat Bimbingan
            </h4>
          </p>

        <p></p>

  <!-- Modal kirim pesan -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Kepada  <br>
            <?php
            if (empty($mhs['fotomhs'])) {
            }else{
            ?>
            <img class="profile-img" src="../assets/img-mhs/<?php echo $mhs['fotomhs'] ?>" width="50" height="50" style="border-radius: 100%;border:1px;">
            Mahasiswa <em><strong><?php echo $mhs['nama']; ?></strong></em>
           
            <?php
            }
            ?> 
          </h4>
          </div>
        <form action="" method="POST">
          <div class="modal-body"> 
              <!-- id tersembunyi -->
              <input type="hidden" name="id_mhs" value="<?php echo $id_mhs; ?>"> 
              <input type="hidden" name="id_dsn" value="<?php echo $data['id_dsn']; ?>">
              <input type="hidden" name="id_pembone" value="<?php echo $mhs['id_pembone']; ?>">
              <!-- End id tersembunyi -->

              <input type="text" name="subyek" class="form-control" placeholder="Masukkan Subyek Pesan ...">
              <textarea name="isi_pesan" cols="30" rows="5" class="form-control" placeholder="Ketikkan Isi Pesan disini .."></textarea>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"> <i class="fa fa-times"></i> Batal</button>
            <button type="submit" name="kirim_pesan" class="btn btn-sm btn-success"><i class="fa fa-envelope-o"></i> Kirim Pesan</button>
          </div>
        </form>
              <?php 
              if (isset($_POST['kirim_pesan'])) {
                $id_pengirim= $_POST['id_dsn'];
                $id_penerima= $_POST['id_mhs'];
                $subyek= $_POST['subyek']; 
                $isi_pesan= $_POST['isi_pesan'];
                $tanggal= date('Y-m-d'); 
                $id_pembone= $_POST['id_pembone'];

                $isi = mysqli_query($con, "INSERT INTO tb_pesan VALUES(NULL,'$id_penerima','$id_pengirim','$subyek','$isi_pesan','$tanggal', 'belum','$id_pembone')");
                if ($isi) {
                echo "<b class='text-danger'><h4>Pesan Sukses Terkirim Kepada $mhs[nama_dosen]</h4> </b>";
                }

              }

              ?>
        </div>
      </div>
    </div>





          
          <?php
          $query_daftar_pesan = mysqli_query($con,"SELECT * FROM tb_pesanpembone WHERE id_pengirim='$id_mhs' AND id_penerima='$data[id_dsn]'
              ORDER BY id_pesan DESC
              ");
          while ($daftar_pesan=mysqli_fetch_array($query_daftar_pesan)) {
            if($daftar_pesan['status_pesan']=="belum"){
        ?>
        <!-- Tampilkan pesan yg belum dibuka -->
            <div class="list-group">
            <p><i class="fa fa-envelope-o"></i> Pesan Baru</p>
            <a href="?page=bimbingan1&act=bukapesan&id_mhs=<?php echo $id_mhs; ?>&id_pesan=<?php echo $daftar_pesan['id_pesan']; ?>" class="list-group-item" style="background-color:#CDDC39;">

            <img class="profile-img" src="../assets/img-mhs/<?php echo $mhs['fotomhs'] ?>" width="40" height="40" style="border-radius: 100%; border:1px solid #fff;">
            <?php echo $mhs['nama']; ?> - <em>Belum Dibaca</em> : "<b><?php echo $daftar_pesan['subyek']; ?></b>" - Dikirim <em><?php echo date('d F Y', strtotime( $daftar_pesan['tgl_pesan'])); ?></em>
            </a>
            </div>  


        <?php } 
            else if($daftar_pesan['status_pesan']=="sudah"){
        ?>
             <div class="list-group">
            <!-- <i class="fa fa-envelope-o" style="font-size: 20px;"></i> Pesan Baru -->
            <a href="?page=bimbingan1&act=bukapesan&id_mhs=<?php echo $id_mhs; ?>&id_pesan=<?php echo $daftar_pesan['id_pesan']; ?>" class="list-group-item" style="border: 0px double #3E2723;border-radius: 20px;font-family: consolas;background-color:#F5F5F5;">

            <img class="profile-img" src="../assets/img-mhs/<?php echo $mhs['fotomhs'] ?>" width="40" height="40" style="border-radius: 100%; border:1px solid #fff;">
            <?php echo $mhs['nama']; ?>  <p>  "<b><code><?php echo $daftar_pesan['subyek']; ?></code></b>" 
           - Dikirim <em><?php echo date('d F Y', strtotime( $daftar_pesan['tgl_pesan'])); ?></em></p>
            </a>
            </div>  



        <?php 
            } 
          }
        ?>
      </div>
    </div>
     </div> 
     <div class="col-md-8">
<a href="javascript:history.back()" class="btn btn-warning"><i class="fa fa-chevron-left"></i> Kembali</a>


<a onclick="return confirm('Yakin Akan Akhiri Bimbimbingan ?')" href="?page=bimbingan1&act=stop&ID=<?=$_GET[id_mhs];?>"  class="btn btn-primary"><i class="fa fa-stop"></i> Akhiri Bimbingan</a>
<p>
            <?php 
if ($mhs['status_skripsi']=='SELESAI') {
// echo "<span class='btn btn-success'>Telah selesai</span>";
echo '<div class="alert alert-success alert-dismissible" role="alert">
STATUS SKRIPSI TELAH <strong>SELESAI</strong>
</div>';
}else{
echo '<div class="alert alert-danger alert-dismissible" role="alert">
STATUS SKRIPSI <strong>BELUM SELESAI/SEDANG BERLANSUNG</strong>
</div>';
}

?>
</p>

        <div class="card" style="overflow:scroll;height:500px;">

              <div class="card-body">
                 Riwayat Konsultasi

                 <hr>

                 <div class="table-responsive">                 
                <table class="table table-striped">
                <thead>
                    <tr style="background-color:#212121;color: #E91E63;">
                        <th>No.</th>
                        <th>Tanggal</th>
                        <th>Pembahasan</th>
                       <!--  <th>Catatan</th>
                        <th>Keterangan</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no= 1;
                     $mhs = mysqli_query($con,"SELECT * FROM tb_pesanpembone WHERE id_pembone='$mhs[id_pembone]' ") or die(mysqli_error($con)) ;
                        while ($data= mysqli_fetch_array($mhs)) { ?>
                    <tr>
                        <td><?php echo $no++; ?>.</td>
                        <th><?php echo $data['tgl_pesan']; ?></th>
                        <td><?php echo $data['subyek']; ?>
                          <br> <code><?php echo $data['isi_pesan']; ?></code>
                        </td>
                      <!--   <td><?php echo $data['isi_pesan']; ?></td>
                        <td><?php echo $data['status_pesan']; ?></td> -->
                        
                    </tr>
                <?php } ?>

                </tbody>
            </table>

            </div>


              </div>
        </div>
      </div>  
 </div>

