<?php 
$id_mhs = $_GET['id_mhs'];
$riwayat2 = mysqli_query($con,"SELECT * FROM 
tb_pembone
INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan

WHERE tb_pembone.id_mhs='$id_mhs'");
$mhs = mysqli_fetch_array($riwayat2);
?> 

<?php
$id_mhs=$_GET['id_mhs'];
$id_pesan = $_GET['id_pesan'];
$query_buka_pesan = mysqli_query($con, "SELECT * FROM tb_pesanpembone
INNER JOIN tb_fileskripsi ON tb_pesanpembone.id_file=tb_fileskripsi.id_file
WHERE tb_pesanpembone.id_pesan='$id_pesan' AND tb_pesanpembone.id_pengirim='$id_mhs' ");
$buka=mysqli_fetch_array($query_buka_pesan);
?>
<?php $sudah_dibaca = mysqli_query($con, "UPDATE tb_pesanpembone SET status_pesan='sudah' WHERE id_pesan=$id_pesan"); ?>

<div class="row">
	<div class="col-md-12">
		<div class="card">
	        <div class="card-body">	
	    <!-- <h4><b> <i class="fa fa-envelope-o" style="font-size: 25px;"></i> Buka Pesan</b> </h4>      	   -->
			<div class="row">
				<div class="col-md-6">
					<div class="list-group">
			<span class="list-group-item" style="background-color:#8BC34A;color: #fff;">
				<h4 class="list-group-item-heading">
				<?php
				if (empty($mhs['fotomhs'])) {
				}else{
				?>
				<img class="profile-img" src="../assets/img-mhs/<?php echo $mhs['fotomhs'] ?>" width="50" height="50" style="border-radius: 100%;border:1px;">
				Mahasiswa
				<em><strong><?php echo $mhs['nama']; ?></strong></em>

				<?php
				}
				?></h4>
			<p class="list-group-item-text">
			.<em class="pull-right">Dikirim <?php echo date('d F Y',strtotime($buka['tgl_pesan'])); ?></em>
			</p>
			</span>
				<span class="list-group-item">
					<h4 class="list-group-item-heading">
					Pembahasan: <strong><?php echo $buka['subyek']; ?></strong>
					</h4>
				<i class="fa fa-envelope"></i> Pesan
					<h4>
					<!--  style="border: 1px solid;padding: 7px;border-radius: 7px;background-color: #FAFAFA;" -->
					<p class="list-group-item-text">

					<code style="color: black;"><?php echo $buka['isi_pesan']; ?></code>
					</p>
					</h4>
				</span>
		</div>

		<!-- balas pesan -->
<form action="" method="POST" enctype="multipart/form-data">
		<!-- id tersembunyi -->
		<input type="hidden" name="id_mhs" value="<?php echo $id_mhs; ?>"> 
		<input type="hidden" name="id_dsn" value="<?php echo $data['id_dsn']; ?>">
		<input type="hidden" name="id_pembone" value="<?php echo $mhs['id_pembone']; ?>">
		<input type="hidden" name="id_file" value="<?php echo $buka['id_file']; ?>">
		<input type="hidden" name="id_pesan" value="<?php echo $id_pesan; ?>">

		<!-- End id tersembunyi -->
		<div class="list-group">
		<span href="#" class="list-group-item" style="background-color:#E91E63;">
			<h4 class="list-group-item-heading" style="color: #fff;">

			<img class="profile-img" src="../assets/images/<?php echo $data['foto'] ?>" width="50" height="50" style="border-radius: 100%;border:1px;"> Anda <em><b><?php echo $data['nama_dosen'] ?></b> </em> 
			</h4>
				<p class="list-group-item-text">
					.
					<em class="pull-right" style="color: #fff;">[ <?php echo date('d F Y') ?> ] </em>
				</p>
		</span>
		<span class="list-group-item">
		<h4 class="list-group-item-heading">
		<em>Balas Pesan</em>
		</h4>
		<p class="list-group-item-text">
		<input type="text" name="subyek" class="form-control" placeholder="Masukkan Subyek Pesan ...">
		<textarea name="isi_pesan" cols="30" rows="5" class="form-control" placeholder="Ketikkan Isi Pesan disini .."></textarea>

		<!-- <p class="text-danger"> Lampiran Wajib Diisi *</p> -->
		<input type="file" name="fileone" class="form-control">
		
				<?php 
								//fungsi untuk mengkonversi size file
function formatBytes($bytes, $precision = 2) { 
$units = array('B', 'KB', 'MB', 'GB', 'TB');
$bytes = max($bytes, 0); 
$pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
$pow = min($pow, count($units) - 1);
$bytes /= pow(1024, $pow);
return round($bytes, $precision) . ' ' . $units[$pow]; 
} 


				if (isset($_POST['balas_pesan'])) {
						// untuk file
					$allowed_ext  = array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'rar', 'zip');
					$file_name    = $_FILES['fileone']['name'];
					@$file_ext     = strtolower(end(explode('.',$file_name)));
					$file_size    = $_FILES['fileone']['size'];
					$file_tmp     = $_FILES['fileone']['tmp_name'];

					$id_pengirim= $_POST['id_dsn'];
					$id_penerima= $_POST['id_mhs'];
					$subyek= $_POST['subyek']; 
					$isi_pesan= $_POST['isi_pesan'];
					$tanggal= date('Y-m-d'); 
					$id_pembone= $_POST['id_pembone'];
					$id_file= $_POST['id_file'];
					$id_pesan= $_POST['id_pesan'];

		if(in_array($file_ext, $allowed_ext) === true){
		if($file_size < 3044070){
		$lokasi = '../assets/file_pembone/'.$id_pesan.'.'.$file_ext;
		move_uploaded_file($file_tmp, $lokasi);

			$pesan = mysqli_query($con, "INSERT INTO tb_pesanpembone VALUES(NULL,'$id_penerima','$id_pengirim','$subyek','$isi_pesan','$tanggal', 'belum','$id_pembone','$id_file')");


		if($pesan){
			$pesanTerakhir = mysqli_query($con,"SELECT id_pesan FROM tb_pesanpembone ORDER BY id_pesan DESC LIMIT 1 ");
			$id = mysqli_fetch_array($pesanTerakhir);
			$idPesan = $id['id_pesan'];
			$file= mysqli_query($con,"INSERT INTO tb_fileone VALUES(NULL,'$idPesan','$tanggal', '$file_name','$file_ext', '$file_size', '$lokasi')");	
			if ($file) {
						?>
					<div class="alert alert-success alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong>PESAN TERKIRIM!</strong> Pesan Sukses Terkirim Kepada <?php echo $mhs[nama] ?>
					</div>
					<?php

			}
		}else{
		echo '<div class="error">ERROR: Gagal upload file!</div>';
		}
		}else{
		echo '<div class="error">ERROR: Besar ukuran file (file size) maksimal 1 Mb!</div>';
		}
		}else{
		echo '<div class="error">ERROR: Ekstensi file tidak di izinkan!</div>';
		$tanpaFile = mysqli_query($con, "INSERT INTO tb_pesanpembone VALUES('null','$id_penerima','$id_pengirim','$subyek','$isi_pesan','$tanggal', 'belum','$id_pembone','0')");
		if ($tanpaFile) {
				?>
				<div class="alert alert-success alert-dismissible" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<strong>PESAN TERKIRIM!</strong> Pesan Sukses Terkirim Kepada <?php echo $mhs[nama] ?>
				</div>
				<?php
		}
		}
		}





				?>
				<input type="submit" name="balas_pesan" value="KIRIM PESAN" class="btn btn-primary">
		 <a href="javascript:history.back()" class="btn btn-danger"><i class="fa fa-chevron-left"></i> Batal</a>
				
			
		</p>
		</span>
		

		
		</div>
		<!-- <a id="ke_balas_pesan" href="#" class="btn btn-primary btn-block">Balas Pesan</a> -->

	</form>
									
				</div>	
				<div class="col-md-6">

				<div class="thumbnail">
		
					<div class="caption">
					<h3 class="title">Bab Pembahasan<a class="anchorjs-link" href="#thumbnail-label"><span class="anchorjs-icon"></span></a></h3>
					<?php
					if ($buka['tipe_file']=='pdf') {
						// tipe PDF
						?>
						<p class="description"> 
							<embed src="<?php echo $buka['file']; ?>" width="100%" height="600"> </embed>
						</p>
						<a href="<?php echo $buka['file']; ?>" class="btn btn-success btn-xs" role="button" target="_blank"><i class="fa fa-download"></i> Unduh File <?php echo $buka['nama_file']; ?></a>
						<?php
						
					}else{
						// Tipe laninya
						?>
						<p class="description"> 
							<a href="<?php echo $buka['file']; ?>" class="btn btn-default" style="font-size: 200px;" target="_blank"> <i class="fa fa-file-word-o text-primary"></i> </a>
						</p>
						<a href="<?php echo $buka['file']; ?>" class="btn btn-success btn-xs" role="button" target="_blank"><i class="fa fa-download"></i> Unduh File <?php echo $buka['nama_file']; ?></a>
						<?php
					}


					 ?>
					</div>
					</div> 

				</div>			
			</div>

		
	


		</div>
		
		</div>
		</div>	
	</div>
	</div>







	


