<?php 
$update= mysqli_query($con,"UPDATE tb_mhs SET status_skripsi='SELESAI' WHERE id_mhs='$_GET[ID]' ");

if ($update) {
	echo "
<script type='text/javascript'>
	setTimeout(function () {
	swal({
	title: 'SUKSES',
	text:  'BIMBINGAN TELAH SELESAI',
	type: 'success',
	timer: 3000,
	showConfirmButton: true
	});     
	},10);  
	window.setTimeout(function(){ 
	window.location.replace('?page=bimbingan1&act=riwayat2&id_mhs=$_GET[ID]');
	} ,3000);   
</script>
";	
}


 ?>