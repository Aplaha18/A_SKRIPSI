
<div class="row">
<div class="col-xs-12">
      <div class="card">
        <div class="card-header"style="background-color: RGBA(12, 11, 11, 0.82);color: #fff;">
          MAHASISWA BIMBINGAN II
        </div>
        <div class="card-body no-padding">
            <table class="datatable table table-striped primary" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Photo</th>
                        <th>Nim</th>
                        <th>Nama Mahasiswa</th>
                        <th>Judul Skripsi</th>
                     
                        <th>Riwayat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no= 1;
                     $mhs = mysqli_query($con,"SELECT * FROM tb_pembtwo
                        INNER JOIN tb_mhs ON tb_pembtwo.id_mhs=tb_mhs.id_mhs
                        INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
                        INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
                        WHERE tb_pembtwo.id_dsn='$data[id_dsn]'") or die(mysqli_error($con)) ;
                        while ($data= mysqli_fetch_array($mhs)) { ?>
                    <tr>
                        <td><?php echo $no++; ?>.</td>
                        <th>
                            <img src="../assets/img-mhs/<?php echo $data['fotomhs']; ?>" width="40" height="40" class="img-thumbnail">
                        </th>
                        <td><?php echo $data['nim']; ?></td>
                        <td><?php echo $data['nama']; ?></td>
                        <td><?php echo $data['judul_proposal']; ?></td>
                  
                        <td>
                            <a href="?page=bimbingan&act=riwayat2&id_mhs=<?php echo $data['id_mhs'];?> " class="btn btn-danger"> <i class="fa fa-history"></i> Riwayat Bimbingan</a>
                        </td>
                    </tr>
                <?php } ?>

                </tbody>
            </table>
        </div>
      </div>
    </div>
</div>

