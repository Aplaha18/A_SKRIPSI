<?php 
$mhs= $_GET['mhs'];
$qry = mysqli_query($con,"SELECT * FROM tb_mhs WHERE id_mhs='$mhs' ");
$row = mysqli_fetch_array($qry);
 ?>
<div class="row">
<div class="col-sm-12 col-xs-12">

      <div class="card">
        <div class="card-header">
          <div class="col-md-6">
             <a href="javascript:history.back()" class="btn btn-danger btn-xs"> <i class="fa fa-chevron-left"></i> Kembali </a>
            <table class="table" style="font-weight: bold;color:black;">
              <tr>
                <td rowspan="4">
                  <img class="img-thumbnail" src="../assets/img-mhs/<?php echo $row['fotomhs'] ?>" width="100" height="130" style="border-radius: 7px;border: 2px solid #FAFAFA;">
                </td>
              </tr>
               <tr>
                <td>Nama Mahasiswa</td>
                <td>:</td>
                <td><?php echo $row['nama'] ?></td>
              </tr>
              <tr>
                <td>NIM</td>
                <td>:</td>
                <td><?php echo $row['nim'] ?></td>
              </tr>
              <tr>
                <td>Tahun Angkatan</td>
                <td>:</td>
                <td><?php echo $row['tahun_angkatan'] ?></td>
              </tr>
          </table>            
          </div>
        </div>
        <div class="card-body">
            <div class="section-body">
              <div class="step">
    <ul class="nav nav-tabs nav-justified" role="tablist">
     <!--    <li role="step">
            <a href="#step1" id="step1-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">
                <div class="icon fa fa-file-o"></div>
                <div class="heading">
                    <div class="title">Shipping</div>
                    <div class="description">Enter your address</div>
                </div>
            </a>
        </li> -->
        <li role="step" class="active">
            <a href="#step2" role="tab" id="step2-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-file-o"></div>
                <div class="heading">
                    <div class="title">Daftar Judul Yang Diajukan</div>
                    <div class="description">Daftar Judul Yang Diajukan</div>
                </div>
            </a>
        </li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
     
        <div role="tabpanel" class="tab-pane active" id="step2">
         <!--    <b>Step2</b>
            <hr> -->
               <table class="table table-condensed table-striped">
                      <thead>
                        <tr>
                          <th>No.</th>
                          <th>Tanggal Pengajuan</th>
                          <th>Judul Proposal</th>
                          <th>Status Proposal</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $no=1; 
                        $query= mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$mhs' ");
                        while ($row= mysqli_fetch_array($query)) { ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo date('d F Y',strtotime($row['tgl_pengajuan'])); ?></td>
                          <td><?php echo $row['judul_proposal']; ?></td>
                          <td>
                            <?php 
                            if ($row['status_proposal']=='Belum Dibaca') {
                              echo "<span class='label label-warning' style='font-weight:bold;font-size:16px;'>Belum Dibaca</span>";

                            }elseif ($row['status_proposal']=='Ditolak') {
                              echo "<span class='label label-danger' style='font-weight:bold;font-size:16px;'>Ditolak</span>";

                            }else{
                              echo "<span class='label label-success' style='font-weight:bold;font-size:16px;'>Rekomendasi</span>";
                            }

                             ?>
                              
                            </td>
                          <td>
                            <a data-toggle="modal" data-target="#<?php echo $row['id_pengajuan']; ?>" class="btn btn-success btn-xs">Selengkapnya >></a>
    <div class="modal fade bs-example-modal-lg" id="<?php echo $row['id_pengajuan']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><?php echo $row['judul_proposal']; ?></h4>
          </div>
          <form action="" method="POST" accept-charset="utf-8">
          <div class="modal-body">
            <b>POKOK MASLAH : </b>
            <p>
              <?php echo $row['masalah']; ?>
              <input type="hidden" name="status" value="Rekomendasi">
              <input type="hidden" name="statust" value="Ditolak">
              <input type="hidden" name="id" value="<?php echo $row['id_pengajuan']; ?>">
            </p>
          </div>
          <div class="modal-footer">
            <center>
            <!--   <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button> -->
              <button type="submit" name="tidak" class="btn btn-danger"> <i class="fa fa-times"></i> TIDAK </button>
            <button type="submit" name="rekomendasi" class="btn btn-primary"> <i class="fa fa-check"></i> REKOMENDASI JUDUL </button>
            </center>
          </div>
          </form>
          <?php 
          if (isset($_POST['rekomendasi'])) {

            $id = $_POST['id'];
            $status = $_POST['status'];
            $today = date('Y-m-d');
            mysqli_query($con,"UPDATE tb_pengajuanjudul SET status_proposal='$status',tgl_rekomendasi='$today' WHERE id_pengajuan='$id' ");

            echo "
            <script type='text/javascript'>
            setTimeout(function () {
            swal({
            title: 'REKOMENDASI SUKSES',
            text:  'Informasi ini Akan Disampaikan Ke KAPRODI ..',
            type: 'success',
            timer: 3000,
            showConfirmButton: true
            });     
            },10);  
            window.setTimeout(function(){ 
            window.location.replace('?page=pengajuan&mhs=$mhs');
            } ,3000);   
            </script>";

            
          }elseif (isset($_POST['tidak'])) {
            $id = $_POST['id'];
            $statust = $_POST['statust'];
            $today = date('Y-m-d');
            mysqli_query($con,"UPDATE tb_pengajuanjudul SET status_proposal='$statust',tgl_rekomendasi='$today' WHERE id_pengajuan='$id' ");

            echo "
            <script type='text/javascript'>
            setTimeout(function () {
            swal({
            title: 'SUKSES',
            text:  'Informasi ini Akan Disampaikan Ke Mahasiswa ..',
            type: 'success',
            timer: 3000,
            showConfirmButton: true
            });     
            },10);  
            window.setTimeout(function(){ 
            window.location.replace('?page=pengajuan&mhs=$mhs');
            } ,3000);   
            </script>";

            
          }
           ?>

        </div>
      </div>
    </div>

                          </td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>
        </div>
    </div>
</div>
            </div>
          </div>
        </div>
      </div>
 </div>

