<?php 
$pemb= $_GET['pemb'];
$pem1 = mysqli_query($con,"SELECT * FROM tb_pembone
INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
WHERE  tb_pembone.id_pembone='$pemb'");
$p1= mysqli_fetch_array($pem1);
 ?>
 <?php 
// $pembtwo= $_GET['pembtwo'];
$pem2 = mysqli_query($con,"SELECT * FROM tb_pembtwo
-- INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
WHERE tb_pembtwo.id_pengajuan='$p1[id_pengajuan]'");
$p2= mysqli_fetch_array($pem2);
 ?>


   <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-body">
<table width="100%" style="border-bottom: 5px double;">
  <tr>
    <td><img src="../assets/images/unibba.png" width="100" /></td>
    <td align="center"><p align="center">
    	<h3><strong>UNIVERSITAS BALE BANDUNG</strong></h3></p>
    <p align="center"><h4><strong>FAKULTAS TEKNOLOGI INFORMASI</strong></h4></p>
	</td>
 	 </tr>
  <tr>
    <td width="5%">&nbsp;</td>
    <td width="95%"><p align="center">Jl. R.A.A Wiranatakusumah No.7 Baleendah40258 - Telepon (022) 5943106, Website: https://fti.unibba.ac.id/</p>
	</td>
  </tr>
</table>
<br>

 <table cellpadding="1" cellspacing="1" style="width:100%">
	<tbody>
		<tr>
			<td>Nomor</td>
			<td>: 01/FTI-UNIBBA/<?php echo date ("Y") ?></td>
		</tr>
		<tr>
			<td>Lamp</td>
			<td>: 1 (Satu) Rangkap</td>
		</tr>
		<tr>
			<td>Hal</td>
			<td>: <strong>Mohon Kesediaan Jadi Pembimbing</strong></td>
		</tr>
	</tbody>
</table>

<p>Yth : <strong><?php echo $p1['nama_dosen']; ?></strong></p>

<p>Di Tempat</p>

<p>Assalamu&#39;alaikum wr,wb.</p>

<p>&nbsp; &nbsp;Sesuai dengan usulan Pembimbing Skripsi yang dia ajukan oleh Mahasiswa Jurusan Teknik Informatika. Fakultas Teknologi Informasi, Maka bersama ini dimohon kesediaan Bapak/Ibu sebagai pembimbing Skripsi Mahasiswa dibawah ini :</p>

<table cellpadding="1" cellspacing="1" width="100%">
	<tbody>
		<tr>
			<td>Nama</td>
			<td>: </td>
			<td><strong><?php echo $p1['nama']; ?></strong></td>
		</tr>
		<tr>
			<td>NIM</td>
			<td>: </td>
			<td><?php echo $p1['nim']; ?></td>
		</tr>
		<tr>
			<td>Judul Skripsi</td>
			<td>: </td>
			<td><strong><?php echo $p1['judul_proposal']; ?></strong></td>
		</tr>
		<tr>
			<td>Pembimbing</td>
			<td>: </td>
			<td>1. <?php
			if ($p1['ket_one']=='Belum Konfir') {
				?>
				<b class='text-danger'>Belum Anda Kofirmasi</b>
				<a href="?page=confirm&act=confir&aksi=<?php echo $p1['id_pembone']; ?>" class='btn btn-default' style="background-color:#9CCC65;color: #fff;"><i class='fa fa-check'></i> Klik Disini Jika Anda Menyetujui !</a>
				<?php
			}else{
				echo $p1['nama_dosen']; 
			}

			 ?></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>2. <?php
			if ($p2['ket_two']=='Belum Konfir') {
				echo "<b>Belum Konfirmasi</b>";
			}else{
				echo $p2['nama_dosen']; 
			}

			 ?></td>
		</tr>
	</tbody>
</table>

<p>&nbsp; &nbsp; &nbsp;Demikian permohonan ini kami sampaikan atas perhatian dan kerjasamanya saya ucapkan terimakasih.</p>

<p style="text-align:right">Wassalam.</p>

<p style="text-align:right">Ketua Jurusan,</p>

<p style="text-align:right">&nbsp;</p>

<p style="text-align:right">&nbsp;</p>

<p style="text-align:right"><strong><u>Yaya Suharya, S.kom., M.T.</u><br></strong><strong>NIDN. 0407047706</strong> </p>
        </div>
      </div>
    </div>
</div>







	