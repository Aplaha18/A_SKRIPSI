<?php 
$aksi = $_GET['aksi'];
$aksi2 = $_GET['aksi2'];
$sql = mysqli_query($con,"UPDATE tb_pembone SET ket_one='Bersedia' WHERE id_pembone='$aksi' ");
$sql2 = mysqli_query($con,"UPDATE tb_pembtwo SET ket_two='Bersedia' WHERE id_pembtwo='$aksi2' ");
if ($sql || $sql2) {
// echo " <script>
// 	window.location='index.php';
// </script>";	
echo "
<script type='text/javascript'>
	setTimeout(function () {
	swal({
	title: 'TERIMAKASIH TELAH KONFIRMASI',
	text:  '-',
	type: 'success',
	timer: 3000,
	showConfirmButton: true
	});     
	},10);  
	window.setTimeout(function(){ 
	window.location.replace('index.php');
	} ,3000);   
</script>
";
}

 ?>



