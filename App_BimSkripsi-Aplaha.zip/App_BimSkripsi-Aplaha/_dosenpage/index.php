
<?php 
error_reporting(0);
ini_set('display_errors',0);
session_start();
if (!isset($_SESSION['dosen'])) {
?> <script>
    alert('Anda Belum Login !!');
    window.location='../logindsn.php';
 </script>
<?php
}
include '../config/databases.php';
 ?>


<!DOCTYPE html>
<html>
<head>
  <title>Selamat Datang - <?php echo $_SESSION['nama']; ?></title>
    
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="../assets/css/vendor.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/flat-admin.css">

  <!-- Theme -->
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/blue-sky.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/blue.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/red.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/yellow.css">
  <!-- Sweat Alert -->
    <link rel="stylesheet" type="text/css" href="../assets/alert/css/sweetalert.css">
      <script src="../assets/alert/js/jquery-2.1.4.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="../assets/alert/js/sweetalert.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script type="text/javascript" src="../assets/ckeditor/ckeditor.js"></script>


</head>
<body>
<?php
if (@$_SESSION['dosen']) {
$id_dosen = @$_SESSION['id'];
}

$sql = mysqli_query($con,"SELECT * FROM tb_dsn WHERE id_dsn='$id_dosen'") or die(mysqli_error($con));
$data = mysqli_fetch_array($sql);
?>
 <div class="app app-red">
<aside class="app-sidebar" id="sidebar">
  <div class="sidebar-header" style="background-color: #212121;">
   
    <a class="sidebar-brand" href="#"><span class="highlight"><b>DOSEN</b></span> <!-- <b style="color: #fff;">Mahasiswa</b> --></a>
    
    <button type="button" class="sidebar-toggle">
      <i class="fa fa-times"></i>
    </button>
  </div>
  <div class="sidebar-menu" style="background-color: #212121;">
    <ul class="sidebar-nav">
      <li class="">
        <a href="index.php">
          <div class="icon">
            <i class="fa fa-home" aria-hidden="true"></i>
          </div>
          <div class="title" style="color: #fff;">Beranda</div>
        </a>
      </li>
  <!--     <li>
        <a href="?page=stepone&act=intopik">
          <div class="icon">
            <i class="fa fa-cogs" aria-hidden="true"></i>
          </div>
          <div class="title">Pengaturan</div>
        </a>
      </li> -->
      <li class="dropdown ">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <div class="icon">
            <i class="fa fa-cogs" aria-hidden="true"></i>
          </div>
          <div class="title" style="color: #fff;">Pengaturan</div>
        </a>
        <div class="dropdown-menu" style="border-right: 2px double #E91E63;">
          <ul>
            <li class="section"><i class="fa fa-cog" aria-hidden="true"></i> Pengaturan</li>
            <!-- <li><a href="../uikits/customize.html">Buat Jadwal Bimbingan</a></li> -->
             <li><a href="?page=set">Buat Prosedur Bimbingan</a></li>
            <li class="line"></li>
          </ul>
        </div>
      </li>
 <!--      <li class="@@menu.messaging">
        <a href="../messaging.html">
          <div class="icon">
            <i class="fa fa-comments" aria-hidden="true"></i>
          </div>
          <div class="title">Pesan</div>
        </a>
      </li> -->
      <li class="dropdown ">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <div class="icon">
            <i class="fa fa-users" aria-hidden="true"></i>
          </div>
          <div class="title" style="color: #fff;">Bimbingan</div>
        </a>
        <div class="dropdown-menu">
          <ul>
            <li class="section"><i class="fa fa-file-o" aria-hidden="true"></i> PEMBIMBING II</li>
            <li><a href="?page=bimbingan&act=listmhs2">Daftar Mahasiswa Bimbingan</a></li>
            <li class="line"></li>
            <li class="section"><i class="fa fa-file-o" aria-hidden="true"></i> PEMBIMBING I</li>
            <li><a href="?page=bimbingan1&act=listmhs1">Daftar Mahasiswa Bimbingan</a></li>
          </ul>
        </div>
      </li>
  
      
    </ul>
  </div>
  <div class="sidebar-footer" style="background-color: #ff0000;">
    <ul class="menu">
      <li>
        <a href="" class="dropdown-toggle" data-toggle="dropdown">
          <!-- <i class="fa fa-cogs" aria-hidden="true"></i> -->
          FTI 2020 - UNIBBA
        </a>
      </li>
      <!-- <li><a href="#"><span class="flag-icon flag-icon-th flag-icon-squared"></span></a></li> -->
    </ul>
  </div>
</aside>

<script type="text/ng-template" id="sidebar-dropdown.tpl.html">
  <div class="dropdown-background">
    <div class="bg"></div>
  </div>
  <div class="dropdown-container">
    {{list}}
  </div>
</script>
<div class="app-container">
  <nav class="navbar navbar-default" id="navbar">
  <div class="container-fluid">
    <div class="navbar-collapse collapse in">
      <ul class="nav navbar-nav navbar-mobile">
        <li>
          <button type="button" class="sidebar-toggle">
            <i class="fa fa-bars"></i>
          </button>
        </li>
        <li class="logo">
          <a class="navbar-brand" href="#"><span class="highlight">Dosen</span> Online</a>
        </li>
        <li>
          <button type="button" class="navbar-toggle">
            <img class="profile-img" src="../assets/images/<?php echo $data['foto'] ?>">
          </button>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-left">
        <li class="navbar-title">
          <!-- <?php echo date('d F Y'); ?> -->
          <b style="color:black;"><img src="../assets/images/fti.png" width="75"> BIMBINGAN SKRIPSI ONLINE</b> 
          
        </li>
        <li class="navbar-search hidden-sm">
          <!-- Online -->
 <!--          <input id="search" type="text" placeholder="Search..">
          <button class="btn-search"><i class="fa fa-search"></i></button> -->
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown notification danger">
              <?php
              $pem1 = mysqli_query($con,"SELECT * FROM tb_pembone
              INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
              WHERE  tb_pembone.ket_one='Belum Konfir' AND tb_pembone.id_dsn='$data[id_dsn]' ");
              $jpem1 = mysqli_num_rows($pem1);
              $pem2 = mysqli_query($con,"SELECT * FROM tb_pembtwo
              INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
              WHERE  tb_pembtwo.ket_two='Belum Konfir' AND tb_pembtwo.id_dsn='$data[id_dsn]' ");
               $jpem2 = mysqli_num_rows($pem2);
              ?>
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <div class="icon"><i class="fa fa-info" aria-hidden="true"></i></div>
            <div class="title">System Notifications</div>
            <div class="count">
              <?php $jmnya = $jpem1+$jpem2; ?>
              <?php echo $jmnya; ?></div>
          </a>
          <div class="dropdown-menu">
            <ul>
              <li class="dropdown-header"><h4 class="username">Kesediaan Jadi Pembimbing</h4></li>
                <?php
                while ($p1= mysqli_fetch_array($pem1)) { ?>
                <li>
                    <a href="?page=confirm&pemb=<?php echo $p1['id_pembone']; ?>">
                      <span class="badge badge-danger pull-right"></span> 
                      <div class="message">
                        <div class="content">
                          <div class="title">Judul : "<b class="text-danger"><?php echo $p1['judul_proposal'] ?></b>" </div>
                        </div>
                      </div>
                    </a>
                </li>

                <?php 
                }
                ?>
                 <?php
                while ($p2= mysqli_fetch_array($pem2)) { ?>
                <li>
                    <a href="?page=confirm&act=two&pembtwo=<?php echo $p2['id_pembtwo']; ?>">
                      <span class="badge badge-danger pull-right"></span> 
                      <div class="message">
                        <div class="content">
                          <div class="title">Judul : "<b class="text-danger"> <?php echo $p2['judul_proposal'] ?> </b>" </div>
                        </div>
                      </div>
                    </a>
                </li>

                <?php 
                }
                ?>
            </ul>
          </div>
        </li>
        <li class="dropdown notification warning">
          <!-- pemb 1 -->
          <?php 
          $query_daftar_pesan = mysqli_query($con,"SELECT * FROM tb_pesanpembone
          INNER JOIN tb_pembone ON tb_pesanpembone.id_pembone=tb_pembone.id_pembone
          INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs 
          WHERE tb_pesanpembone.id_penerima='$data[id_dsn]'
          AND tb_pesanpembone.status_pesan='belum'
          ORDER BY id_pesan DESC ");
          $pemb1= mysqli_num_rows($query_daftar_pesan);

           ?>
          <!-- pemb 2 -->
          <?php 
          $daftar_pesan = mysqli_query($con,"SELECT * FROM tb_pesan
          INNER JOIN tb_pembtwo ON tb_pesan.id_pembtwo=tb_pembtwo.id_pembtwo
          INNER JOIN tb_mhs ON tb_pembtwo.id_mhs=tb_mhs.id_mhs 
          WHERE tb_pesan.id_penerima='$data[id_dsn]'
          AND tb_pesan.status_pesan='belum'
          ORDER BY id_pesan DESC ");
           $pemb2= mysqli_num_rows($daftar_pesan);
           ?>

          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <div class="icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
            <div class="title">Unread Messages</div>
            <div class="count">
             <?php  $jmpemb = $pemb1+$pemb2 ?>

            <?php echo $jmpemb ?></div>
          </a>
          <div class="dropdown-menu">
            <ul>
              <li class="dropdown-header"><h4 class="username">Pesan Masuk Bimbingan</h4></li>
                <!-- Informasi Bimbingan 1 --> 
                <?php
                while ($pesan=mysqli_fetch_array($query_daftar_pesan)) { ?>
                <li>
                <a href="?page=bimbingan1&act=riwayat2&id_mhs=<?php echo $pesan['id_mhs'] ?>">
                  <!-- <span class="badge badge-warning pull-right">10</span> -->
                  <div class="message">
                    <img class="profile" src="../assets/img-mhs/<?php echo $pesan['fotomhs'] ?>">
                    <div class="content">
                      <div class="title">"<?php echo $pesan['subyek'] ?>"</div>
                      <div class="description"><?php echo $pesan['nama'] ?></div>
                    </div>
                  </div>
                </a>
                </li>
                <?php 
                } 
                ?>
              <!-- Informasi pesan sebagai pembimbing 2 -->
              <?php
              while ($pesan2=mysqli_fetch_array($daftar_pesan)) { ?>
              <li>
                <a href="?page=bimbingan&act=riwayat2&id_mhs=<?php echo $pesan2['id_mhs'] ?>">
                <!-- <span class="badge badge-warning pull-right">10</span> -->
                <div class="message">
                  <img class="profile" src="../assets/img-mhs/<?php echo $pesan2['fotomhs'] ?>">
                  <div class="content">
                    <div class="title">"<?php echo $pesan2['subyek'] ?>"</div>
                    <div class="description"><?php echo $pesan2['nama'] ?></div>
                  </div>
                </div>
                </a>
              </li>
              <?php 
              } 
              ?>
            </ul>
          </div>
        </li>
        <li class="dropdown notification danger">
            <?php
            $mhs = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul INNER JOIN tb_mhs ON tb_pengajuanjudul.id_mhs=tb_mhs.id_mhs WHERE tb_pengajuanjudul.id_dsn='$data[id_dsn]' AND status_proposal='Belum Dibaca' GROUP BY tb_pengajuanjudul.id_mhs DESC ");
            $jml = mysqli_num_rows($mhs);
            ?>
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <div class="icon"><i class="fa fa-bell" aria-hidden="true"></i></div>
            <div class="title">System Notifications</div>
            <div class="count"><?php echo $jml; ?></div>
          </a>
          <div class="dropdown-menu">
            <ul>
              <li class="dropdown-header"><h4 class="username">Mahasiswa Mengajukan Judul</h4></li>
                <?php
                while ($d= mysqli_fetch_array($mhs)) { ?>
                <li>
                    <a href="?page=pengajuan&mhs=<?php echo $d['id_mhs']; ?>">
                      <span class="badge badge-danger pull-right"></span> 
                      <div class="message">
                        <div class="content">
                          <div class="title"><img class="img-circle" src="../assets/img-mhs/<?php echo $d['fotomhs'] ?>" width="50" height="50"> <b><?php echo $d['nama']; ?> </b>
                          (<?php echo $d['nim']; ?>)</div>
                          <div class="description">Mengajukan Judul | <?php echo $d['tgl_pengajuan']; ?></div>
                        </div>
                      </div>
                    </a>
                </li>

                <?php 
                }
                ?>
            </ul>
          </div>
        </li>
        <li class="dropdown profile">
          <a href="/html/pages/profile.html" class="dropdown-toggle"  data-toggle="dropdown">
            <img class="profile-img" src="../assets/images/<?php echo $data['foto'] ?>">
            <div class="title">Profile</div>
          </a>
          <div class="dropdown-menu">
            <div class="profile-info">
              <h4 class="username"><?php echo $data['nama_dosen'] ?></h4>
            </div>
            <ul class="action">
            <!--   <li>
                <a href="#">
                  <span class="badge badge-danger pull-right">5</span>
                  My Inbox
                </a>
              </li> -->
              <li>
                <a href="?page=set&act=profile">
                  Ubah Password
                </a>
              </li>
              <li>
                <a href="logout.php">
                  Logout
                </a>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

  <?php 
  error_reporting();
  $page = $_GET['page'];
  $act= $_GET['act'];
    if ($page=='pengajuan') {
      if ($act=='') {
        include 'pages/pengajuan/view_pengajuanjudul.php';
      }
    }elseif ($page=='confirm') {
      if ($act=='') {
         include 'pages/confirmasi/confirmasi-one.php';
      }elseif ($act=='two') {
         include 'pages/confirmasi/confirmasi-two.php';
      }elseif ($act=='confir') {
       include 'pages/confirmasi/confirmasi.php';
      }
    }elseif ($page=='bimbingan') {
      if ($act=='listmhs2') {
        include 'pages/bimbingan/list_mahasiswa2.php';
      }elseif ($act=='riwayat2') {
        include 'pages/bimbingan/riwayat_bimbingan2.php';
      }elseif ($act=='bukapesan') {
        include 'pages/bimbingan/buka_pesan.php';
      }
    }elseif ($page=='bimbingan1') {
      if ($act=='listmhs1') {
        include 'pages/bimbingan1/list_mahasiswa1.php';
      }elseif ($act=='riwayat2') {
         include 'pages/bimbingan1/riwayat_bimbingan1.php';
      }elseif ($act=='bukapesan') {
        include 'pages/bimbingan1/buka_pesan.php';
      }elseif ($act=='stop') {
        include 'pages/bimbingan1/akhir_bimbingan.php';

      }
    }
    
    elseif ($page=='set') {
      if ($act=='') {
        include 'pages/pengaturan/set_peraturan.php';
      }elseif ($act=='addprosedur') {
        include 'pages/pengaturan/tambah_peraturan.php';
      }elseif ($act=='edit') {
        include 'pages/pengaturan/edit_peraturan.php';
      }elseif ($act=='del') {
         include 'pages/pengaturan/del_peraturan.php';
      }elseif ($act=='profile') {
         include 'pages/pengaturan/set_profile.php';
      }
    }elseif ($page=='') {
       include 'homepage.php';
    }else{
     echo "Page Not Found !";
    }

   ?>

  </div>
</div>

  <script type="text/javascript" src="../assets/js/vendor.js"></script>
  <script type="text/javascript" src="../assets/js/app.js"></script>
      <script>
          CKEDITOR.replace('ckedtor1',{
             uiColor:'#FAFAFA',
            filebrowserImageBrowseUrl : 'assets/kcfinder'
        });
        
    </script>


</body>
</html>