
 <div class="row">
    <div class="col-lg-12">
      <div class="card"style="background: url('../front/img/bg-banner.jpg');">
        <!-- style="background-color: RGBA(12, 11, 11, 0.82);" -->
        <div class="card-body app-heading"style="background-color: RGBA(12, 11, 11, 0.82);">
          <!-- <img class="profile-img" src="../assets/images/<?php echo $data['foto'] ?>"> -->
          <div class="app-title">
            <div class="title"><span class="highlight" style="color:#81D4FA;"><b>Dashboard</b> Administrator</span>
              <!-- <img src="../assets/images/iain.png" width="60" class="pull-right" style="border-radius: 5px;"> -->
              <b class="pull-right" style="color: #fff;font-size: 18px;">PROGRAM STUDI TEKNIK INFORMATIKA</b>
            </div>
             <div class="description" style="color: #fff;"> <code  style="font-size: 16px;">Selamat Datang [ <b  style="font-size: 18px;"><?php echo $data['nama_adm'] ?></b> ]</code></div> 
          </div>
        </div>
      </div>
    </div>
  </div>
   <?php include 'pages/dashboard.php'; ?>


  <div class="row">

    <!-- Tabs -->
    <div class="col-sm-12 col-xs-12">
      <div class="card">
     <!--    <div class="card-header">
          Tab & Step
        </div> -->
        <div class="card-body">
            <div class="section-body">
              <div class="step">
    <ul class="nav nav-tabs nav-justified" role="tablist">
        <li role="step" class="active">
            <a href="#step2" role="tab" id="step2-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-info"></div>
                <div class="heading">
                    <div class="title">Halaman Administrator</div>
                    <div class="description">Informasi Utama</div>
                </div>
            </a>
        </li>
        <li role="step">
            <a href="#step3" role="tab" id="step3-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-bar-chart-o"></div>
                <div class="heading">
                    <div class="title">Grafik</div>
                    <div class="description">Grafik Skripsi Mahasiswa</div>
                </div>
            </a>
        </li>
        <!-- <li role="step">
            <a href="#step4" role="tab" id="step4-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-truck "></div>
                <div class="heading">
                    <div class="title">Purchase Successfully</div>
                    <div class="description">Wait for us shipping</div>
                </div>
            </a>
        </li> -->
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="step2">
            <!-- <b>Informasi Utama</b>: -->
            <!-- <hr> -->
            
               <div class="row">
                    <div class="col-md-6">
                    

              </div> 
              <div class="col-md-6">
                <!-- <h3>SELAMAT DATANG</h3> -->
               
              </div>   
               </div>   
              
           

        </div>

        <!-- tab 2 -->
         <div role="tabpanel" class="tab-pane" id="step3">
         <h3> Grafik</h3>
         <hr>
          <?php 
$sql = mysqli_query($con,"SELECT * FROM tb_mhs GROUP BY tahun_angkatan");
$tahun = array();
$selesai = array();
$blmselesai = array();

while ($dg= mysqli_fetch_array($sql)) {
$tahun [] = $dg['tahun_angkatan'];

// selaseai
$sumSelesai=mysqli_query($con,"SELECT COUNT(id_mhs) as selesai FROM tb_mhs WHERE tahun_angkatan='$dg[tahun_angkatan]' AND status_skripsi='SELESAI' ");
$sl= mysqli_fetch_array($sumSelesai);
$selesai [] = intval($sl['selesai']);



}

?>

         <div id="grafik"></div>
         <script>

Highcharts.chart('grafik', {
  chart: {
    type: 'spline'
  },
  title: {
    text: 'GRAFIK SKRIPSI SELESAI'
  },
  subtitle: {
    text: 'Source: Sistem Monitoring Skripsi'
  },
  xAxis: {
    categories: <?php echo json_encode($tahun) ?>
  },
  yAxis: {
    title: {
      text: 'Jumlah'
    },
    labels: {
      formatter: function () {
        return this.value + '';
      }
    }
  },
  tooltip: {
    crosshairs: true,
    shared: true
  },
  plotOptions: {
    spline: {
      marker: {
        radius: 4,
        lineColor: '#666666',
        lineWidth: 1
      }
    }
  },
  series: [{
    name: 'SELESAI',
    marker: {
      symbol: 'square'
    },
    data: <?php echo json_encode($selesai) ?>

  }]
});

         </script>

         </div>
        
       
    </div>
</div>
            </div>
          </div>
        </div>
      </div>

    <!-- end tabs -->

  </div>

    