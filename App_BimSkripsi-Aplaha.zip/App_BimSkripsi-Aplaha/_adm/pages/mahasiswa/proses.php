<?php 
if (isset($_POST['save'])) {
	$nama = $_POST['nama'];
	$nim = $_POST['nim'];
	$tahun = $_POST['tahun'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$password1 = $_POST['password'];

	$sumber = @$_FILES['foto']['tmp_name'];
	$target = '../assets/img-mhs/';
	$nama_gambar = @$_FILES['foto']['name'];
	$pindah = move_uploaded_file($sumber, $target.$nama_gambar);
	if ($pindah) {
	mysqli_query($con,"INSERT INTO tb_mhs VALUES (NULL,'$nim','$nama','$tahun','$username','$password','$password1','$nama_gambar','Y','$_POST[jenis]')") or die (mysqli_error($con));
	?>
		<script type='text/javascript'>
		setTimeout(function () {
		swal({
		title: 'DATA TERSIMPAN',
		text:  'Berhasil Menyimpan Data !',
		type: 'success',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=mhs');
		} ,3000);   
		</script>
	<?php
	}
}elseif (isset($_POST['update'])) {
	$id = $_POST['id'];
	$nim = $_POST['nim'];
	$nama = $_POST['nama'];
	$tahun = $_POST['tahun'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$password1 = $_POST['password'];

	$gambar = @$_FILES['foto']['name'];
	if (!empty($gambar)) {
		move_uploaded_file($_FILES['foto']['tmp_name'],"../assets/img-mhs/$gambar");
		$ganti = mysqli_query($con,"UPDATE tb_mhs SET fotomhs='$gambar' WHERE id_mhs='$id' ");
	}
	mysqli_query($con,"UPDATE tb_mhs SET nim='$nim',nama='$nama',username='$username',password='$password',secondpass='$password1',tahun_angkatan='$tahun' WHERE id_mhs='$id' ") or die (mysqli_error($con));
	?>
		<script type='text/javascript'>
		setTimeout(function () {
		swal({
		title: 'DATA DIUBAH',
		text:  'Berhasil Mengubah Data !',
		type: 'success',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=mhs');
		} ,3000);   
		</script>
	<?php
}

 ?>