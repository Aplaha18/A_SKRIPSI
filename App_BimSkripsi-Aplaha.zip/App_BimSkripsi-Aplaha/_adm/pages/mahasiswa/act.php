<link rel="stylesheet" type="text/css" href="../assets/alert/css/sweetalert.css">
<script src="../assets/alert/js/jquery-2.1.4.min.js" type="text/javascript" charset="utf-8" async defer></script>
<script src="../assets/alert/js/sweetalert.min.js" type="text/javascript" charset="utf-8" async defer></script>

<?php 
// Panggil Koneksi Databases
include '../config/databases.php';

		// 
		if (isset($_POST['register'])) {
			$setuju = $_POST['ok'];
		$nama = $_POST['nama'];
		$nim = $_POST['nim'];
		$tahun = $_POST['tahun'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$secondpass = $_POST['secondpass'];

		$sumber = @$_FILES['foto']['tmp_name'];
		$target = '../assets/img-mhs/';
		$nama_gambar = @$_FILES['foto']['name'];
		move_uploaded_file($sumber, $target.$nama_gambar);
		if ($password == $secondpass) {
		$sql_get = mysqli_query ($con,"SELECT * FROM tb_mhs WHERE username = '$username'");
		$num_row = mysqli_num_rows($sql_get);

		if ($num_row==0) {
		$passwordnya= md5($password);
		//  echo "lanjutkan query";
		mysqli_query($con,"INSERT INTO tb_mhs VALUES(NULL,'$nim','$nama','$username','$passwordnya','$secondpass','$nama_gambar','$tahun','Y','N') ");
		echo "
		<script type='text/javascript'>
		setTimeout(function () {
		swal({
		title: 'Selamat',
		text:  'Akun mahasiswa berhasil di buat!!',
		type: 'success',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=mhs');
		} ,3000);   
		</script>";
		}else {
		echo "
		<script type='text/javascript'>
		setTimeout(function () { 

		swal({
		title: 'MAAF !!',
		text:  'Username Sudah Digunakan, Ubah Username Anda !!',
		type: 'error',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=mhs');
		} ,3000);   
		</script>";
		}
		}else {
		//    echo " <script> alert('password tidak sama ??'); </script>";
		echo "
		<script type='text/javascript'>
		setTimeout(function () { 

		swal({
		title: 'OPSS !!',
		text:  'Konfirmasi Password Tidak Cocok !!',
		type: 'error',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=mhs');
		} ,3000);   
		</script>";
		}
		}
		

 ?>
