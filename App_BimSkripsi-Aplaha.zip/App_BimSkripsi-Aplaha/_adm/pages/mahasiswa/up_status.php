<?php 
$id = $_GET['id'];
$status = $_GET['status'];
if ($status=='Y') {
	$sql1=mysqli_query($con,"UPDATE tb_mhs SET status_akun='N' WHERE id_mhs='$id' ");
}else{
	$sql2=mysqli_query($con,"UPDATE tb_mhs SET status_akun='Y' WHERE id_mhs='$id' ");
}
if ($sql1 || $sql2) {
	echo "<script>
	window.location='?page=mhs';
</script>";
	
}

 ?>