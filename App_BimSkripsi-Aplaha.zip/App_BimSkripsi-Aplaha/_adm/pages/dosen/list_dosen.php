<div class="row">
<!-- <div class="col-xs-12">

</div> -->
<h4></h4>
<div class="col-xs-12">

      <div class="card">
        <div class="card-header">
         <h3> <a href="javascript:history.back()" class="btn btn-danger btn-xs"> <i class="fa fa-chevron-left"></i> Kembali</a>&nbsp;
<a data-toggle="modal" data-target="#modalTambah" class="btn btn-primary btn-xs"> <i class="fa fa-plus"></i> Tambah Dosen</a> &nbsp;  <b>Manajemen Dosen</b></h3>
        </div>
        <div class="card-body no-padding">
            <table class="datatable table table-striped primary" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Foto</th>
                        <th>NIK</th>
                        <th>Nama Dosen</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no= 1;
                     $mhs = mysqli_query($con,"SELECT * FROM tb_dsn ORDER BY id_dsn ASC ") or die(mysqli_error($con)) ;
                        while ($data= mysqli_fetch_array($mhs)) { ?>
                   
                    <tr>
                    <a href="?page=bimbingan&act=riwayat2&id_mhs=<?php echo $data['id_mhs'];?> ">
                        <td><b><?php echo $no++; ?>.</b></td>
                        <th>
                            <img src="../assets/images/<?php echo $data['foto']; ?>" width="40" height="40" class="img-circle">
                        </th>
                        <td><?php echo $data['nip']; ?></td>
                        <td><?php echo $data['nama_dosen']; ?></td>
                        <td><?php echo $data['jabatan']; ?></td>
                        <td>
                            <?php if ($data['status_akundsn']=='Y') {
                            echo "<b class='label label-success'>Aktif</b> ";
                        }else{
                            echo "<b class='label label-danger'>Blokir</b> ";
                        }
                        ?></td>
                        <td>
                            <center>
                              <?php if ($data['status_akundsn']=='Y') {
                                ?>
                                 <a href="?page=dosen&act=get&id=<?php echo $data['id_dsn'];?>&status=<?php echo $data['status_akundsn'];?>" class="btn btn-danger btn-xs"> <i class="fa fa-times"></i></i> Blokir</a>
                                <?php
                            }else{
                                ?>
                                <a href="?page=dosen&act=get&id=<?php echo $data['id_dsn'];?>&status=<?php echo $data['status_akundsn'];?>" class="btn btn-primary btn-xs"> <i class="fa fa-check"></i></i> Aktif</a>
                                <?php
                                }
                            ?>

                            <a href="?page=dosen&act=detail&id_dsn=<?php echo $data['id_dsn'];?> " class="btn btn-success btn-xs"> <i class="fa fa-search-plus"></i></a>

                            <a href="pages/dosen/printdetail_dosen.php?id_dsn=<?php echo $data['id_dsn'];?> " class="btn btn-warning btn-xs" target="_blank"> <i class="fa fa-print"></i></a>

                            <a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#<?php echo $data['id_dsn'];?>"> <i class="fa fa-pencil"></i></a>
                            <!-- Modal Edit -->
                            <div class="modal fade bs-example-modal-lg" id="<?php echo $data['id_dsn'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                <div class="modal-dialog modal-lg" style="width: 95%;">
                                    <div class="modal-content">
                                      <div class="modal-header" style="background-color: #E91E63;color: #fff">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title"> <i class="fa fa-pencil"></i> Ubah Data Dosen</h4>
                                      </div>
                                        <form action="?page=dosen&act=proses" method="POST" accept-charset="utf-8" enctype="multipart/form-data">
                                          <div class="modal-body">
                                            <table class="table">
                                                <tr>
                                                    <td>NIK</td>
                                                    <td><input type="text" name="nip" class="form-control" value="<?php echo $data['nip'] ?>" required style="width: 100%;"></td>
                                                     <td>Nama Lengkap</td>
                                                    <td> <input type="text" name="nama" class="form-control" value="<?php echo $data['nama_dosen'] ?>" required style="width: 100%;"></td>
                                                </tr>
                                                <tr>
                                                    <td>Jabatan</td>
                                                    <td><input type="text" name="jabatan" class="form-control" value="<?php echo $data['jabatan'] ?>" required style="width: 100%;"></td>
                                                     <td> Foto  <img src="../assets/images/<?php echo $data['foto']; ?>" width="50" height="50" class="img-thumbnail"></td>
                                                    <td> <input type="file" name="foto" class="form-control" style="width: 100%;"></td>
                                                </tr>
                                                  <tr>
                                                    <td>Username</td>
                                                    <td><input type="text" name="username" class="form-control" value="<?php echo $data['username'] ?>" required style="width: 100%;"></td>
                                                     <td>Password</td>
                                                    <td> <input type="text" name="password" class="form-control" value="<?php echo $data['seconddpass'] ?>" required style="width: 100%;"></td>
                                                </tr>
                                                <input type="hidden" name="id" value="<?php echo $data['id_dsn'] ?>">


                                            </table>          
                                          </div> 
                                          <div class="modal-footer" style="background-color:#424242;">
                                            <center>
                                                <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"> <i class="fa fa-times"></i> TUTUP</button>
                                                <button type="submit" name="update" class="btn btn-sm btn-success"> <i class="fa fa-pencil"></i> UPDATE DATA</button>
                                            </center>
                                          </div>
                                      </form>
                                    </div>
                                </div>
                            </div>


                            <!-- End Modal Edit -->

                             <a href="?page=dosen&act=del&id_dsn=<?php echo $data['id_dsn'];?> " class="btn btn-danger btn-xs" onclick="return confirm('Yakin Akan Hapus Data ??')"> <i class="fa fa-trash"></i></a>
                             </center>
                        </td>
                    </a>
                    </tr>                 
                <?php } ?>

                </tbody>
            </table>
        </div>
      </div>

      <!-- Modal Tamabh Data Dosen -->
    <div class="modal fade bs-example-modal-lg" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog modal-lg" style="width: 95%;">
        <div class="modal-content">
          <div class="modal-header" style="background-color: #E91E63;color: #fff">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"> <i class="fa fa-plus"></i> Tambah Data Dosen</h4>
          </div>
          <form action="?page=dosen&act=proses" method="POST" accept-charset="utf-8" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="row">
                <div class="col-md-6">
                <div class="form-group">
                    <label>NIK</label>
                    <input type="text" name="nip" class="form-control" placeholder="Enter NIK  .." required>
                </div>                                               
                </div> 
                <div class="col-md-6">
                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control" placeholder="Enter nama lengkap.." required>
                </div>                                               
                </div>                           
            </div>
            <div class="row">
                <div class="col-md-6">
                <div class="form-group">
                    <label>Jabatan</label>
                    <input type="text" name="jabatan" class="form-control" placeholder="Enter Jabatan .." required>
                </div>                                               
                </div> 

                <div class="col-md-6">
                <div class="form-group">
                    <label>Foto</label>
                    <input type="file" name="foto" class="form-control" required>     
                </div>                                               
                </div> 
                <div class="col-md-6">
                <div class="form-group">
                    <label>Jenis Dosen</label>
                    <select name="jenis" class="form-control">
                        <option value="">-- Jenis Dosen</option>
                        <option value="Dosen Tetap"> Dosen Tetap</option>
                         <option value="Dosen Tarbiyah"> Dosen Honorer</option>
                    </select>
                </div>                                               
                </div>                           
            </div> 
            <div class="row">
                <div class="col-md-6">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Enter Username .." required>
                </div>                                               
                </div> 
                
                <div class="col-md-6">
                <div class="form-group">
                    <label>Password</label>
                    <input type="text" name="password" class="form-control" placeholder="Enter Password.." required>
                </div>                                               
                </div>                           
            </div>           
          </div>
          <div class="modal-footer" style="background-color: #212121;">
            <center>
                <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"> <i class="fa fa-times"></i> TUTUP</button>
                <button type="submit" name="save" class="btn btn-sm btn-success"> <i class="fa fa-save"></i> SIMPAN DATA</button>
            </center>
          </div>
      </form>
        </div>
      </div>
    </div>

<!-- end modal -->


</div>
</div>


