
<?php 
$id = $_GET['id_dsn'];
$i= mysqli_query($con,"DELETE FROM tb_dsn WHERE id_dsn='$id' ");
$ii= mysqli_query($con,"DELETE FROM tb_pa WHERE id_dsn='$id' ");
$iii= mysqli_query($con,"DELETE FROM tb_pembone WHERE id_dsn='$id' ");
$iiii= mysqli_query($con,"DELETE FROM tb_pembtwo WHERE id_dsn='$id' ");
$iiiii= mysqli_query($con,"DELETE FROM tb_pengajuanjudul WHERE id_dsn='$id' ");
$iiiiii= mysqli_query($con,"DELETE FROM tb_peraturan WHERE id_dsn='$id' ");
$iiiiiii= mysqli_query($con,"DELETE FROM tb_pesan WHERE id_penerima='$id' or id_pengirim='$id' ");
$iiiiiiii= mysqli_query($con,"DELETE FROM tb_pesanpembone WHERE id_penerima='$id' or id_pengirim='$id' ");
if ($i||$ii||$iii||$iiii||$iiiii||$iiiiii||$iiiiiii||$iiiiiiii) {
		?>
		<script type='text/javascript'>
		setTimeout(function () {
		swal({
		title: 'DATA TELAH DIHAPUS',
		text:  'Berhasil Menghapus Data !',
		type: 'success',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=dosen');
		} ,3000);   
		</script>
	<?php
}

?>
