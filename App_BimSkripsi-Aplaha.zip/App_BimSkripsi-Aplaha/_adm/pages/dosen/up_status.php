<?php 
$id = $_GET['id'];
$status = $_GET['status'];
if ($status=='Y') {
	$sql1=mysqli_query($con,"UPDATE tb_dsn SET status_akundsn='N' WHERE id_dsn='$id' ");
}else{
	$sql2=mysqli_query($con,"UPDATE tb_dsn SET status_akundsn='Y' WHERE id_dsn='$id' ");
}
if ($sql1 || $sql2) {
	echo "<script>
	window.location='?page=dosen';
</script>";
	
}

 ?>