<?php 
if (isset($_POST['save'])) {
	$nip = $_POST['nip'];
	$nama = $_POST['nama'];
	$jabatan = $_POST['jabatan'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$password1 = $_POST['password'];

	$sumber = @$_FILES['foto']['tmp_name'];
	$target = '../assets/images/';
	$nama_gambar = @$_FILES['foto']['name'];

	$pindah = move_uploaded_file($sumber, $target.$nama_gambar);
	if ($pindah) {
	mysqli_query($con,"INSERT INTO tb_dsn VALUES (NULL,'$nip','$nama','$jabatan','$username','$password','$password1','$nama_gambar','Y','$_POST[jenis]')") or die (mysqli_error($con));
	?>
		<script type='text/javascript'>
		setTimeout(function () {
		swal({
		title: 'DATA TERSIMPAN',
		text:  'Berhasil Menyimpan Data !',
		type: 'success',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=dosen');
		} ,3000);   
		</script>
	<?php
	}
}elseif (isset($_POST['update'])) {
	$id = $_POST['id'];
	$nip = $_POST['nip'];
	$nama = $_POST['nama'];
	$jabatan = $_POST['jabatan'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$password1 = $_POST['password'];

	$gambar = @$_FILES['foto']['name'];
	if (!empty($gambar)) {
		move_uploaded_file($_FILES['foto']['tmp_name'],"../assets/images/$gambar");
		$ganti = mysqli_query($con,"UPDATE tb_dsn SET foto='$gambar' WHERE id_dsn='$id' ");
	}
	mysqli_query($con,"UPDATE tb_dsn SET nip='$nip',nama_dosen='$nama',jabatan='$jabatan',username='$username',password='$password',secondpass='$password1',jenis_dosen='$_POST[jenis]' WHERE id_dsn='$id' ") or die (mysqli_error($con));
	?>
		<script type='text/javascript'>
		setTimeout(function () {
		swal({
		title: 'DATA DIUBAH',
		text:  'Berhasil Mengubah Data !',
		type: 'success',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=dosen');
		} ,3000);   
		</script>
	<?php
}

 ?>