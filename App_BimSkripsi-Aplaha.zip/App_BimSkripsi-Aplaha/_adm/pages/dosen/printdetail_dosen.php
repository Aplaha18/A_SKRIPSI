<!-- 
  <link rel="stylesheet" type="text/css" href="../../../assets/css/vendor.css">
  <link rel="stylesheet" type="text/css" href="../../../assets/css/flat-admin.css"> -->
  <!DOCTYPE html>
  <html>
  <head>
  	  <style>
  	body{
  		font-family: Verdana, Geneva, Tahoma, sans-serif;
  		font-size: 12px;
  	}
  </style>
  </head>
  <body>

<?php 
include '../../../config/databases.php';
$id_dsn = $_GET['id_dsn'];
$dosen = mysqli_query($con,"SELECT * FROM tb_dsn WHERE id_dsn='$id_dsn' ") or die(mysqli_error($con));
foreach ($dosen as $data)?>

<table width="100%" style="text-align: center;">
  <tr>
  <td>
  <img src="../../../assets/images/unibba.png" width="100">
  </td>
    <td>
    <h4 align="center">DETAIL LAPORAN DATA DOSEN PEMBIMBING DAN PENGUJI<br> PROGRAM STUDI TEKNIK INFORMATIKA <br> FAKULTAS TEKNOLOGI INFORMASI <br> UNIVERSITAS BALE BANDUNG <br> BANDUNG</h4>
    </td>
    <td>
      <img src="../../../assets/images/fti.png" width="100">
    </td>
  </tr>
</table>
<hr>




		    			<center><h2><b>PROFILE DOSEN</b></h2><img src="../../../assets/images/<?php echo $data['foto']; ?>" width="100" height="120" style="border-radius: 5px;"></center>

						<table width="100%" style="font-weight: bold;color: black;">
							<tr>
								<td>Nama Dosen</td>
								<td>:</td>
								<td><?php echo $data['nama_dosen']; ?></td>
							</tr>
							<tr>
								<td>NIK</td>
								<td>:</td>
								<td><?php echo $data['nip']; ?></td>
							</tr>
							<tr>
								<td>Jabatan</td>
								<td>:</td>
								<td><?php echo $data['jabatan']; ?></td>
							</tr>
							<tr>
								<td>Status Akun</td>
								<td>:</td>
								<td><?php
								if ($data['status_akundsn']=='Y') {
									echo "<b class='text-success'>Aktif</b>";
								}else{
									echo "<b class='btn btn-danger btn-block btn-xs'>Blokir</b>";
								}
								?></td>
							</tr>
						</table>
		    	<hr style="border: 1px double;">		
		    
		  	<?php
		  	 $cek1 = mysqli_query($con,"SELECT * FROM tb_pembone WHERE id_dsn='$id_dsn'");
		  	 $key = mysqli_fetch_array($cek1);
		  	 	if (empty($key['id_dsn'])) {
		  	 		// echo "<h1>Belum Ada Data !</h1>";
		  	 		?>
					<strong>Oppss!</strong> Belum Ada data mahasiswa Bimbingan I !
		  	 		<?php
		  	 	}else{
		  	 		?>
		  	 		<!-- Tampilkan tabel 1 -->
		  	 		
				  	 <table width="100%" border="1" style="border-collapse: collapse;"  cellpadding="3">
				  		<caption><b> MAHASISWA BIMBINGAN I</b></caption>
				  		<thead>
				  			<tr style="background-color:#ECEFF1;height: 40px;">
				  				<th>No.</th>
				  				<th>NIM</th>
				  				<th>Nama Mahasiswa</th>
				  				<th>Judul Skripsi</th>
				  				<th>Tahun Akt</th>
						  		<th></th>				  				
				  			</tr>
				  		</thead>
				  		<tbody>
							<?php 
							$no=1;
							$pemb1 = mysqli_query($con,"SELECT * FROM tb_pembone
							INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
							INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
							WHERE tb_pembone.id_dsn='$id_dsn'
							") or die(mysqli_error($con));
							foreach ($pemb1 as $mhs) { ?>
				  			<tr>
				  				<td><?php echo $no++; ?>.</td>
				  				<td><?php echo $mhs['nim']; ?></td>
				  				<td><?php echo $mhs['nama']; ?></td>
				  				<td><?php echo $mhs['judul_proposal']; ?></td>
				  				<td align="center"><?php echo $mhs['tahun_angkatan']; ?></td>
				  				<td align="center">
				  					<img src="../../../assets/img-mhs/<?php echo $mhs['fotomhs']; ?>" width="40" height="40" style="border-radius: 100%;">
				  				</td>
				  			</tr>
				  		<?php } ?>
				  		</tbody>
				  	</table>
				 
		  	 		<?php
		  	 	}

		  	 	?>
		  	 	<!-- Pembimbing 2 -->
					<?php
					$cek2 = mysqli_query($con,"SELECT * FROM tb_pembtwo WHERE id_dsn='$id_dsn'");
					$key2 = mysqli_fetch_array($cek2);
					if (empty($key2['id_dsn'])) {
						?>
						<strong>Oppss!</strong> Belum Ada data mahasiswa Bimbingan II !
		  	 		   <?php
					}else{
						?>
						<!-- tampilkan tabel 2 -->
					
							<table width="100%" border="1" style="border-collapse: collapse;"  cellpadding="3">
						  		<caption><b>MAHASISWA BIMBINGAN II</b></caption>
						  		<thead>
						  			<tr style="background-color:#ECEFF1;height: 40px;">
						  				<th>No.</th>
						  				<th>NIM</th>
						  				<th>Nama Mahasiswa</th>
						  				<th>Judul Skripsi</th>	
						  				<th>Tahun Akt</th>
						  				<th></th>					  				
						  			</tr>
						  		</thead>
						  		<tbody>
									<?php 
									$no=1;
									$pemb2 = mysqli_query($con,"SELECT * FROM tb_pembtwo
									INNER JOIN tb_mhs ON tb_pembtwo.id_mhs=tb_mhs.id_mhs
									INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
									WHERE tb_pembtwo.id_dsn='$id_dsn'
									") or die(mysqli_error($con));
									foreach ($pemb2 as $mhs2) { ?>
						  			<tr>
						  				<td><?php echo $no++; ?>.</td>
						  				<td><?php echo $mhs2['nim']; ?></td>
						  				<td><?php echo $mhs2['nama']; ?></td>
						  				<td><?php echo $mhs2['judul_proposal']; ?></td>
						  				<td align="center"><?php echo $mhs2['tahun_angkatan']; ?></td>
						  				<td align="center">
						  					<img src="../../../assets/img-mhs/<?php echo $mhs2['fotomhs']; ?>" width="40" height="40" style="border-radius: 100%;">
						  				</td>
						  			</tr>
						  		<?php } ?>
						  		</tbody>
						  	</table>							
					
						<?php
					}
					?>


					                <br>
<table width="100%">
<!--    <a href="#" class="no-print" onclick="window.print();"> <button style="height: 40px; width: 70px; background-color: dodgerblue;border:none; color: white; border-radius:7px;font-size: 17px; " type=""> Cetak</button> </a> -->
<tr>
<td align="right" colspan="6" rowspan="" headers="">
<p>Bandung, <?php echo date (" d F Y") ?>  <br> <br>
Ketua Jurusan </p> <br> <br> <br>
<p><br>
---------------------------------- </p>
</td>
</tr>
</table>

		  	
		  	
 <script>
 	window.print();
 </script>
  </body>
  </html>