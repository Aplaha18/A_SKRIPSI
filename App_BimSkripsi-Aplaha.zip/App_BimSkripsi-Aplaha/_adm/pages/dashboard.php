<?php 
/// Jumlah mhs
$mhs = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tb_mhs"));
$dsn = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tb_dsn"));
$judul = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE disetujui_kajur='Disetujui' "));


 ?>
<div class="row">
  <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
      <a href="?page=mhs" class="card card-banner card-green-light"style="background-color: #00C853;">
  <div class="card-body">
    <i class="icon fa fa-child fa-4x"style="color: #fff;"></i>
    <div class="content">
      <div class="title"style="color: #fff;">Jumlah Data Mahasiswa</div>
      <div class="value"style="color: #fff;"><span class="sign"></span><?php echo $mhs; ?></div>
    </div>
  </div>
</a>

  </div>
  <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
      <a href="?page=dosen" class="card card-banner card-blue-light" style="background-color: #4DD0E1;">
  <div class="card-body">
    <i class="icon fa fa-user-secret fa-4x" style="color: #fff;"></i>
    <div class="content">
      <div class="title"style="color: #fff;">Jumlah Data Dosen</div>
      <div class="value"style="color: #fff;"><span class="sign"></span><?php echo $dsn; ?></div>
    </div>
  </div>
</a>

  </div>
  <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
      <a href="?page=judul" class="card card-banner card-yellow-light" style="background-color: #FFC107">
  <div class="card-body">
    <i class="icon fa fa-graduation-cap fa-4x"style="color: #fff;"></i>
    <div class="content">
      <div class="title"style="color: #fff;">Jumlah Skripsi</div>
      <div class="value"style="color: #fff;"><span class="sign"></span><?php echo $judul; ?></div>
    </div>
  </div>
</a>

  </div>
</div>