<?php 
error_reporting(0);
ini_set('display_errors',0);
session_start();
if (!isset($_SESSION['admin1'])) {
?> <script>
    alert('Anda Belum Login !!');
    window.location='../loginadm.php';
 </script>
<?php
}
include '../config/databases.php';
 ?>

<!DOCTYPE html>
<html>
<head>
  <title>Selamat Datang - <?php echo $_SESSION['nama']; ?></title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="../assets/css/vendor.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/flat-admin.css">

  <!-- Theme -->
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/blue-sky.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/blue.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/red.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/yellow.css">

 
  <!-- Sweat Alert -->
    <link rel="stylesheet" type="text/css" href="../assets/alert/css/sweetalert.css">
      <script src="../assets/alert/js/jquery-2.1.4.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="../assets/alert/js/sweetalert.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script type="text/javascript" src="../assets/ckeditor/ckeditor.js"></script>
  <!-- grafik -->
  <script src="../assets/grafik/highcharts.js"></script>
<script src="../assets/grafik/exporting.js"></script>
<script src="../assets/grafik/tema.js"></script>


</head>
<body>
<?php
if (@$_SESSION['admin1']) {
$idadm = @$_SESSION['id'];
}

$sql = mysqli_query($con,"SELECT * FROM tb_adm WHERE id='$idadm'") or die(mysqli_error($con));
$data = mysqli_fetch_array($sql);
?>
  <div class="app app-red">
<aside class="app-sidebar" id="sidebar">
  <div class="sidebar-header"style="background-color:#212121;">
    <a class="sidebar-brand" href="#"><span class="highlight"><b>ADMIN</b></span><b style="color: #fff;">Panel</b></a>
    <!-- <img src="../assets/images/ptik.png" width="150"> -->
    <button type="button" class="sidebar-toggle">
      <i class="fa fa-times"></i>
    </button>
  </div>
  <div class="sidebar-menu" style="background-color:#212121;">
    <ul class="sidebar-nav">
      <li class="">
        <a href="index.php">
          <div class="icon">
            <i class="fa fa-home" aria-hidden="true"></i>
          </div>
          <div class="title" style="color:#FAFAFA">Dashboard</div>
        </a>
      </li>

      <li class="dropdown ">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <div class="icon">
            <i class="fa fa-graduation-cap" aria-hidden="true"></i>
          </div>
          <div class="title"style="color:#FAFAFA">Akademik</div>
        </a>
        <div class="dropdown-menu">
          <ul>
            <li class="section"><i class="fa fa-file-o" aria-hidden="true"></i> Data Dosen</li>
            <li><a href="?page=dosen">Managemen Dosen</a></li>
            <li class="line"></li>
            <li class="section"><i class="fa fa-file-o" aria-hidden="true"></i> Data Mahasiswa</li>
            <li><a href="?page=mhs">Manajemen Mahasiswa</a></li>
          </ul>
        </div>
      </li>  

      <li class="">
        <a href="?page=judul">
          <div class="icon">
            <i class="fa fa-file-text" aria-hidden="true"></i>
          </div>
          <div class="title" style="color:#FAFAFA">Judul Skripsi</div>
        </a>
      </li>
    </ul>
  </div>

</aside>

<script type="text/ng-template" id="sidebar-dropdown.tpl.html">
  <div class="dropdown-background">
    <div class="bg"></div>
  </div>
  <div class="dropdown-container">
    {{list}}
  </div>
</script>
<div class="app-container">
  <nav class="navbar navbar-default" id="navbar">
  <div class="container-fluid">
    <div class="navbar-collapse collapse in">
      <ul class="nav navbar-nav navbar-mobile">
        <li>
          <button type="button" class="sidebar-toggle">
            <i class="fa fa-bars"></i>
          </button>
        </li>
        <li class="logo">
          <a class="navbar-brand" href="#"><span class="highlight">c-Panel</span> Admin</a>
        </li>
        <li>
          <button type="button" class="navbar-toggle">
            <img class="profile-img" src="../assets/images/<?php echo $data['img'] ?>">
          </button>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-left">
        <li class="navbar-title">
          <!-- <?php echo date('d F Y'); ?> -->
          <b><img src="../assets/images/fti.png" width="75"> BIMBINGAN SKRIPSI ONLINE </b>
          
        </li>
        <li class="navbar-search hidden-sm" style="color: red;">

        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown notification danger">
        <?php 
        $mhs = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul INNER JOIN tb_mhs ON tb_pengajuanjudul.id_mhs=tb_mhs.id_mhs WHERE disetujui_kajur='Belum Diterima' GROUP BY tb_pengajuanjudul.id_mhs DESC ");
        $jml = mysqli_num_rows($mhs);
        ?>
          
          <div class="dropdown-menu">
            <ul>
             
            </ul>
          </div>
        </li>
        <li class="dropdown profile">
          <a href="/html/pages/profile.html" class="dropdown-toggle"  data-toggle="dropdown">
            <img class="profile-img" src="../assets/images/<?php echo $data['img'] ?>">
            <div class="title">Profile</div>
          </a>
          <div class="dropdown-menu">
            <div class="profile-info">
              <h4 class="username"><?php echo $data['nama_adm'] ?></h4>
            </div>
            <ul class="action">
              <li>
                <a href="?page=profile">
                  Setting Profile
                </a>
              </li>
              <li>
                <a href="logout.php">
                  Logout
                </a>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

  <?php 
  error_reporting();
  $page = $_GET['page'];
  $act= $_GET['act'];
    if ($page=='dosen') {
      if ($act=='') {
        include 'pages/dosen/list_dosen.php';
      }elseif ($act=='proses') {
        include 'pages/dosen/proses.php';
      }elseif ($act=='detail') {
        include 'pages/dosen/detail_dosen.php';
      }elseif ($act=='del') {
        include 'pages/dosen/del_dosen.php';
      }elseif ($act=='get') {
        include 'pages/dosen/up_status.php';
      }
    }elseif ($page=='mhs') {
       if ($act=='') {
         include 'pages/mahasiswa/list_mhs.php';
       }elseif ($act=='detail') {
        include 'pages/mahasiswa/detail_mhs.php';
       }elseif ($act=='get') {
        include 'pages/mahasiswa/up_status.php';
       }elseif ($act=='del') {
         include 'pages/mahasiswa/del_mhs.php';
       }elseif ($act=='proses') {
         include 'pages/mahasiswa/proses.php';
       }elseif ($act=='act') {
         include 'pages/mahasiswa/act.php';
       }
    }elseif ($page=='judul') {
       if ($act=='') {
         include 'pages/judul_skripsi/list_judul.php';
       }elseif ($act=='persetujuan') {
         include 'pages/judul_skripsi/persetujuan_judul.php';
       }
    }elseif ($page=='profile') {
       if ($act=='') {
        include 'pages/profile/profile.php';
       }
    }elseif ($page=='set') {
       if ($act=='') {
        include 'pages/pengaturan/pengaturan_apl.php';
       }
    }elseif ($page=='') {
       include 'homepage.php';
    }else{
     echo "Page Not Found !";
    }

   ?>

  </div>
</div>

  <script type="text/javascript" src="../assets/js/vendor.js"></script>
  <script type="text/javascript" src="../assets/js/app.js"></script>
      <script>
          CKEDITOR.replace('ckedtor1',{
             uiColor:'#FAFAFA',
            filebrowserImageBrowseUrl : 'assets/kcfinder'
        });
        
    </script>


</body>
</html>