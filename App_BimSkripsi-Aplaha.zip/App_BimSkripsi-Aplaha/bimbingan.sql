-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2020 at 08:13 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bimbingan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_adm`
--

CREATE TABLE `tb_adm` (
  `id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama_adm` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_adm`
--

INSERT INTO `tb_adm` (`id`, `username`, `password`, `nama_adm`, `img`, `status`) VALUES
(1, 'adm', 'b09c600fddc573f117449b3723f23d64', 'Yusuf Muharam, S.Kom', '2  - Copy (2).png', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama_admin` varchar(40) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `username`, `password`, `nama_admin`, `img`, `status`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Yaya Suharya, S.Kom, M.T.', '1b.png', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tb_dsn`
--

CREATE TABLE `tb_dsn` (
  `id_dsn` int(11) NOT NULL,
  `nip` varchar(21) NOT NULL,
  `nama_dosen` varchar(50) NOT NULL,
  `jabatan` varchar(30) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(60) NOT NULL,
  `secondpass` varchar(60) NOT NULL,
  `foto` varchar(225) NOT NULL,
  `status_akundsn` varchar(12) NOT NULL,
  `jenis_dosen` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_dsn`
--

INSERT INTO `tb_dsn` (`id_dsn`, `nip`, `nama_dosen`, `jabatan`, `username`, `password`, `secondpass`, `foto`, `status_akundsn`, `jenis_dosen`) VALUES
(1, '04104808008', 'YUDI HERDIANA, S.T, M.T.', 'Dekan', '04104808008', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1.png', 'Y', ''),
(2, '01043170007', 'YAYA SUHARYA, M.T.', 'Ketua Prodi IF', '01043170007', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1A.png', 'Y', 'Dosen Tetap'),
(3, '04104808122', 'ROSMALINA, S.T, M.Kom', 'Ketua Prodi SI', '04104808122', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1b - Copy (3).png', 'Y', 'Dosen Tetap'),
(4, '04104808094', 'DENNY RUSDIANTO, M.KOM', 'Dosen', '04104808094', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1b - Copy (4).png', 'Y', 'Dosen Tetap'),
(5, '01043180002', 'SUTIYONO, M.KOM', 'Dosen', '01043180002', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1b - Copy (5).png', 'Y', 'Dosen Tetap'),
(6, '04104808015', 'RUSTIYANA, M.T', 'Dosen', '04104808015', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1b - Copy (6).png', 'Y', 'Dosen Tetap'),
(7, '0412027905', 'NURUL IMAMAH, S.T., M.T.', 'Dosen', '0412027905', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1b - Copy (7).png', 'Y', 'Dosen Tetap'),
(8, '04022037002', 'ZEN MUNAWAR, S.T, M.T.', 'Dosen', '04022037002', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1b - Copy (8).png', 'Y', 'Dosen Tetap'),
(9, '0413107002', 'IIM ABDURROHIM, S.T.,M.T.', 'Dosen', '0413107002', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1b - Copy (9).png', 'Y', 'Dosen Tetap'),
(10, '04104808007', 'Mochamad Ridwan, S.T.', 'Dosen', '04104808007', '827ccb0eea8a706c4c34a16891f84e7b', '12345', '1.png', 'Y', 'Dosen Tetap');

-- --------------------------------------------------------

--
-- Table structure for table `tb_fileone`
--

CREATE TABLE `tb_fileone` (
  `id_upload` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `nama_file` varchar(100) NOT NULL,
  `tipe_file` varchar(10) NOT NULL,
  `ukuran_file` int(20) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_fileone`
--

INSERT INTO `tb_fileone` (`id_upload`, `id_pesan`, `tanggal_upload`, `nama_file`, `tipe_file`, `ukuran_file`, `file`) VALUES
(1, 2, '2020-08-04', 'cover.pdf', 'pdf', 452111, '../assets/file_pembone/1.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tb_fileskripsi`
--

CREATE TABLE `tb_fileskripsi` (
  `id_file` int(11) NOT NULL,
  `id_mhs` int(11) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  `kode` varchar(225) NOT NULL,
  `nama_file` varchar(225) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `tipe_file` varchar(10) NOT NULL,
  `ukuran_file` varchar(20) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_fileskripsi`
--

INSERT INTO `tb_fileskripsi` (`id_file`, `id_mhs`, `id_pengajuan`, `kode`, `nama_file`, `tanggal_upload`, `tipe_file`, `ukuran_file`, `file`) VALUES
(1, 27, 1, 'M001', 'PROPOSAL SKRIPSI', '2020-08-04', 'pdf', '1147650', '../assets/file_skripsi/M001.pdf'),
(2, 27, 1, 'M002', 'REVISI PROPOSAL', '2020-08-04', 'pdf', '1147650', '../assets/file_skripsi/M002.pdf'),
(3, 27, 1, 'M003', 'BAB I', '2020-08-04', 'pdf', '369830', '../assets/file_skripsi/M003.pdf'),
(4, 27, 1, 'M004', 'BAB II', '2020-08-04', 'pdf', '562784', '../assets/file_skripsi/M004.pdf'),
(5, 27, 1, 'M005', 'BAB III', '2020-08-04', 'pdf', '704317', '../assets/file_skripsi/M005.pdf'),
(6, 27, 1, 'M006', 'BAB IV', '2020-08-04', 'pdf', '188765', '../assets/file_skripsi/M006.pdf'),
(7, 27, 1, 'M007', 'BAB V', '2020-08-04', 'pdf', '545368', '../assets/file_skripsi/M007.pdf'),
(8, 27, 1, 'M008', 'BAB VI', '2020-08-04', 'docx', '22222', '../assets/file_skripsi/M008.docx'),
(9, 27, 1, 'M009', 'BAB I REVISI', '2020-08-04', 'pdf', '369830', '../assets/file_skripsi/M009.pdf'),
(10, 27, 1, 'M010', 'BAB II REVISI', '2020-08-04', 'pdf', '562784', '../assets/file_skripsi/M010.pdf'),
(11, 27, 1, 'M011', 'BAB III REVISI', '2020-08-04', 'pdf', '704317', '../assets/file_skripsi/M011.pdf'),
(12, 27, 1, 'M012', 'BAB IV REVISI', '2020-08-04', 'pdf', '188765', '../assets/file_skripsi/M012.pdf'),
(13, 27, 1, 'M013', 'BAB V REVISI', '2020-08-04', 'pdf', '452111', '../assets/file_skripsi/M013.pdf'),
(14, 27, 1, 'M014', 'BAB VI REVISI', '2020-08-04', 'docx', '22222', '../assets/file_skripsi/M014.docx');

-- --------------------------------------------------------

--
-- Table structure for table `tb_filetwo`
--

CREATE TABLE `tb_filetwo` (
  `id_upload` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `nama_file` varchar(100) NOT NULL,
  `tipe_file` varchar(10) NOT NULL,
  `ukuran_file` int(20) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_filetwo`
--

INSERT INTO `tb_filetwo` (`id_upload`, `id_pesan`, `tanggal_upload`, `nama_file`, `tipe_file`, `ukuran_file`, `file`) VALUES
(1, 2, '2020-08-04', 'cover.pdf', 'pdf', 452111, '../assets/file_pembtwo/1.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tb_mhs`
--

CREATE TABLE `tb_mhs` (
  `id_mhs` int(11) NOT NULL,
  `nim` varchar(12) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(60) NOT NULL,
  `secondpass` varchar(60) NOT NULL,
  `fotomhs` varchar(225) NOT NULL,
  `tahun_angkatan` int(30) NOT NULL,
  `status_akun` varchar(12) NOT NULL,
  `status_skripsi` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_mhs`
--

INSERT INTO `tb_mhs` (`id_mhs`, `nim`, `nama`, `username`, `password`, `secondpass`, `fotomhs`, `tahun_angkatan`, `status_akun`, `status_skripsi`) VALUES
(1, '311170026', 'MOHAMAD FIRTIYADI', '311170026', '202cb962ac59075b964b07152d234b70', '123', '2 .png', 2017, 'Y', 'N'),
(2, 'C1A160053', 'MUHAMAD HANIF R', 'C1A160053', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (2).png', 2016, 'Y', 'N'),
(3, 'C1A160051', 'ILHAM MUHAJIRIN', 'C1A160051', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (3).png', 2016, 'Y', 'N'),
(4, 'C1A160043', 'ROYNA NASRULLOH', 'C1A160043', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (4).png', 2016, 'Y', 'N'),
(5, 'C1A160040', 'RIVAL MAULANA YUSUP', 'C1A160040', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (5).png', 2016, 'Y', 'N'),
(6, 'C1A160035', 'MULYADI', 'C1A160035', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (6).png', 2016, 'Y', 'N'),
(7, 'C1A160034', 'AKBAR TAWAKAL PANCANANDITA', 'C1A160034', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (7).png', 2016, 'Y', 'N'),
(8, 'C1A160033', 'FITRI ASYSYIFA', 'C1A160033', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (8).png', 2016, 'Y', 'N'),
(9, 'C1A160032', 'GILANG RAMADAN', 'C1A160032', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (9).png', 2016, 'Y', 'N'),
(10, 'C1A160029', 'M JAMIL ZAINU NOOR', 'C1A160029', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (10).png', 2016, 'Y', 'N'),
(11, 'C1A160028', 'MOCH ILHAM BAHARI', 'C1A160028', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (11).png', 2016, 'Y', 'N'),
(12, 'C1A160027', 'MOCH DENNIS SUGIRI', 'C1A160027', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (12).png', 2016, 'Y', 'N'),
(13, 'C1A160021', 'IKBAL NAUBAH RAMDANI', 'C1A160021', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (13).png', 2016, 'Y', 'N'),
(14, 'C1A160018', 'RIVAN RAMDANI', 'C1A160018', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (14).png', 2016, 'Y', 'N'),
(15, 'C1A160017', 'SANDI SOPIAN', 'C1A160017', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (15).png', 2016, 'Y', 'N'),
(16, 'C1A160016', 'CHANDRA RIZKI AZHARI', 'C1A160016', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (16).png', 2016, 'Y', 'N'),
(17, 'C1A160015', 'SABDA ALAM', 'C1A160015', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (17).png', 2016, 'Y', 'N'),
(18, 'C1A160014', 'FAHMI KURNIAWAN', 'C1A160014', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (18).png', 2016, 'Y', 'N'),
(19, 'C1A160013', 'AHMAD KAMAL FASYA', 'C1A160013', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (19).png', 2016, 'Y', 'N'),
(20, 'C1A160012', 'YOGASWARA RABBANI', 'C1A160012', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (20).png', 2016, 'Y', 'N'),
(21, 'C1A160011', 'JIHAN PUJIANA', 'C1A160011', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (21).png', 2016, 'Y', 'N'),
(22, 'C1A160010', 'MOHAMMAD BAYU ANGGARA', 'C1A160010', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (22).png', 2016, 'Y', 'N'),
(23, 'C1A160009', 'GALIH REXY HAKIKI', 'C1A160009', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (23).png', 2016, 'Y', 'N'),
(24, 'C1A160006', 'ABDUL AZIZ', 'C1A160006', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (24).png', 2016, 'Y', 'N'),
(25, 'C1A160005', 'DIKA HADIJAYA', 'C1A160005', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (25).png', 2016, 'Y', 'N'),
(26, 'C1A160004', 'JAKA PERYOGA TRISWARA', 'C1A160004', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (26).png', 2016, 'Y', 'N'),
(27, 'C1A160003', 'APLAHA IQBAL NURSALAM', 'C1A160003', '202cb962ac59075b964b07152d234b70', '123', '2  - Copy (27).png', 2016, 'Y', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pa`
--

CREATE TABLE `tb_pa` (
  `id_pa` int(11) NOT NULL,
  `id_mhs` int(11) NOT NULL,
  `id_dsn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pa`
--

INSERT INTO `tb_pa` (`id_pa`, `id_mhs`, `id_dsn`) VALUES
(1, 27, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembone`
--

CREATE TABLE `tb_pembone` (
  `id_pembone` int(11) NOT NULL,
  `id_mhs` int(11) NOT NULL,
  `id_dsn` int(11) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  `tgl_penetapan_one` date NOT NULL,
  `ket_one` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pembone`
--

INSERT INTO `tb_pembone` (`id_pembone`, `id_mhs`, `id_dsn`, `id_pengajuan`, `tgl_penetapan_one`, `ket_one`) VALUES
(1, 27, 1, 1, '2020-08-04', 'Bersedia');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembtwo`
--

CREATE TABLE `tb_pembtwo` (
  `id_pembtwo` int(11) NOT NULL,
  `id_mhs` int(11) NOT NULL,
  `id_dsn` int(11) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  `tgl_penetapan_two` date NOT NULL,
  `ket_two` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pembtwo`
--

INSERT INTO `tb_pembtwo` (`id_pembtwo`, `id_mhs`, `id_dsn`, `id_pengajuan`, `tgl_penetapan_two`, `ket_two`) VALUES
(1, 27, 10, 1, '2020-08-04', 'Bersedia');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pengajuanjudul`
--

CREATE TABLE `tb_pengajuanjudul` (
  `id_pengajuan` int(11) NOT NULL,
  `id_mhs` int(11) NOT NULL,
  `id_dsn` int(11) NOT NULL,
  `judul_proposal` text NOT NULL,
  `masalah` text NOT NULL,
  `tgl_pengajuan` date NOT NULL,
  `status_proposal` varchar(15) NOT NULL,
  `tgl_rekomendasi` date NOT NULL,
  `disetujui_kajur` varchar(15) NOT NULL,
  `tgl_acc` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pengajuanjudul`
--

INSERT INTO `tb_pengajuanjudul` (`id_pengajuan`, `id_mhs`, `id_dsn`, `judul_proposal`, `masalah`, `tgl_pengajuan`, `status_proposal`, `tgl_rekomendasi`, `disetujui_kajur`, `tgl_acc`) VALUES
(1, 27, 6, 'MEMBUAT APLIKASI BIMBINGAN SKRIPSI ONLINE UNTUK EFEKTIVITAS BIMBINGAN SKRIPSI (STUDI KASUS PRODI TEKNIK INFORMATIKA FTI UNIBBA)', '<p>1. Bagaimana mahasiswa bisa cepat menemukan data skripsi yang sudah pernah dibuat supaya judul yang diusulkan tidak memiliki persamaan dengan judul skripsi sebelumnya ?</p>\r\n\r\n<p>2. Bagaimana mahasiswa bisa mengetahui bahwa judul yang diajukan telah disetujui oleh ketua prodi tanpa perlu ke kampus ?</p>\r\n\r\n<p>3. Bagaimana komunikasi mahasiswa dengan pembimbing bisa berjalan baik untuk menyesuaikan waktu bimbingan ?</p>\r\n', '2020-08-04', 'Belum Dibaca', '0000-00-00', 'Disetujui', '2020-08-04');

-- --------------------------------------------------------

--
-- Table structure for table `tb_peraturan`
--

CREATE TABLE `tb_peraturan` (
  `id_peraturan` int(11) NOT NULL,
  `id_dsn` int(11) NOT NULL,
  `isi_peraturan` text NOT NULL,
  `tgl_set` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesan`
--

CREATE TABLE `tb_pesan` (
  `id_pesan` int(11) NOT NULL,
  `id_penerima` int(11) NOT NULL,
  `id_pengirim` int(11) NOT NULL,
  `subyek` text NOT NULL,
  `isi_pesan` text NOT NULL,
  `tgl_pesan` date NOT NULL,
  `status_pesan` varchar(15) NOT NULL,
  `id_pembtwo` int(11) NOT NULL,
  `id_file` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pesan`
--

INSERT INTO `tb_pesan` (`id_pesan`, `id_penerima`, `id_pengirim`, `subyek`, `isi_pesan`, `tgl_pesan`, `status_pesan`, `id_pembtwo`, `id_file`) VALUES
(1, 10, 27, 'PROPOSAL SKRIPSI', 'Berikut proposal skripsi yang saya buat.', '2020-08-04', 'sudah', 1, 1),
(2, 27, 10, 'REVISI PROPOSAL', 'Silahkan revisi kembali proposal khusus nya pada bab 3', '2020-08-04', 'sudah', 1, 1),
(3, 10, 27, 'REVISI PROPOSAL SKRIPSI', '', '2020-08-04', 'sudah', 1, 1),
(4, 10, 27, 'BAB I', '', '2020-08-04', 'sudah', 1, 1),
(5, 27, 10, 'REVISI BAB I', 'Perbaiki pada tujuan masalah dan batasan masalah', '2020-08-04', 'sudah', 1, 0),
(6, 10, 27, 'REVISI BAB II', 'Berikut update revisi pada bab 2', '2020-08-04', 'sudah', 1, 0),
(7, 10, 27, 'BAB II', '', '2020-08-04', 'sudah', 1, 0),
(8, 10, 27, 'BAB III', '', '2020-08-04', 'sudah', 1, 0),
(9, 27, 10, 'REVISI BAB III', 'Revisi pada bagian kerangka piker sesuaikan dengan metodologi penelitian', '2020-08-04', 'belum', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesanpembone`
--

CREATE TABLE `tb_pesanpembone` (
  `id_pesan` int(11) NOT NULL,
  `id_penerima` int(11) NOT NULL,
  `id_pengirim` int(11) NOT NULL,
  `subyek` text NOT NULL,
  `isi_pesan` text NOT NULL,
  `tgl_pesan` date NOT NULL,
  `status_pesan` varchar(15) NOT NULL,
  `id_pembone` int(11) NOT NULL,
  `id_file` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pesanpembone`
--

INSERT INTO `tb_pesanpembone` (`id_pesan`, `id_penerima`, `id_pengirim`, `subyek`, `isi_pesan`, `tgl_pesan`, `status_pesan`, `id_pembone`, `id_file`) VALUES
(1, 1, 27, 'PROPOSAL SKRIPSI', 'Berikut Proposal skripsi yang saya buat.', '2020-08-04', 'sudah', 1, 1),
(2, 27, 1, 'Revisi Proposal', 'Revisi pada bab 1 dan 2 yah', '2020-08-04', 'sudah', 1, 1),
(3, 1, 27, 'REVISI PROPOSAL SKRIPSI', 'Berikut file proposal yang sudah di revisi ', '2020-08-04', 'sudah', 1, 1),
(4, 1, 27, 'BAB I', '', '2020-08-04', 'sudah', 1, 3),
(5, 27, 1, 'REVISI BAB I', '', '2020-08-04', 'sudah', 1, 0),
(6, 1, 27, 'REVISI BAB I', '', '2020-08-04', 'sudah', 1, 0),
(7, 1, 27, 'BAB II', 'Berikut Bab 2 yang sudah dibuat', '2020-08-04', 'sudah', 1, 4),
(8, 27, 1, 'REVISI BAB II', 'Perbaiki pada tinjauan pustaka nya dan lanjut pada bab 3', '2020-08-04', 'sudah', 1, 0),
(9, 1, 27, 'BAB III', 'berikut bab 3 yang dibuat', '2020-08-04', 'sudah', 1, 0),
(10, 27, 1, 'REVISI BAB III', 'Silahkan revisi pada metodologi penelitian', '2020-08-04', 'sudah', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_adm`
--
ALTER TABLE `tb_adm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_dsn`
--
ALTER TABLE `tb_dsn`
  ADD PRIMARY KEY (`id_dsn`);

--
-- Indexes for table `tb_fileone`
--
ALTER TABLE `tb_fileone`
  ADD PRIMARY KEY (`id_upload`);

--
-- Indexes for table `tb_fileskripsi`
--
ALTER TABLE `tb_fileskripsi`
  ADD PRIMARY KEY (`id_file`),
  ADD KEY `id_mhs` (`id_mhs`),
  ADD KEY `id_pengajuan` (`id_pengajuan`),
  ADD KEY `id_pengajuan_2` (`id_pengajuan`);

--
-- Indexes for table `tb_filetwo`
--
ALTER TABLE `tb_filetwo`
  ADD PRIMARY KEY (`id_upload`);

--
-- Indexes for table `tb_mhs`
--
ALTER TABLE `tb_mhs`
  ADD PRIMARY KEY (`id_mhs`);

--
-- Indexes for table `tb_pa`
--
ALTER TABLE `tb_pa`
  ADD PRIMARY KEY (`id_pa`),
  ADD KEY `id_mhs` (`id_mhs`),
  ADD KEY `id_dsn` (`id_dsn`);

--
-- Indexes for table `tb_pembone`
--
ALTER TABLE `tb_pembone`
  ADD PRIMARY KEY (`id_pembone`),
  ADD KEY `id_mhs` (`id_mhs`),
  ADD KEY `id_dsn` (`id_dsn`),
  ADD KEY `id_pengajuan` (`id_pengajuan`);

--
-- Indexes for table `tb_pembtwo`
--
ALTER TABLE `tb_pembtwo`
  ADD PRIMARY KEY (`id_pembtwo`),
  ADD KEY `id_mhs` (`id_mhs`,`id_dsn`,`id_pengajuan`),
  ADD KEY `id_dsn` (`id_dsn`);

--
-- Indexes for table `tb_pengajuanjudul`
--
ALTER TABLE `tb_pengajuanjudul`
  ADD PRIMARY KEY (`id_pengajuan`);

--
-- Indexes for table `tb_peraturan`
--
ALTER TABLE `tb_peraturan`
  ADD PRIMARY KEY (`id_peraturan`),
  ADD KEY `id_dsn` (`id_dsn`);

--
-- Indexes for table `tb_pesan`
--
ALTER TABLE `tb_pesan`
  ADD PRIMARY KEY (`id_pesan`),
  ADD KEY `id_file` (`id_file`),
  ADD KEY `id_pembtwo` (`id_pembtwo`);

--
-- Indexes for table `tb_pesanpembone`
--
ALTER TABLE `tb_pesanpembone`
  ADD PRIMARY KEY (`id_pesan`),
  ADD KEY `id_file` (`id_file`),
  ADD KEY `id_pembone` (`id_pembone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_adm`
--
ALTER TABLE `tb_adm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_dsn`
--
ALTER TABLE `tb_dsn`
  MODIFY `id_dsn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tb_fileone`
--
ALTER TABLE `tb_fileone`
  MODIFY `id_upload` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_fileskripsi`
--
ALTER TABLE `tb_fileskripsi`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_filetwo`
--
ALTER TABLE `tb_filetwo`
  MODIFY `id_upload` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_mhs`
--
ALTER TABLE `tb_mhs`
  MODIFY `id_mhs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tb_pa`
--
ALTER TABLE `tb_pa`
  MODIFY `id_pa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_pembone`
--
ALTER TABLE `tb_pembone`
  MODIFY `id_pembone` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_pembtwo`
--
ALTER TABLE `tb_pembtwo`
  MODIFY `id_pembtwo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_pengajuanjudul`
--
ALTER TABLE `tb_pengajuanjudul`
  MODIFY `id_pengajuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_peraturan`
--
ALTER TABLE `tb_peraturan`
  MODIFY `id_peraturan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_pesan`
--
ALTER TABLE `tb_pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_pesanpembone`
--
ALTER TABLE `tb_pesanpembone`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
