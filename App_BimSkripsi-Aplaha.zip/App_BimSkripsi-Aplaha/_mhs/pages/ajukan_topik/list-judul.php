<div class="row">
<div class="col-sm-12 col-xs-12">
    <a href="javascript:history.back()" class="btn btn-danger"> <i class="fa fa-chevron-left"></i> Kembali </a>
    <a href="?page=stepone&act=intopik" class="btn btn-info"> <i class="fa fa-plus"></i> Tambah Topik Baru </a>
    <a href="cetak/kartu-pengajuanjudul.php?id=<?php echo $data['id_mhs']; ?>" target="_blank" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Kartu Pengajuan Judul </a>
      <div class="card">
        <div class="card-header" style="background-color: #E91E63;color: #fff;">
          <i class="fa fa-file-o"></i> Daftar Judul Saya
        </div>
        <div class="card-body">
            <div class="section-body">
              <div class="step">
    <ul class="nav nav-tabs nav-justified" role="tablist">
     <!--    <li role="step">
            <a href="#step1" id="step1-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">
                <div class="icon fa fa-file-o"></div>
                <div class="heading">
                    <div class="title">Shipping</div>
                    <div class="description">Enter your address</div>
                </div>
            </a>
        </li> -->
        <li role="step" class="active">
            <a href="#step2" role="tab" id="step2-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-file-o"></div>
                <div class="heading">
                    <div class="title">Daftar Judul Yang Diajukan</div>
                    <div class="description">Daftar Judul Yang Diajukan</div>
                </div>
            </a>
        </li>
        <li role="step">
            <a href="#step3" role="tab" id="step3-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-check" style="color:#03A9F4;"></div>
                <div class="heading">
                    <div class="title">Direkomendasi Dosen Wali</div>
                    <div class="description">Daftar Judul Direkomendasi Dosen Wali</div>
                </div>
            </a>
        </li>
        <li role="step">
            <a href="#step4" role="tab" id="step4-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-check" style="color: red;"></div>
                <div class="heading">
                    <div class="title">Disetujui KAPRODI</div>
                    <div class="description">Judul Yang Disetujui KAPRODI</div>
                </div>
            </a>
        </li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane" id="step1">
            <b>Step1</b> : Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel
        </div>
        <div role="tabpanel" class="tab-pane active" id="step2">
         <!--    <b>Step2</b>
            <hr> -->
               <table class="table table-condensed table-striped">
                      <thead>
                        <tr>
                          <th>No.</th>
                          <th>Tanggal Pengajuan</th>
                          <th>Judul Proposal</th>
                          <th>Status Proposal</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $no=1; 
                        $query= mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' ");
                        while ($row= mysqli_fetch_array($query)) { ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo date('d F Y',strtotime($row['tgl_pengajuan'])); ?></td>
                          <td><?php echo $row['judul_proposal']; ?></td>
                          <td><?php echo $row['status_proposal']; ?></td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>
        </div>
        <div role="tabpanel" class="tab-pane" id="step3">
            <!-- <b>Step3</b>  -->
            <!-- DIREKOMENDASI OLEH PA -->
              <table class="table table-condensed table-striped">
                      <thead>
                        <tr>
                          <th>No.</th>
                          <th>Tanggal Pengajuan</th>
                          <th>Judul Proposal</th>
                          <th>Status Proposal</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $no=1; 
                        $query= mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' AND status_proposal='Rekomendasi' ");
                        while ($row= mysqli_fetch_array($query)) { ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo date('d F Y',strtotime($row['tgl_pengajuan'])); ?></td>
                          <td><?php echo $row['judul_proposal']; ?></td>
                          <td><?php echo $row['status_proposal']; ?></td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>
        </div>
        <div role="tabpanel" class="tab-pane" id="step4">
            <!-- REKOMENDASI OLEH KAJUR -->

             <?php 
          $result = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' AND disetujui_kajur='Disetujui' ");
          $judulnyo = mysqli_fetch_array($result);
          if ($judulnyo['disetujui_kajur']=='Disetujui') {
        ?>
          <div class="alert alert-warning alert-dismissible fade in" role="alert" style="border: 3px double;">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
              <center>
              <b>SELAMAT ! <br>
             Judul
             </b>
              <h4 id="oh-snap!-you-got-an-error!">"<b><?php echo $judulnyo['judul_proposal']; ?></b>"</h4>
              <b>Telah "<?php echo $judulnyo['disetujui_kajur']; ?>" Pada Tanggal <?php echo date('d F Y',strtotime($judulnyo['tgl_acc'])); ?>  </b>
              <hr style="border:1px dashed brown;"> 
              </center>
              <?php 
              $pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
              INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
              WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
              $pemb2=mysqli_fetch_array($pb2);
             if (empty($pemb2['id_pembtwo'])) {
               echo " <center> Saat Ini Dosen Pembimbing 1 dan Dosen Pembimbing 2 Anda Belum Dipilh, Tunggu Informasi Selanjutnya ..</center>";
             }else{
              ?>
               <?php 
            $pb1=mysqli_query($con, "SELECT * FROM tb_pembone
            INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
            WHERE tb_pembone.id_mhs='$data[id_mhs]' ");
            $pemb=mysqli_fetch_array($pb1);
            ?>

            <?php 
              $pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
              INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
              WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
              $pemb2=mysqli_fetch_array($pb2);
              ?>

              <table class="table table-condensed table-hover" style="background-color: #FAFAFA;">
            <tr>
              <td colspan="2" align="center"><b>PEMBIMBING I </b></td>
              <td colspan="2" align="center"><b>PEMBIMBING II </b></td>
            </tr>
            <tr>
              <td colspan="2" align="center">
                <?php
                if (empty($pemb['foto'])) {
                  
                }else{
                  ?>
                  <img class="img-thumbnail" src="../assets/images/<?php echo $pemb['foto'] ?>" width="80" height="80">
                  <?php
                }
                ?>
                
              </td>
              <td colspan="2" align="center">
                  <?php
                if (empty($pemb2['foto'])) {
                  
                }else{
                  ?>
                  <img class="img-thumbnail" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="80" height="80">
                  <?php
                }
                ?>
                </td>
            </tr>
            <!-- 1 -->
          
            <tr>
              <td>Nama Dosen </td>
              <td><?php echo $pemb['nama_dosen']; ?></td>
              <td>Nama Dosen </td>
              <td><?php echo $pemb2['nama_dosen']; ?></td>
            </tr>
            <tr>
              <td>NIK</td>
              <td><?php echo $pemb['nip']; ?></td>
              <td>NIK</td>
              <td><?php echo $pemb2['nip']; ?></td>
            </tr>
            <tr>
              <td>Jabatan</td>
              <td><?php echo $pemb['jabatan']; ?></td>
              <td>Jabatan</td>
              <td><?php echo $pemb2['jabatan']; ?></td>
            </tr>
              <tr>
              <td>Persetujuan</td>
              <?php
              if ($pemb['ket_one']=='Belum Konfir') {
               echo '<td class="label label-danger">Belum Konfirmasi</td>';
              }else{
                ?>
                <td><b class="btn btn-success">Bersedia </b> <a href="" class="btn btn-primary"><i class="fa fa-print"></i> Cetak</a></td>
                <?php
              
              }
              ?>
              

              <td>Persetujuan</td>
              <!-- <td class="label label-danger"><?php echo $pemb2['ket_two']; ?></td> -->
                 <?php
              if ($pemb2['ket_two']=='Belum Konfir') {
               echo '<td class="label label-danger">Belum Konfirmasi</td>';
              }else{
                 ?>
                <td><b class="btn btn-success">Bersedia </b> <a href="" class="btn btn-primary"><i class="fa fa-print"></i> Cetak</a></td>
                <?php
              }
              ?>
            </tr>
          </table>
       

<hr>
<p>
  Perhatian ! <br>
  - Harap Cetak Surat Kesediaan Pembimbing 1 dan Pembimbing 2 Sebagai Bukti / Arsip <br>
  - Harap diberi Stempel dan Tanda Tangan Ketua Jurusan Pada Masing-masing Surat .

</p>



              <?php
             }
              ?>



          </div>
        <?php
        }
        ?>


       <!--        <table class="table table-condensed table-striped">
                      <thead>
                        <tr>
                          <th>No.</th>
                          <th>Tanggal Pengajuan</th>
                          <th>Judul Proposal</th>
                          <th>Status Proposal</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $no=1; 
                        $query= mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' AND disetujui_kajur='Disetujui' ");
                        while ($row= mysqli_fetch_array($query)) { ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo date('d F Y',strtotime($row['tgl_pengajuan'])); ?></td>
                          <td><?php echo $row['judul_proposal']; ?></td>
                          <td><?php echo $row['status_proposal']; ?></td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table> -->
        </div>
    </div>
</div>
            </div>
          </div>
        </div>
      </div>
 </div>

