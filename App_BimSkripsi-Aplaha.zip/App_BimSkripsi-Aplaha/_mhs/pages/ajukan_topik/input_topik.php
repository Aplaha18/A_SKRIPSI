
<?php 
$pa = mysqli_query($con,"SELECT * FROM tb_pa
INNER JOIN tb_mhs ON tb_pa.id_mhs=tb_mhs.id_mhs
INNER JOIN tb_dsn ON tb_pa.id_dsn=tb_dsn.id_dsn WHERE tb_pa.id_mhs='$data[id_mhs]' ");
$dosen_pa = mysqli_fetch_array($pa);
if ($dosen_pa['id_dsn']=='') {
	// Jika Dosen WALI Belum dipilih Tampilkan pesan ini ...

echo "
<script type='text/javascript'>
setTimeout(function () {
swal({
title: 'ANDA BELUM MEMILIH DOSEN WALI',
text:  'Pengajuan Topik Tidak Bisa dilanjutkan ..',
type: 'error',
timer: 3000,
showConfirmButton: true
});     
},10);  
window.setTimeout(function(){ 
window.location.replace('index.php');
} ,3000);   
</script>";


}else{
	?>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
				<div class="card-title">Form Pengajuan Masalah</div>
          <ul class="card-action">
         <!--  	<?php $cek =mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' ");
			$judulnya = mysqli_fetch_array($cek);
			$num_row = mysqli_num_rows($cek); ?> -->
            <li class="dropdown">
				<a href="?page=stepone&act=listjudul" class="btn btn-primary"> <i class="fa fa-file-o"></i> DAFTAR JUDUL SAYA </a>
				<a href="#" class="btn btn-default" style="background-color: #E91E63;"> <!-- <i class="fa fa-file-o"></i>  -->JUMLAH JUDUL SAYA (<?php echo $num_row; ?>) </a>


            </li>
          </ul>
				</div>
				<div class="card-body">
				 <form action="?page=stepone" method="POST" accept-charset="utf-8">
					<div class="row">
						<div class="col-md-12">
							<p>Isilah Form dibawah ini untuk mengusulkan topik/judul proposal anda !</p>
							<label>JUDUL PROPOSAL</label>
							<input type="hidden" name="id_mhs" value="<?php echo $data['id_mhs'] ?>">
							<input type="hidden" name="id_dsn" value="<?php echo $dosen_pa['id_dsn'] ?>">
							<input type="text" name="judul" class="form-control" placeholder="Masukkan Judul Proposal disini .." required>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<label>POKOK MASALAH</label>
							<textarea name="masalah" id="ckedtor1" rows="3" class="form-control" required></textarea>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-md-12">					
							<center>
								<button type="submit" name="ajukan" class="btn btn-success btn-lg"> <i class="fa fa-check"></i> Ajukan Judul</button>
								<a href="javascript:history.back();" class="btn btn-danger btn-lg"> <i class="fa fa-times"></i> Batal</a>
							</center>
						</div>
					</div>
				</form>
				<div>
				
			</div>
		</div>
	</div>



	<?php
}

?>