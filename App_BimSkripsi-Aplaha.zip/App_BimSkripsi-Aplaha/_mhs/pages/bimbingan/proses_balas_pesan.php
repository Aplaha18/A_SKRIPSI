<?php 
if (isset($_POST['balas_pesan'])) {
$id_mhs= $_POST['id_mhs'];
$id_dsn= $_POST['id_dsn'];
$subyek= $_POST['subyek']; 
$isi_pesan= $_POST['isi_pesan'];
$tanggal= date('Y-m-d'); 
$id_pembtwo= $_POST['id_pembtwo'];

$isi = mysqli_query($con, "INSERT INTO tb_pesan VALUES(NULL,'$id_mhs','$id_dsn','Re: $subyek','$isi_pesan','$tanggal', 'belum','$id_pembtwo')");
if ($isi) {
$pesan = "Pesan Terkirim ....";
}

}

?>