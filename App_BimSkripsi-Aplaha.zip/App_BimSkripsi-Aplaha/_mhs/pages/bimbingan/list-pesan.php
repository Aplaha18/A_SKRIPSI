
<?php 
$id_dsn = $_GET['id_dsn'];
// $pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
// INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
// WHERE tb_pembtwo.id_dsn='$id_dsn' ");
// $pemb2=mysqli_fetch_array($pb2);
?>
<?php 
$pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
$pemb2=mysqli_fetch_array($pb2);
 ?>

  
<div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body app-heading">
            <?php
            if (empty($pemb2['foto'])) {
            }else{
            ?>
            <img class="profile-img" src="../assets/images/<?php echo $pemb2['foto'] ?>">
            <?php
            }
            ?>
          <div class="app-title">
            <div class="title">
              <small>Pembimbing II</small> <br><span class="highlight"><?php echo $pemb2['nama_dosen'] ?></span></div>
            <div class="description">NIK.<?php echo $pemb2['nip'] ?></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-5">
      <div class="card" style="overflow:scroll;height:700px;">
        <div class="card-body">
          <p>
            <h4>
              <b><i class="fa fa-envelope-o"></i></b> Kontak Masuk
            </h4>
          </p>
          <a href="javascript:history.back()" class="btn btn-warning"><i class="fa fa-chevron-left"></i> Kembali</a>
          <a data-toggle="modal" data-target="#myModal" class="btn btn-success"><i class="fa fa-envelope-o"></i> Kirim Pesan</a> 
          <p></p>
        <?php
        $query_daftar_pesan = mysqli_query($con,"SELECT * FROM tb_pesan WHERE id_pengirim='$pemb2[id_dsn]' AND id_penerima='$data[id_mhs]'
        ORDER BY id_pesan DESC
        ");
        while ($daftar_pesan=mysqli_fetch_array($query_daftar_pesan)) {
        if($daftar_pesan['status_pesan']=="belum"){
        ?>
  <!-- Tampilkan pesan yg belum dibuka -->
        <div class="list-group">
         <p> <h4><i class="fa fa-envelope-o"></i> Pesan Baru</h4> </p>
          <a href="?page=two&act=bukapesan&id_pesan=<?php echo $daftar_pesan['id_pesan']; ?>" class="list-group-item" style="background-color: #E91E63;color: #fff;">
          <img class="profile-img" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="40" height="40" style="border-radius: 100%; border:1px solid;"> <?php echo $pemb2['nama_dosen']; ?> - <em>Belum Dibaca</em> : "<b><?php echo $daftar_pesan['subyek']; ?></b>" - Dikirim <em><?php echo date('d F Y', strtotime( $daftar_pesan['tgl_pesan'])); ?></em>
          </a>
        </div>  


  <?php } 
      else if($daftar_pesan['status_pesan']=="sudah"){
  ?>
        <div class="list-group" style="border: 1px dashed red;">
        <a href="?page=two&act=bukapesan&id_pesan=<?php echo $daftar_pesan['id_pesan']; ?>" class="list-group-item">
        <img class="profile-img" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="40" height="40" style="border-radius: 100%; border:1px solid;"> <?php echo $pemb2['nama_dosen']; ?> -<!--  <em>Belum Dibaca</em> : --> "<b><?php echo $daftar_pesan['subyek']; ?></b>" - Dikirim <em><?php echo date('d F Y', strtotime( $daftar_pesan['tgl_pesan'])); ?></em>
        </a>
        </div>

  <?php 
      } 
    }
  ?>
</div>
</div>




  </div>


  <!-- Modal kirim pesan -->


  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Kepada <b>Pembimbing II</b> <br>
              <?php
            if (empty($pemb2['foto'])) {
            }else{
            ?>
            <img class="profile-img" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="50" height="50" style="border-radius: 100%;border:1px;">
            <strong><?php echo $pemb2['nama_dosen']; ?></strong>
           
            <?php
            }
            ?></h4>
          </div>
             <form action="" method="POST">
          <div class="modal-body">
 
    <!-- id tersembunyi -->
    <input type="hidden" name="id_mhs" value="<?php echo $data['id_mhs']; ?>"> 
    <input type="hidden" name="id_dsn" value="<?php echo $pemb2['id_dsn']; ?>">
    <input type="hidden" name="id_pembtwo" value="<?php echo $pemb2['id_pembtwo']; ?>">
    <!-- End id tersembunyi -->
<!-- 
  <img class="profile-img" src="../assets/img-mhs/<?php echo $data['foto'] ?>" width="50" height="50" style="border-radius: 100%;border:1px;"> <em><b><?php echo $data['nama'] ?></b> </em> [<em><?php echo date('d F Y') ?> </em>]
  <br> -->

    <input type="text" name="subyek" class="form-control" placeholder="Masukkan Subyek Pesan ...">
    <textarea name="isi_pesan" cols="30" rows="5" class="form-control" placeholder="Ketikkan Isi Pesan disini .."></textarea>
    <label>

  
</label> 
    <!-- <input type="submit" name="balas_pesan" value="KIRIM PESAN" class="btn btn-success"> -->
    <!-- <a id="ke_balas_pesan" href="#" class="btn btn-primary btn-block">Balas Pesan</a> -->

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"> <i class="fa fa-times"></i> Batal</button>
            <button type="submit" name="balas_pesan" class="btn btn-sm btn-success"><i class="fa fa-envelope-o"></i> Kirim Pesan</button>
          </div>
            </form>
                    <?php 
        if (isset($_POST['balas_pesan'])) {
        $id_pengirim= $_POST['id_mhs'];
        $id_penerima= $_POST['id_dsn'];
        $subyek= $_POST['subyek']; 
        $isi_pesan= $_POST['isi_pesan'];
        $tanggal= date('Y-m-d'); 
        $id_pembtwo= $_POST['id_pembtwo'];

        $isi = mysqli_query($con, "INSERT INTO tb_pesan VALUES(NULL,'$id_penerima','$id_pengirim','Re: $subyek','$isi_pesan','$tanggal', 'belum','$id_pembtwo')");
        if ($isi) {
        echo "<b class='text-danger'><h4>Pesan Sukses Terkirim Kepada $pemb2[nama_dosen]</h4> </b>";
        }

        }

        ?>
        </div>
      </div>
    </div>