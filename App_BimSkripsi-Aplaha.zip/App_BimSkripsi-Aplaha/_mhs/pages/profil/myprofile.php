<div class="row">
	<div class="col-lg-4 col-md-4 col-md-12 col-xs-12 col-lg-offset-3">
		<div class="card">
			<div class="card-body">				
				<form action="" method="POST" enctype="multipart/form-data">
					<center>
					<h4>Ubah Data Profil</h4>
				</center>
				
				<div class="form-group">
					<label>NIM</label>
					<input type="text" name="nim" class="form-control" value="<?php echo $data['nim'] ?>" disabled>	
					<input type="hidden" name="id" class="form-control" value="<?php echo $data['id_mhs'] ?>">				
				</div>
				<div class="form-group">
					<label>Nama Lengkap</label>
					<input type="text" name="nama" class="form-control" value="<?php echo $data['nama'] ?>">				
				</div>
				<div class="form-group">
					<label>Username</label>
					<input type="text" name="username" class="form-control" value="<?php echo $data['username'] ?>">				
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="text" name="password" class="form-control" value="<?php echo $data['secondpass'] ?>">				
				</div>
				<div class="form-group">
					<label>Foto Profile</label>
					<input type="file" name="foto" class="form-control">				
				</div>
				<div class="form-group">
					<button type="submit" name="set" class="btn btn-primary"><i class="fa fa-pencil"></i> Update</button>
					<a href="javascript:history.back()" class="btn btn-danger"><i class="fa fa-times"></i> Batal</a>				
				</div>
				</form>	
				<?php
				if (isset($_POST['set'])) {
				$id = $_POST['id'];
				$nama = $_POST['nama'];
				$username = $_POST['username'];
				$password = md5($_POST['password']);
				$second = $_POST['password'];
				$tahun = $_POST['tahun_angkatan'];
				$gambar = @$_FILES['foto']['name'];
				if (!empty($gambar)) {
				move_uploaded_file($_FILES['foto']['tmp_name'],"../assets/img-mhs/$gambar");
				$ganti = mysqli_query($con,"UPDATE tb_mhs SET fotomhs='$gambar' WHERE id_mhs='$id' ");
				}
				mysqli_query($con,"UPDATE tb_mhs SET nama='$nama',username='$username',password='$password',secondpass='$second',tahun_angkatan='$tahun' WHERE id_mhs='$id' ") or die (mysqli_error($con));
				?>
				<script type='text/javascript'>
				setTimeout(function () {
				swal({
				title: 'DATA DIUBAH',
				text:  'Berhasil Mengubah Data !',
				type: 'success',
				timer: 3000,
				showConfirmButton: true
				});     
				},10);  
				window.setTimeout(function(){ 
				window.location.replace('index.php');
				} ,3000);   
				</script>
				<?php
				}
				  ?>							
			</div>						
		</div>			
	</div>	
</div>