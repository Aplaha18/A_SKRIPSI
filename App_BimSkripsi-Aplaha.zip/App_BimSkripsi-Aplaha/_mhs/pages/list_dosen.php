<div class="row">
<!-- <div class="col-xs-12">

</div> -->
<h4></h4>
<div class="col-xs-12">

      <div class="card">
        <div class="card-header">
         <h3> <a href="index.php" class="btn btn-danger btn-xs"> <i class="fa fa-chevron-left"></i> Kembali</a>&nbsp;  <b>Manajemen Dosen</b></h3>
        </div>
        <div class="card-body no-padding">
            <table class="datatable table table-striped primary" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Foto</th>
                        <th>NIP</th>
                        <th>Nama Dosen</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no= 1;
                     $mhs = mysqli_query($con,"SELECT * FROM tb_dsn ORDER BY id_dsn ASC ") or die(mysqli_error($con)) ;
                        while ($data= mysqli_fetch_array($mhs)) { ?>
                   
                    <tr>
                    <a href="?page=bimbingan&act=riwayat2&id_mhs=<?php echo $data['id_mhs'];?> ">
                        <td><b><?php echo $no++; ?>.</b></td>
                        <th>
                            <img src="../assets/images/<?php echo $data['foto']; ?>" width="40" height="40" class="img-circle">
                        </th>
                        <td><?php echo $data['nip']; ?></td>
                        <td><?php echo $data['nama_dosen']; ?></td>
                        <td><?php echo $data['jabatan']; ?></td>
                        <td>
                            <?php if ($data['status_akundsn']=='Y') {
                            echo "<b class='label label-success'>Aktif</b> ";
                        }else{
                            echo "<b class='label label-danger'>Blokir</b> ";
                        }
                        ?></td>
                        <td>
                            <center>
                            <a href="?page=dosen&act=detail&id_dsn=<?php echo $data['id_dsn'];?> " class="btn btn-primary btn-xs"> <i class="fa fa-search-plus"></i> Selengkapnya</a>
                            </center>
                            </div>
                            </form>
                            </div>
                            </div>
                            </div>
                         </a>
                    </tr>                 
                <?php } ?>
                </tbody>
            </table>
        </div>
      </div>

</div>
</div>


