
<!-- Pembimbing 2 -->
<?php 
$pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
$pemb2=mysqli_fetch_array($pb2);
?>
<!-- end pembimbing 2 -->
<!-- Pembimbing 2 -->
<?php 
$pb1=mysqli_query($con, "SELECT * FROM tb_pembone
INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
WHERE tb_pembone.id_mhs='$data[id_mhs]' ");
$pemb1=mysqli_fetch_array($pb1);
?>
<!-- end pembimbing 2 -->

<div class="row">
<div class="col-md-12 col-sm-12">
  <div class="card">
    <div class="card-header">
        <div class="card-title"><h4><b>Kartu Bimbingan</b></h4></div>
        <!-- border-left:4px solid;border-right:4px solid; -->
        <div style="padding: 5px;border-radius: 5px;box-shadow: 0 0 18px #D0D0D0;">
        <a href="cetak/printKartuBimbingan.php?data=<?php echo $data['id_mhs']; ?>" target="_blank" class="btn btn-default btn-xs"><i class="fa fa-file-o"></i> Cetak Kartu Bimbingan</a>
        <a href="cetak/kartu-pengajuanjudul.php?id=<?php echo $data['id_mhs']; ?>" target="_blank" class="btn btn-primary btn-xs"> <i class="fa fa-print"></i> Cetak Kartu Pengajuan Judul </a>
        
          
        </div>
      </div>

    <div class="card-body" style="overflow:scroll;height:400px;">
      
        <table class="table-bordered" width="100%">
            <tr>
              <td rowspan="2">NO</td>
              <td rowspan="2">Hari/Tanggal</td>
              <td><div align="center">Hal Yang Dikonsultasi </div></td>
              <td rowspan="2">Keterangan</td>
            </tr>
            <tr>
              <td><div align="center"><b>Pembimbing I</b> </div></td>
            </tr>
          <!-- pembimbing 1 -->
            <?php 
            $no=1;
            $satu = mysqli_query($con,"SELECT * FROM tb_pesanpembone WHERE id_pembone='$pemb1[id_pembone]' ") or die(mysqli_error($con));
            while ($d= mysqli_fetch_array($satu)) { ?>
            <tr>
              <td><?php echo $no++; ?>.</td>
              <td><?php echo $d['tgl_pesan']; ?></td>
              <td><?php echo $d['subyek']; ?></td>
              <td><?php echo $d['isi_pesan']; ?></td>
            </tr>
          <?php } ?>
          <tr>
              <td rowspan="2">NO</td>
              <td rowspan="2">Hari/Tanggal</td>
              <td><div align="center">Hal Yang Dikonsultasi </div></td>
              <td rowspan="2">Keterangan</td>
            </tr>
            <tr>
              <td><div align="center"><b>Pembimbing II</b></div></td>
            </tr>
            <!-- pembimbing 2 -->
            <?php 
            $no=1;
            $dua = mysqli_query($con,"SELECT * FROM tb_pesan WHERE id_pembtwo='$pemb2[id_pembtwo]' ") or die(mysqli_error($con));
            while ($d= mysqli_fetch_array($dua)) { ?>
            <tr>
              <td><?php echo $no++; ?>.</td>
              <td><?php echo $d['tgl_pesan']; ?></td>
              <td><?php echo $d['subyek']; ?></td>
              <td><?php echo $d['isi_pesan']; ?></td>
            </tr>
          <?php } ?>

        </table>
      
    </div>
    
  </div>

</div>
</div>
