<?php 
$id_dsn = $_GET['id_dsn'];
$dosen = mysqli_query($con,"SELECT * FROM tb_dsn WHERE id_dsn='$id_dsn' ") or die(mysqli_error($con));
foreach ($dosen as $data)?>
<div class="row">
	<div class="col-md-12">
		<div class="card">
		  <div class="card-header">
          <h3><a href="javascript:history.back()" class="btn btn-danger btn-xs"> <i class="fa fa-chevron-left"></i> Kembali</a></h3>
        </div>
		    <div class="card-title">
		    	
		    	<div class="row">
		    		<div class="col-md-2" align="right">
		    			<center><h4><b>PROFILE DOSEN</b></h4>
		    	<img src="../assets/images/<?php echo $data['foto']; ?>" width="130" height="150" class="img-thumbnail">
		    </center>
		    		</div>	
		    		<div class="col-md-5">
		    			<!-- <hr> -->
		    			<br>
		    			<br>
						<table class="table" style="font-weight: bold;color: black;">
							<tr>
								<td>Nama Dosen</td>
								<td>:</td>
								<td><?php echo $data['nama_dosen']; ?></td>
							</tr>
							<tr>
								<td>Nip</td>
								<td>:</td>
								<td><?php echo $data['nip']; ?></td>
							</tr>
							<tr>
								<td>Jabatan</td>
								<td>:</td>
								<td><?php echo $data['jabatan']; ?></td>
							</tr>
							<tr>
								<td>Status Akun</td>
								<td>:</td>
								<td><?php
								if ($data['status_akundsn']=='Y') {
									echo "<b class='text-success'>Aktif</b>";
								}else{
									echo "<b class='btn btn-danger btn-block btn-xs'>Blokir</b>";
								}
								?></td>
							</tr>
						</table>
		    				    			
		    		</div>		    		
		    	</div>
		    </div>
		    
		  </div>
		  <div class="card-body">
		  	<?php
		  	 $cek1 = mysqli_query($con,"SELECT * FROM tb_pembone WHERE id_dsn='$id_dsn'");
		  	 $key = mysqli_fetch_array($cek1);
		  	 	if (empty($key['id_dsn'])) {
		  	 		// echo "<h1>Belum Ada Data !</h1>";
		  	 		?>
						<div class="alert alert-danger alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<strong>Oppss!</strong> Belum Ada data mahasiswa Bimbingan I !
						</div>
		  	 		<?php
		  	 	}else{
		  	 		?>
		  	 		<!-- Tampilkan tabel 1 -->
		  	 		<div class="table-responsive">
				  	 <table class="table table-condensed table-striped table-hover">
				  		<caption><b><i class="fa fa-chevron-right"></i> MAHASISWA BIMBINGAN I</b></caption>
				  		<thead style="background-color:#40C4FF;color: #fff;">
				  			<tr>
				  				<th>No.</th>
				  				<th>Nim</th>
				  				<th>Nama Mahasiswa</th>
				  				<th>Judul Skripsi</th>
				  				<th></th>
				  			</tr>
				  		</thead>
				  		<tbody>
							<?php 
							$no=1;
							$pemb1 = mysqli_query($con,"SELECT * FROM tb_pembone
							INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
							INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
							WHERE tb_pembone.id_dsn='$id_dsn'
							") or die(mysqli_error($con));
							foreach ($pemb1 as $mhs) { ?>
				  			<tr>
				  				<td><?php echo $no++; ?>.</td>
				  				<td><?php echo $mhs['nim']; ?></td>
				  				<td><?php echo $mhs['nama']; ?></td>
				  				<td><?php echo $mhs['judul_proposal']; ?></td>
				  				<td><img src="../assets/img-mhs/<?php echo $mhs['fotomhs']; ?>" width="40" height="40" class="img-circle"></td>
				  			</tr>
				  		<?php } ?>
				  		</tbody>
				  	</table>
				  </div>
		  	 		<?php
		  	 	}

		  	 	?>
		  	 	<!-- Pembimbing 2 -->
					<?php
					$cek2 = mysqli_query($con,"SELECT * FROM tb_pembtwo WHERE id_dsn='$id_dsn'");
					$key2 = mysqli_fetch_array($cek2);
					if (empty($key2['id_dsn'])) {
						?>
						<div class="alert alert-danger alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<strong>Oppss!</strong> Belum Ada data mahasiswa Bimbingan II !
						</div>
		  	 		<?php
					}else{
						?>
						<!-- tampilkan tabel 2 -->
						<div class="table-responsive">
							<table class="table table-condensed table-striped table-hover">
						  		<caption><b><i class="fa fa-chevron-right"></i> MAHASISWA BIMBINGAN II</b></caption>
						  		<thead style="background-color:#40C4FF;color: #fff;">
						  			<tr>
						  				<th>No.</th>
						  				<th>Nim</th>
						  				<th>Nama Mahasiswa</th>
						  				<th>Judul Skripsi</th>
						  				<th></th>
						  			</tr>
						  		</thead>
						  		<tbody>
									<?php 
									$no=1;
									$pemb2 = mysqli_query($con,"SELECT * FROM tb_pembtwo
									INNER JOIN tb_mhs ON tb_pembtwo.id_mhs=tb_mhs.id_mhs
									INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
									WHERE tb_pembtwo.id_dsn='$id_dsn'
									") or die(mysqli_error($con));
									foreach ($pemb2 as $mhs2) { ?>
						  			<tr>
						  				<td><?php echo $no++; ?>.</td>
						  				<td><?php echo $mhs2['nim']; ?></td>
						  				<td><?php echo $mhs2['nama']; ?></td>
						  				<td><?php echo $mhs2['judul_proposal']; ?></td>
						  				<td><img src="../assets/img-mhs/<?php echo $mhs2['fotomhs']; ?>" width="40" height="40" class="img-circle"></td>
						  			</tr>
						  		<?php } ?>
						  		</tbody>
						  	</table>							
					   </div>
						<?php
					}
					?>

		  	
		  	
		  </div>
		</div>
	</div>	
</div>
