<?php 
$pb2=mysqli_query($con, "SELECT * FROM tb_pembone
INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
WHERE tb_pembone.id_mhs='$data[id_mhs]' ");
$pemb2=mysqli_fetch_array($pb2);
?>

<?php
// $id_mhs=$_GET['id_mhs'];
$id_pesan = $_GET['id_pesan'];
$query_buka_pesan = mysqli_query($con, "SELECT * FROM tb_pesanpembone
    WHERE id_pesan='$id_pesan' AND id_pengirim='$pemb2[id_dsn]' ");
$buka=mysqli_fetch_array($query_buka_pesan);

?>
<?php $sudah_dibaca = mysqli_query($con, "UPDATE tb_pesanpembone SET status_pesan='sudah' WHERE id_pesan=$id_pesan"); ?>
<div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body app-heading">
            <?php
            if (empty($pemb2['foto'])) {
            }else{
            ?>
            <img class="profile-img" src="../assets/images/<?php echo $pemb2['foto'] ?>">
            <?php
            }
            ?>
          <div class="app-title">
            <div class="title">
              <small>Pembimbing I</small> <br><span class="highlight"><?php echo $pemb2['nama_dosen'] ?></span></div>
            <div class="description">NIK.<?php echo $pemb2['nip'] ?></div>
          </div>
        </div>
      </div>
 


</div>

	<div class="col-md-12">
		<div class="card">
	        <div class="card-body">
	        	  
		<div class="list-group">
				<span class="list-group-item" style="background-color: #E91E63;color: #fff;">
					<h4 class="list-group-item-heading">
					<?php
						if (empty($pemb2['foto'])) {
						}else{
						?>
						<img class="profile-img" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="50" height="50" style="border-radius: 100%;border:1px;">
						Pembimbing II <em><strong><?php echo $pemb2['nama_dosen']; ?></strong></em>

						<?php
						}
					?></h4>
					<p class="list-group-item-text">
						.
					<span class="pull-right">Dikirim Tanggal [<em><?php echo date('d F Y',strtotime($buka['tgl_pesan'])); ?></em>]</span> </p>
				</span>
				<span class="list-group-item">
					<h4 class="list-group-item-heading">
					Pembahsan: <strong><?php echo $buka['subyek']; ?></strong>
					</h4>
					<p><i class="fa fa-envelope"></i> Pesan</p>
					<h4>
						<!--  style="border: 1px solid;padding: 7px;border-radius: 7px;background-color: #FAFAFA;" -->
					<p class="list-group-item-text">
					<code style="color: black;"><?php echo $buka['isi_pesan']; ?></code>
					</p>
					</h4>
					 	<p>
						<?php
						 $lampiran = mysqli_query($con,"SELECT * FROM tb_fileone WHERE id_pesan=$id_pesan ");
						 $link = mysqli_fetch_array($lampiran);
						 ?>
						 <b>File : </b> <?php 
						 	if (empty($link)) {
						 		echo "<h4>Tidak Ada File Yang Dilampirkan</h4>";
						 	}else{
						 		?>
						 		<a href="<?php echo $link['file'] ?>" class="btn btn-success" target="_blank"> <i class="fa fa-download"></i> Download File</a>
						 		<?php
						 	}
						  ?>
						
					</p>
				</span>
			</div>
			<div class="list-group">
			<span class="list-group-item" style="background-color:#8BC34A;color: #fff;">
				<h4 class="list-group-item-heading">
					<img class="profile-img" src="../assets/img-mhs/<?php echo $data['fotomhs'] ?>" width="50" height="50" style="border-radius: 100%;border:1px;"> Anda <em><b><?php echo $data['nama'] ?></b> </em>
				</h4>
				<p class="list-group-item-text">
					.
				<span class="pull-right"> [<em><?php echo date('d F Y') ?></em>]</span> </p>
			</span>
			<span class="list-group-item">
				<h4><em>Balas Pesan</em></h4>
					<form action="" method="POST">
						<!-- id tersembunyi -->
						<input type="hidden" name="id_mhs" value="<?php echo $data['id_mhs']; ?>"> 
						<input type="hidden" name="id_dsn" value="<?php echo $pemb2['id_dsn']; ?>">
						<input type="hidden" name="id_pembone" value="<?php echo $pemb2['id_pembone']; ?>">
						<input type="hidden" name="id_file" value="<?php echo $buka['id_file']; ?>">
						<!-- End id tersembunyi -->
					<input type="text" name="subyek" class="form-control" placeholder="Masukkan Subyek Pesan ...">
						<textarea name="isi_pesan" cols="30" rows="5" class="form-control" placeholder="Ketikkan Isi Pesan disini .."></textarea>
						<!-- 	<div class="alert alert-success alert-dismissible" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<strong>Warning!</strong> Better check yourself, you're not looking too good.
							</div> -->
								<?php 
						if (isset($_POST['balas_pesan'])) {
						$id_pengirim= $_POST['id_mhs'];
						$id_penerima= $_POST['id_dsn'];
						$subyek= $_POST['subyek']; 
						$isi_pesan= $_POST['isi_pesan'];
						$tanggal= date('Y-m-d'); 
						$id_pembone= $_POST['id_pembone'];
						$id_file= $_POST['id_file'];

						$isi = mysqli_query($con, "INSERT INTO tb_pesanpembone VALUES(NULL,'$id_penerima','$id_pengirim','$subyek','$isi_pesan','$tanggal', 'belum','$id_pembone','$id_file')");
						if ($isi) {
							?>
							<div class="alert alert-success alert-dismissible" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<strong>PESAN TERKIRIM!</strong> Pesan Sukses Terkirim Kepada <?php echo $pemb2[nama_dosen] ?>
							</div>
							<?php
						
						}

						}

						?>

						<input type="submit" name="balas_pesan" value="KIRIM PESAN" class="btn btn-primary">
						<a href="javascript:history.back()" class="btn btn-danger"><i class="fa fa-chevron-left"></i> Batal</a>
					</form>

			</span>
			
			

		</div>

	


		</div>
		
		</div>
		</div>	
	</div>
	</div>







	


