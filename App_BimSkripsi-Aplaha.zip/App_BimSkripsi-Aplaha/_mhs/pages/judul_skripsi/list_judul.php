<div class="row">
<!-- <div class="col-xs-12">
<a href="" class="btn btn-danger"> <i class="fa fa-chevron-left"></i> Kembali</a>
<a data-toggle="modal" data-target="#modalTambah" class="btn btn-primary"> <i class="fa fa-plus"></i> Tambah Dosen</a>
</div> -->
<div class="col-xs-12">

      <div class="card">
        <div class="card-header">
          <h3><a href="javascript:history.back()" class="btn btn-danger btn-xs"> <i class="fa fa-chevron-left"></i> Kembali</a> &nbsp; <b> Judul Skripsi Mahasiswa</b></h3>
        </div>
        <div class="card-body no-padding">
            <table class="datatable table table-striped primary table-hover" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Judul Skripsi</th>
                        <th>Tahun</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no= 1;
                     $judul = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE disetujui_kajur='Disetujui' ORDER BY id_pengajuan DESC ") or die (mysqli_error($con)) ;
                     foreach ($judul as $data) { ?>                   
                    <tr>
                        <td><b><?php echo $no++; ?>.</b></td>
                        <td> <a href="?page=mhs&act=detail&id_mhs=<?php echo $data['id_mhs'];?>"><b><?php echo $data['judul_proposal']; ?></b></a></td>
                        <td><?php echo date('Y',strtotime($data['tgl_acc'])); ?></td>
                        <td>
                            <a href="?page=mhs&act=detail&id_mhs=<?php echo $data['id_mhs'];?>" class="btn btn-primary btn-xs"> <i class="fa fa-pencil"></i> Selengkapnya</a>
                        </td>
                    </tr>                 
                <?php } ?>

                </tbody>
            </table>
        </div>
      </div>




</div>
</div>