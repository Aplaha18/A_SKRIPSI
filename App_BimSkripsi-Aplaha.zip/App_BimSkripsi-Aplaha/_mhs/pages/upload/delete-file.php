<?php 
$id = $_GET['id'];
$result = mysqli_query($con,"SELECT kode,tipe_file FROM tb_fileskripsi WHERE id_file='$id'");
$row = mysqli_fetch_array($result);
if (file_exists("../assets/file_skripsi/".$row['kode'].'.'.$row['tipe_file'])) {
	unlink("../assets/file_skripsi/".$row['kode'].'.'.$row['tipe_file']);
	mysqli_query($con,"DELETE FROM tb_fileskripsi WHERE id_file='$id' ");
	?>
		<script type='text/javascript'>
		setTimeout(function () {
		swal({
		title: 'FILE TERHAPUS',
		text:  'File Berhasil di Hapus Dari Direktori .. !',
		type: 'success',
		timer: 3000,
		showConfirmButton: true
		});     
		},10);  
		window.setTimeout(function(){ 
		window.location.replace('?page=upload');
		} ,3000);   
		</script>
	<?php


}



 ?>
