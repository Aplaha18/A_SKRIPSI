 <div class="row">
    <div class="col-md-12">
      <div class="alert alert-warning alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>Penting!</strong>

             <ol>
               <li>File yang di Upload adalah file Skripsi yang akan di konsultasikan bersama dosen pembimbing</li>
               <li>File Upload Max 2 MB</li>
               <li>Upload File Menjadi 1 File 1 BAB</li>
               <li>Tipe File : doc, docx, xls, xlsx, ppt, pptx, pdf, rar, zip</li>
               <li>Usahakan File tipe PDF agar mudah dan jelas dibaca oleh Dosen Karena akan langsung ditampilkan di halaman konsultasi</li>
             </ol>
              </div>
      <div class="card">
        <div class="card-header">
          <div class="card-title">
            
            <h4><i class="fa fa-upload"></i> Upload File Skripsi</h4>
          </div>

        <!--   <ul class="card-action">
            <li class="dropdown">
              <a href="/" class="dropdown-toggle" data-toggle="dropdown" style="font-size: 23px;color: red;">
                <i class="fa fa-file-pdf-o" aria-hidden="true"></i> DAFTAR FILE
              </a>
              <ul class="dropdown-menu">
                <li><a href="#" style="font-size: 33px;color: red;"><i class="fa fa-file-pdf-o"></i> Daftar File</a></li>
              </ul>
            </li>
          </ul> -->
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-4" style="border-right: 2px solid;">
              <?php 
              $sk = mysqli_query($con,"SELECT id_pengajuan FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' AND disetujui_kajur='Disetujui' ");
              $ds = mysqli_fetch_array($sk);
               ?>
              <?php 

              $carikode = mysqli_query($con,"select max(kode) from tb_fileskripsi") or die(mysql_error());
              $datakode = mysqli_fetch_array($carikode);
              if ($datakode) {
              $nilaikode = substr($datakode[0], 1);
              $kode = (int) $nilaikode;
              $kode = $kode + 1;
              $hasilkode= "M" .str_pad($kode, 3, "0", STR_PAD_LEFT);
              } else{
              $hasilkode = "M001";
              }
              ?>
              <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                
                <label>BAB SKRIPSI</label>
                    <input type="hidden" name="kodefile" class="form-control" value="<?php echo $hasilkode;?>">  
                      <input type="text" name="nama_file" class="form-control" placeholder="Contoh : BAB I,Abstrak">  
                     <input type="hidden" name="id_mhs" value="<?php echo $data['id_mhs'] ?>">
                     <input type="hidden" name="id_pengajuan" value="<?php echo $ds['id_pengajuan'] ?>">
                </div>
                <div class="form-group">
                <label>Upload File</label>
                    <input type="file" name="file" class="form-control">   

                </div>
                <div class="form-group">
                    <button type="submit" name="upload" class="btn btn-primary"> <i class="fa fa-upload"></i> Upload File </button>
                    <a href="javascript:history.back()" class="btn btn-danger"> <i class="fa fa-chevron-left"></i> Batal </a>             
                </div>
              </form>
<?php
//fungsi untuk mengkonversi size file
function formatBytes($bytes, $precision = 2) { 
$units = array('B', 'KB', 'MB', 'GB', 'TB');
$bytes = max($bytes, 0); 
$pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
$pow = min($pow, count($units) - 1);
$bytes /= pow(1024, $pow);
return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

if(isset($_POST['upload'])){
$allowed_ext  = array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'rar', 'zip');
$file_name    = $_FILES['file']['name'];
@$file_ext     = strtolower(end(explode('.',$file_name)));
$file_size    = $_FILES['file']['size'];
$file_tmp     = $_FILES['file']['tmp_name'];

$id_mhs       = $_POST['id_mhs'];
$id_pengajuan = $_POST['id_pengajuan'];
$kodefile   = $_POST['kodefile'];
$nama_file   = $_POST['nama_file'];
$tgl          = date("Y-m-d");


if(in_array($file_ext, $allowed_ext) === true){
if($file_size < 3044070){
$lokasi = '../assets/file_skripsi/'.$kodefile.'.'.$file_ext;
move_uploaded_file($file_tmp, $lokasi);

$in = mysqli_query($con,"INSERT INTO tb_fileskripsi VALUES(NULL,'$id_mhs','$id_pengajuan','$kodefile','$nama_file','$tgl','$file_ext', '$file_size', '$lokasi')");
if($in){
echo "
<script type='text/javascript'>
setTimeout(function () {
swal({
title: 'UPLOAD SUKSES',
text:  'File Berhasil di Upload !',
type: 'success',
timer: 3000,
showConfirmButton: true
});     
},10);  
window.setTimeout(function(){ 
window.location.replace('?page=upload');
} ,3000);   
</script>";
}else{
echo '<div class="error">ERROR: Gagal upload file!</div>';
}
}else{
echo '<div class="error">ERROR: Besar ukuran file (file size) maksimal 1 Mb!</div>';
}
}else{
echo '<div class="error">ERROR: Ekstensi file tidak di izinkan!</div>';
}
}

?> 



            </div> 
            <div class="col-md-8">

              <div class="table-responsive">
                <table class="table table-striped table-hover">
                 <thead>
                   <tr>
                     <th>No.</th>
                     <!-- <th>Tanggal Upload</th> -->
                     <th>Bab Skripsi</th>
                     <th>Tipe File</th>
                     <th></th>
                   </tr>
                 </thead>
                 <tbody>
                  <?php 
                  $no=1;
                  $file = mysqli_query($con,"SELECT * FROM tb_fileskripsi WHERE id_mhs='$data[id_mhs]' ")or die(mysql_error($con));
                  while ($data= mysqli_fetch_array($file)) { ?>
                   <tr>
                     <td><?php echo $no++; ?>.</td>
                     <!-- <td><?php echo date('d F Y',strtotime($data['tanggal_upload'])); ?></td> -->
                     <td>
                      <!-- <?php echo $data['kode']; ?>  --><?php echo $data['nama_file']; ?></td>
                     <td>
                     
                        <a href="<?php echo $data['file']; ?>" target="_blank" class="btn btn-primary btn-xs">
                        <?php
                      if ($data['tipe_file']=='doc') {
                       echo "<i class='fa fa-file-word-o'></i> ".$data['tipe_file'];
                      }elseif ($data['tipe_file']=='docx') {
                        echo "<i class='fa fa-file-word-o'></i> ".$data['tipe_file'];
                      }elseif ($data['tipe_file']=='xls') {
                        echo "<i class='fa fa-file-excel-o'></i> ".$data['tipe_file'];
                      }elseif ($data['tipe_file']=='xlsx') {
                        echo "<i class='fa fa-file-excel-o'></i> ".$data['tipe_file'];
                      }elseif ($data['tipe_file']=='ppt') {
                        echo "<i class='fa fa-file-powerpoint-o'></i> ".$data['tipe_file'];
                      }elseif ($data['tipe_file']=='pptx') {
                        echo "<i class='fa fa-file-powerpoint-o'></i> ".$data['tipe_file'];
                      }elseif ($data['tipe_file']=='pdf') {
                        echo "<i class='fa fa-file-pdf-o'></i> ".$data['tipe_file'];
                      }elseif ($data['tipe_file']=='rar') {
                        echo "<i class='fa fa-file-archive-o'></i>";
                      }elseif ($data['tipe_file']=='zip') {
                        echo "<i class='fa fa-file-zip-o'></i> ".$data['tipe_file'];
                      }                  
                       ?></a>
                         
                       </td>
                     <td>
                       <a href="<?php echo $data['file']; ?>" class="btn btn-success btn-xs" target="_blank"><i class="fa fa-download"></i> </a>
                       <!-- <a href="" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> </a> -->
                       <a href="?page=upload&act=del&id=<?php echo $data['id_file']; ?> " class="btn btn-danger btn-xs" onclick="return confirm('Yakain Akan Hapus File !!')"  ><i class="fa fa-trash"></i> </a>
                     </td>
                   </tr>
                 <?php } ?>
                 </tbody>
               </table>                 
               </div> 
            </div>            
          </div>
        </div>
      </div>
    </div>
  </div>
