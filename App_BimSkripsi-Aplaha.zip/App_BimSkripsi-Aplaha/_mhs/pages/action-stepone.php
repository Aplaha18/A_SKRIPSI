		<?php 

		if (isset($_POST['ajukan'])) {
			$cek =mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' ");
			$judulnya = mysqli_fetch_array($cek);
			$num_row = mysqli_num_rows($cek);			

			$id_mhs = $_POST['id_mhs'];
			$id_dsn = $_POST['id_dsn'];
			$judul = $_POST['judul'];
			$masalah = $_POST['masalah'];
			$tgl_pengajuan = date('Y-m-d');
			$cekjudul =mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE judul_proposal='$judul' ");
			$tampil = mysqli_fetch_array($cekjudul);		
			$cekdulu = $tampil['judul_proposal'];
			if ($cekdulu==$judul) {
					echo "
					<script type='text/javascript'>
					setTimeout(function () {
					swal({
					title: 'JUDUL SERUPA SUDAH ADA',
					text:  '..[ $cekdulu ] ..',

					type: 'error',
					timer: 4000,
					showConfirmButton: true
					});     
					},10);  
					window.setTimeout(function(){ 
					window.location.replace('?page=stepone&act=intopik');
					} ,4000);   
					</script>";
			}
			elseif($num_row>=3) {
				echo "
						<script type='text/javascript'>
						setTimeout(function () {
						swal({
						title: 'MAAF .. GAGAL !!',
						text:  'Anda Telah Mengusulkan 3 Topik, Silahkan Tunggu Rekomendasi Dosen Wali ..',
						type: 'error',
						timer: 3000,
						showConfirmButton: true
						});     
						},10);  
						window.setTimeout(function(){ 
						window.location.replace('?page=stepone&act=listjudul');
						} ,3000);   
						</script>";
			}else{
					mysqli_query($con,"INSERT INTO tb_pengajuanjudul VALUES (NULL,'$id_mhs','$id_dsn','$judul','$masalah','$tgl_pengajuan','Belum Dibaca','0000-00-00','Belum Diterima','0000-00-00')");

						echo "
						<script type='text/javascript'>
						setTimeout(function () {
						swal({
								imageUrl: 'thumbs-up.png',
						title: 'SUKSES',
						text:  'Berhasil Mengusulkan Judul ..',
						type: 'success',
						timer: 3000,
						showConfirmButton: true
						});     
						},10);  
						window.setTimeout(function(){ 
						window.location.replace('?page=stepone&act=listjudul');
						} ,3000);   
						</script>";
			}


            
		}

		 ?>
