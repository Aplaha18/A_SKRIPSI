   <div class="row">
     <!-- Tabs -->
    <div class="col-sm-12 col-xs-12">
      <div class="card">
     <!--    <div class="card-header">
          Tab & Step
        </div> -->
        <div class="card-body">
            <div class="section-body">
              <div class="step">
    <ul class="nav nav-tabs nav-justified" role="tablist">
        <li role="step" class="active">
            <a href="#step2" role="tab" id="step2-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-home"></div>
                <div class="heading">
                    <div class="title">Informasi Utama</div>
                    <div class="description">Informasi Utama</div>
                </div>
            </a>
        </li>
        <li role="step">
            <a href="#step4" role="tab" id="step4-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-user-plus "></div>
                <div class="heading">
                    <div class="title">Dosen Pembimbing</div>
                    <div class="description">Informasi Dosen Pembimbing & Cetak Kartu Kesediaan Jadi Pembimbbing</div>
                </div>
            </a>
        </li>
        <!-- <li role="step">
            <a href="#step3" role="tab" id="step3-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-file-o"></div>
                <div class="heading">
                    <div class="title">Riwayat Pengajuan Judul</div>
                    <div class="description">Mahasiswa Bimbingan</div>
                </div>
            </a>
        </li> -->
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="step2">
            <div class="row">
              <div class="col-md-6">
                <!-- PEMBIMBING 1 -->
                    <?php 
                    $pb2=mysqli_query($con, "SELECT * FROM tb_pembone
                    INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
                    WHERE tb_pembone.id_mhs='$data[id_mhs]' ");
                    $pemb2=mysqli_fetch_array($pb2);
                    ?>
                    <?php $pesan_baru=mysqli_query($con, "SELECT * FROM tb_pesanpembone WHERE id_pengirim='$pemb2[id_dsn]' AND id_penerima='$data[id_mhs]' and status_pesan='belum'");
                    $jumlah_pesan_baru=mysqli_num_rows($pesan_baru); ?>
                      <?php 
                      if($jumlah_pesan_baru==0){
                      // echo "Tidak Ada Pesan Baru (0)";
                      }else if($jumlah_pesan_baru > 0){
                      ?>
                      <a href="?page=one" style="font-size: 23px;">
                      <button type="button" class="btn btn-warning btn-lg">
                      <?php
                      if (empty($pemb2['foto'])) {
                      }else{
                      ?>
                      <img class="profile-img" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="50" height="50" style="border-radius: 100%; border:1px solid #FAFAFA;">
                      <?php
                      }
                      ?> <i class="fa fa-envelope"></i> Pesan Baru (<b style='color:#E91E63;'><?php echo $jumlah_pesan_baru; ?></b>)</button>

                      </a>
                      <?php

                      }
                      ?>
            <!-- PEMBIMBING 2 -->
          <?php 
          $pb=mysqli_query($con, "SELECT * FROM tb_pembtwo
          INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
          WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
          $pemb=mysqli_fetch_array($pb);
          ?>
          <?php
          $pesan_baru2=mysqli_query($con, "SELECT * FROM tb_pesan WHERE id_pengirim='$pemb[id_dsn]' AND id_penerima='$data[id_mhs]' and status_pesan='belum'");
          $jumlah_pesan_baru2=mysqli_num_rows($pesan_baru2); ?>
              <?php 
              if($jumlah_pesan_baru2==0){
              // echo "Tidak Ada Pesan Baru (0)";
              }else if($jumlah_pesan_baru2 > 0){
              ?>
              <hr>

              <a href="?page=two" style="font-size: 23px;">
              <button type="button" class="btn btn-warning btn-lg">
              <?php
              if (empty($pemb['foto'])) {
              }else{
              ?>
              <img class="profile-img" src="../assets/images/<?php echo $pemb['foto'] ?>" width="50" height="50" style="border-radius: 100%; border:1px solid #FAFAFA;">
              <?php
              }
              ?> <i class="fa fa-envelope"></i> Pesan Baru (<b style='color:#E91E63;'><?php echo $jumlah_pesan_baru2; ?></b>)</button>

              </a>
              <?php

              }
              ?>

                  
                     <!--        <div class="alert alert-warning alert-dismissible fade in" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">x</span></button>
                            <h4 id="oh-snap!-you-got-an-error!">Oh snap! You got an error!<a class="anchorjs-link" href="#oh-snap!-you-got-an-error!"><span class="anchorjs-icon"></span></a></h4>
                            <p>Change this and that and try again. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.</p>
                            <p>
                            <button type="button" class="btn btn-info btn-xs"><i class="fa fa-check"></i> Periksa & Rekomendasi</button>
                            </p>
                            </div>   -->

              </div> 
              <div class="col-md-6">
                 <!-- hh  -->
              </div>              
            </div>

        </div>
        <div role="tabpanel" class="tab-pane" id="step3">
            <b>Step3</b> : Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum
        </div>
        <div role="tabpanel" class="tab-pane" id="step4">
           <?php 
          $result = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]' AND disetujui_kajur='Disetujui' ");
          $judulnyo = mysqli_fetch_array($result);
          if ($judulnyo['disetujui_kajur']=='Disetujui') {
        ?>
          <div class="alert alert-warning alert-dismissible fade in" role="alert" style="border: 3px double;">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
              <center>
              <b>SELAMAT ! <br>
             Judul
             </b>
              <h4 id="oh-snap!-you-got-an-error!">"<b><?php echo $judulnyo['judul_proposal']; ?></b>"</h4>
              <b>Telah "<?php echo $judulnyo['disetujui_kajur']; ?>" Pada Tanggal <?php echo date('d F Y',strtotime($judulnyo['tgl_acc'])); ?>  </b>
              <hr style="border:1px dashed brown;"> 
              </center>
              <?php 
              $pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
              INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
              WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
              $pemb2=mysqli_fetch_array($pb2);
             if (empty($pemb2['id_pembtwo'])) {
               echo " <center> Saat Ini Dosen Pembimbing 1 dan Dosen Pembimbing 2 Anda Belum Dipilh, Tunggu Informasi Selanjutnya ..</center>";
             }else{
              ?>
               <?php 
            $pb1=mysqli_query($con, "SELECT * FROM tb_pembone
            INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
            WHERE tb_pembone.id_mhs='$data[id_mhs]' ");
            $pemb=mysqli_fetch_array($pb1);
            ?>

            <?php 
              $pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
              INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
              WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
              $pemb2=mysqli_fetch_array($pb2);
              ?>
            <div class="table-responsive">           

              <table class="table table-condensed table-hover" style="background-color: #FAFAFA;">
            <tr>
              <td colspan="2" align="center"><b>PEMBIMBING I </b></td>
              <td colspan="2" align="center"><b>PEMBIMBING II </b></td>
            </tr>
            <tr>
              <td colspan="2" align="center">
                <?php
                if (empty($pemb['foto'])) {
                  
                }else{
                  ?>
                  <img class="img-thumbnail" src="../assets/images/<?php echo $pemb['foto'] ?>" width="80" height="80">
                  <?php
                }
                ?>
                
              </td>
              <td colspan="2" align="center">
                  <?php
                if (empty($pemb2['foto'])) {
                  
                }else{
                  ?>
                  <img class="img-thumbnail" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="80" height="80">
                  <?php
                }
                ?>
                </td>
            </tr>
            <!-- 1 -->
          
            <tr>
              <td>Nama Dosen </td>
              <td><?php echo $pemb['nama_dosen']; ?></td>
              <td>Nama Dosen </td>
              <td><?php echo $pemb2['nama_dosen']; ?></td>
            </tr>
            <tr>
              <td>NIK</td>
              <td><?php echo $pemb['nip']; ?></td>
              <td>NIK</td>
              <td><?php echo $pemb2['nip']; ?></td>
            </tr>
            <tr>
              <td>Jabatan</td>
              <td><?php echo $pemb['jabatan']; ?></td>
              <td>Jabatan</td>
              <td><?php echo $pemb2['jabatan']; ?></td>
            </tr>
              <tr>
              <td>Persetujuan</td>
              <?php
              if ($pemb['ket_one']=='Belum Konfir') {
               echo '<td class="label label-danger">Belum Konfirmasi</td>';
              }else{
                ?>
                <td><b class="btn btn-success">Bersedia </b> <a href="cetak/printKartuPembimbing.php?pemb=<?php echo $pemb['id_pembone']; ?>" class="btn btn-primary" target="_blank"><i class="fa fa-print"></i> Cetak</a></td>
                <?php
              
              }
              ?>
              

              <td>Persetujuan</td>
              <!-- <td class="label label-danger"><?php echo $pemb2['ket_two']; ?></td> -->
                 <?php
              if ($pemb2['ket_two']=='Belum Konfir') {
               echo '<td class="label label-danger">Belum Konfirmasi</td>';
              }else{
                 ?>
                <td><b class="btn btn-success">Bersedia </b> <a href="cetak/printKartuPembimbing2.php?pembtwo=<?php echo $pemb2['id_pembtwo']; ?>" class="btn btn-primary" target="_blank"><i class="fa fa-print"></i> Cetak</a></td>
                <?php
              }
              ?>
            </tr>
          </table>
           </div>
       

<hr>
<p>
  Perhatian ! <br>
  - Harap Cetak Surat Kesediaan Pembimbing 1 dan Pembimbing 2 Sebagai Bukti / Arsip <br>
  - Harap di Tanda Tangan Ketua Jurusan Pada Masing-masing Surat .

</p>



              <?php
             }
              ?>



          </div>
        <?php
        }
        ?>
        </div>
    </div>
</div>
            </div>
          </div>
        </div>
      </div>

    <!-- end tabs -->
  </div>