<?php 
include '../../config/databases.php';
$pemb= $_GET['pemb'];
$pem1 = mysqli_query($con,"SELECT * FROM tb_pembone
INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
INNER JOIN tb_pengajuanjudul ON tb_pembone.id_pengajuan=tb_pengajuanjudul.id_pengajuan
WHERE  tb_pembone.id_pembone='$pemb'");
$p1= mysqli_fetch_array($pem1);
 ?>
 <?php 
 // $pembtwo= $_GET['pembtwo'];
$pem2 = mysqli_query($con,"SELECT * FROM tb_pembtwo
-- INNER JOIN tb_mhs ON tb_pembone.id_mhs=tb_mhs.id_mhs
INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
INNER JOIN tb_pengajuanjudul ON tb_pembtwo.id_pengajuan=tb_pengajuanjudul.id_pengajuan
WHERE tb_pembtwo.id_pengajuan='$p1[id_pengajuan]'");
$p2= mysqli_fetch_array($pem2);
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style>
 	body{
 		font-family: Verdana, Geneva, Tahoma, sans-serif;
 	} 		
 	</style>
 </head>
 <body>
 	<table width="100%" style="border-bottom: 5px double;">
  <tr>
  <td>
  <img src="../../assets/images/unibba.png" width="100">
  </td>
    <td>
    <h4 align="center"> UNIVERSITAS BALE BANDUNG <br> FAKULTAS TEKNOLOGI INFORMASI <br> PROGRAM STUDI TEKNIK INFORMATIKA
      <p align="center" style="font-size: 9px;">Jl. R.A.A Wiranatakusumah No.7 Baleendah40258 - Telepon (022) 5943106, Website: https://fti.unibba.ac.id/</p></h4>

    </td>
    <td>
      <img src="../../assets/images/fti.png" width="100">
    </td>
  </tr>
</table>
<br>

 <table cellpadding="1" cellspacing="1" style="width:100%">
	<tbody>
		<tr>
			<td>Nomor</td>
			<td>: 01/FTI-UNIBBA/<?php echo date ("Y") ?></td>
		</tr>
		<tr>
			<td>Lamp</td>
			<td>: 1 (Satu) Rangkap</td>
		</tr>
		<tr>
			<td>Hal</td>
			<td>: <strong>Mohon Kesediaan Jadi Pembimbing</strong></td>
		</tr>
	</tbody>
</table>

<p>Yth : <strong><?php echo $p1['nama_dosen']; ?></strong></p>

<p>Di Tempat</p>

<p>Assalamu&#39;alaikum wr,wb.</p>

<p>&nbsp; &nbsp;Sesuai dengan usulan Pembimbing Skripsi yang diajukan oleh Mahasiswa Program Studi Teknik Informatika Fakultas Teknologi Informasi UNIBBA, Maka bersama ini dimohon kesediaan Bapak/Ibu sebagai pembimbing Skripsi Mahasiswa dibawah ini :</p>

<table cellpadding="1" cellspacing="1" width="100%">
	<tbody>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><?php echo $p1['nama']; ?></td>
		</tr>
		<tr>
			<td>NIM</td>
			<td>:</td>
			<td><?php echo $p1['nim']; ?></td>
		</tr>
		<tr>
			<td>Judul Skripsi</td>
			<td>:</td>
			<td><?php echo $p1['judul_proposal']; ?></td>
		</tr>
		<tr>
			<td>Pembimbing</td>
			<td>:</td>
			<td>1. <?php
			if ($p1['ket_one']=='Belum Konfir') {
				?>
					<b class='text-danger'>Belum Anda Kofirmasi</b> <a href="?page=confirm&act=confir&aksi=<?php echo $p1['id_pembone']; ?> " class='btn btn-success btn-xs'> <i class='fa fa-check'></i> Klik Untuk Kofirmasi !</a>
				<?php
			}else{
				echo $p1['nama_dosen']; 
			}

			 ?></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>2. <?php
			if ($p2['ket_two']=='Belum Konfir') {
				echo "<b>Belum Konfirmasi</b>";
			}else{
				echo $p2['nama_dosen']; 
			}

			 ?></td>
		</tr>
	</tbody>
</table>

<p>&nbsp; &nbsp; &nbsp;Demikian permohonan ini kami sampaikan atas perhatian dan kerjasamanya saya ucapkan terimakasih.</p>

<p style="text-align:right">Wassalam,</p>

<p style="text-align:right">Ketua Jurusan,</p>

<p style="text-align:right">&nbsp;</p>

<p style="text-align:right">&nbsp;</p>

<p style="text-align:right"><strong><u>Yaya Suharya, S.kom., M.T.</u><br></strong> </p>

<p style="text-align:right"><strong>NIDN. 0407047706</strong> </p>


 <script>
 	window.print();
 </script>
 </body>
 </html>






	