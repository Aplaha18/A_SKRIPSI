
<?php 
include '../../config/databases.php';
$data= $_GET['data'];
$mhs=mysqli_query($con, "SELECT * FROM tb_mhs WHERE id_mhs='$data' ");
$data1=mysqli_fetch_array($mhs);

$pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
WHERE tb_pembtwo.id_mhs='$data' ");
$pemb2=mysqli_fetch_array($pb2);
?>
<!-- end pembimbing 2 -->
<!-- Pembimbing 2 -->
<?php 
$pb1=mysqli_query($con, "SELECT * FROM tb_pembone
INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
WHERE tb_pembone.id_mhs='$data' ");
$pemb1=mysqli_fetch_array($pb1);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Kartu Bukti Konsultasi Bimbingan Skripsi</title>
<style>
body{
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  font-size: 12px;
}
.tabel{
  border-collapse: collapse;
  font-size: 11px;

}
  
</style>
</head>

<body>

<table width="100%" style="text-align: center;font-size: 17px;">
  <tr>
  <td>
  <img src="../../assets/images/unibba.png" width="100">
  </td>
    <td>
    <h4 align="center"> UNIVERSITAS BALE BANDUNG <br> FAKULTAS TEKNOLOGI INFORMASI <br> PROGRAM STUDI TEKNIK INFORMATIKA
      <p align="center" style="font-size: 9px;">Jl. R.A.A Wiranatakusumah No.7 Baleendah40258 - Telepon (022) 5943106, Website: https://fti.unibba.ac.id/</p></h4>

    </td>
    <td>
      <img src="../../assets/images/fti.png" width="100">
    </td>
  </tr>
</table>
<hr style="border:1px double">
<table width="100%">
  <tr>
    <td><div align="center">KARTU BUKTI KONSULTASI BIMBINGAN SKRIPSI</div></td>
  </tr>
  <tr>
    <br>
  </tr>
</table>
<table width="100%">
  <tr>
    <td width="11%">NAMA</td>
    <td width="1%">:</td>
    <td width="88%"><?php echo $data1['nama'] ?></td>
  </tr>
  <tr>
    <td>NIM</td>
    <td>:</td>
    <td><?php echo $data1['nim'] ?> </td>
  </tr>
  <tr>
    <td>JURUSAN</td>
    <td>:</td>
    <td>Teknik Informatika </td>
  </tr>
  <tr>
    <td>DOSEN PEMBIMBING </td>
    <td>:</td>
    <td>1. <?php echo $pemb1['nama_dosen']; ?> </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>:</td>
    <td>2. <?php echo $pemb2['nama_dosen']; ?> </td>
  </tr>
</table>
<!-- <table width="100%">
  <tr>
    <td> -->
      <br>
   
<!-- </td>
<td> -->

    <!-- <table width="100%" border="1" class="tabel" cellpadding="3">
 

    </table> -->
<!-- </td>
  </tr>
</table> -->
<table width="100%" border="" class="tabel">
  <tr>
    <td><table width="100%" border="1" class="tabel" cellpadding="3">
      <tr>
        <td rowspan="2">No</td>
        <td rowspan="2">Hari/Tanggal</td>
        <td colspan="2" align="center">Hal yang dikonsultasikan </td>
      </tr>
      <tr>
        <td align="center"><b>Pembimbing 1 </b></td>
        <td>Tanda Tangan </td>
      </tr>
       <!-- pembimbing 1 -->
      <?php 
      $no=1;
      $satu = mysqli_query($con,"SELECT * FROM tb_pesanpembone WHERE id_pembone='$pemb1[id_pembone]' ") or die(mysqli_error($con));
      while ($d= mysqli_fetch_array($satu)) { ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo date('d/m/Y',strtotime($d['tgl_pesan'])) ; ?></td>
        <td><?php echo $d['subyek']; ?> ( <?php echo $d['isi_pesan']; ?> )</td>
        <td></td>
      </tr>
    <?php } ?>

    </table></td>
    <td><table width="100%" border="1" class="tabel" cellpadding="3">
      <tr>
        <td rowspan="2">Hari/Tanggal</td>
        <td colspan="2" align="center">Hal yang dikonsultasikan </td>
      </tr>
      <tr>
        <td align="center"><b>Pembimbing 2</b> </td>
        <td>Tanda Tangan </td>
      </tr>
       <!-- pembimbing 2 -->
      <?php 
      $no=1;
      $dua = mysqli_query($con,"SELECT * FROM tb_pesan WHERE id_pembtwo='$pemb2[id_pembtwo]' ") or die(mysqli_error($con));
      while ($d= mysqli_fetch_array($dua)) { ?>
      <tr>
        <td><?php echo date('d/m/Y',strtotime($d['tgl_pesan'])) ; ?></td>
        <td><?php echo $d['subyek']; ?>( <?php echo $d['isi_pesan']; ?> )</td>
        <td></td>
      </tr>
    <?php } ?>

    </table></td>
  </tr>
</table>
      <table width="100%">
      <!--  <a href="#" class="no-print" onclick="window.print();"> <button style="height: 40px; width: 70px; background-color: dodgerblue;border:none; color: white; border-radius:7px;font-size: 17px; " type=""> Cetak</button> </a> -->
        <tr>
          <td align="right" colspan="6" rowspan="" headers="">
            <p>Bandung, <?php echo date (" d F Y") ?> <br>
            Dekan FTI </p> <br> <br> <br>
            <p><u><b>Yudi Herdiana, S.T, M.T.</b></u> <br>
            <b>NIDN. 0428027501      </b></p>
          </td>
        </tr>
      </table>




</body>
</html>
<script>
  window.print();
</script>
