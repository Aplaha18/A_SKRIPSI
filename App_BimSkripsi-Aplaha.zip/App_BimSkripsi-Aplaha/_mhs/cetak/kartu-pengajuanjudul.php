<?php 
$id = $_GET['id'];
include '../../config/databases.php';
$result = mysqli_query($con,"SELECT * FROM tb_pa
              INNER JOIN tb_mhs ON tb_pa.id_mhs=tb_mhs.id_mhs
              INNER JOIN tb_dsn ON tb_pa.id_dsn=tb_dsn.id_dsn WHERE tb_pa.id_mhs='$id' ");
$rows = mysqli_fetch_array($result);

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Kartu Pengajuan Judul Proposal</title>
<style>
body{
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  font-size: 14px;
}
  
</style>
</head>

<body>
<table width="100%" style="text-align: center;font-size: 17px;">
  <tr>
  <td>
  <img src="../../assets/images/unibba.png" width="100">
  </td>
    <td>
    <h4 align="center"> UNIVERSITAS BALE BANDUNG <br> FAKULTAS TEKNOLOGI INFORMASI <br> PROGRAM STUDI TEKNIK INFORMATIKA
      <p align="center" style="font-size: 9px;">Jl. R.A.A Wiranatakusumah No.7 Baleendah40258 - Telepon (022) 5943106, Website: https://fti.unibba.ac.id/</p></h4>

    </td>
    <td>
      <img src="../../assets/images/fti.png" width="100">
    </td>
  </tr>
</table>
<hr style="border:1px double">
<table width="100%">
  <tr>
    <td><div align="center">KARTU PENGAJUAN JUDUL SKRIPSI</div></td>
  </tr>
  <tr><br></tr>
</table>
<table width="100%">
  <tr>
    <td>Nama / NIM </td>
    <td>:</td>
    <td><?php echo $rows['nama'] ?> / <?php echo $rows['nim'] ?> </td>
  </tr>
  <tr>
    <td>Fakultas / Jurusan </td>
    <td>:</td>
    <td>FAKULTAS TEKNOLOGI INFORMASI/ TEKNIK INFORMATIKA </td>
  </tr>
  <tr>
    <td>Tahun Akademik </td>
    <td>:</td>
    <td><?php echo date ("Y",strtotime('-1 year',strtotime(date("Y")))) ?>/<?php echo date ("Y") ?></td>
  </tr>
  <tr>
    <td>Dosen Wali </td>
    <td>:</td>
    <td><?php echo $rows['nama_dosen'] ?></td>
  </tr>
</table>
<hr>
<table width="100%" border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse;">
  <tr>
    <td>No.</td>
    <td>Judul</td>
    <td>Pokok Masalah </td>
    <td>Keterangan</td>
  </tr>
<?php
$no=1; 
$query= mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$id' ");
while ($row= mysqli_fetch_array($query)) { ?>
  <tr>
    <td align="center"><?php echo $no++; ?>.</td>
    <td><?php echo $row['judul_proposal']; ?></td>
    <td><?php echo $row['masalah']; ?></td>
    <td><?php echo $row['status_proposal']; ?></td>
  </tr>
<?php } ?>
</table>
<p>&nbsp;</p>
</body>
</html>
<script>
  window.print();
</script>
