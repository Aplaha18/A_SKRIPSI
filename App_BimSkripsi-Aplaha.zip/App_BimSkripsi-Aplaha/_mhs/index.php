<?php 
session_start();
if (!isset($_SESSION['mahasiswa'])) {
?> <script>
    alert('Anda Belum Login !!');
    window.location='../login.php';
 </script>
<?php
}

include '../config/databases.php';
 ?>


<!DOCTYPE html>
<html>
<head>
  <title>Selamat Datang - <?php echo $_SESSION['nama']; ?></title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="../assets/css/vendor.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/flat-admin.css">

  <!-- Theme -->
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/blue-sky.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/blue.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/red.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/theme/yellow.css">
  <!-- Sweat Alert -->
    <link rel="stylesheet" type="text/css" href="../assets/alert/css/sweetalert.css">
      <script src="../assets/alert/js/jquery-2.1.4.min.js" type="text/javascript" charset="utf-8" async defer></script>
 
  <script src="../assets/alert/js/sweetalert.min.js" type="text/javascript" charset="utf-8" async defer></script>


  <link rel="stylesheet" type="text/css" href="../assets/style.css">
         <script type="text/javascript" src="../assets/pesan.js"></script>


</head>
<body>
<?php
if (@$_SESSION['mahasiswa']) {
$id_user = @$_SESSION['id'];
}

$sql = mysqli_query($con,"SELECT * FROM tb_mhs WHERE id_mhs = '$id_user'") or die(mysqli_error($con));
$data = mysqli_fetch_array($sql);
?>
  <div class="app app-red">
<aside class="app-sidebar" id="sidebar">
  <div class="sidebar-header" style="background-color: #212121;">
    <a class="sidebar-brand" href="#"><span class="highlight">Mahasiswa</span></a>
    
    <button type="button" class="sidebar-toggle">
      <i class="fa fa-times"></i>
    </button>
  </div>
  <div class="sidebar-menu" style="background-color: #212121;">
    <ul class="sidebar-nav">
      <li class="">
        <a href="index.php">
          <div class="icon">
            <i class="fa fa-home" aria-hidden="true"></i>
          </div>
          <div class="title" style="color: #fff;">Beranda</div>
        </a>
      </li>
      <li class="">
       <a href="?page=dosen">
          <div class="icon">
            <i class="fa fa-graduation-cap" aria-hidden="true"></i>
          </div>
          <div class="title" style="color:#FAFAFA">Data Dosen</div>
       </a>
      </li>
      <li class="">
        <a href="?page=judul">
          <div class="icon">
            <i class="fa fa-file-text" aria-hidden="true"></i>
          </div>
          <div class="title" style="color:#FAFAFA">Judul Skripsi</div>
        </a>
      </li>
      <?php 
         $qryp = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]'");
        $menup = mysqli_fetch_array($qryp);
        if ($menup['disetujui_kajur']=='Belum Diterima') {
          // echo "string";
           ?>
            <li>
              <a href="?page=stepone&act=intopik">
              <div class="icon">
                <i class="fa fa-user-plus" aria-hidden="true"></i>
              </div>
              <div class="title">Pengajuan Masalah</div>
              </a>
            </li>
            <?php
     
        }else{
         
        }
       ?>

 

      <?php 
        $qry = mysqli_query($con,"SELECT * FROM tb_pembtwo WHERE id_mhs='$data[id_mhs]'");
        $menu = mysqli_fetch_array($qry);
        if ($menu['ket_two']=='Bersedia') {
          //Tampilkan semua menu disini
          ?>
                     <li class="@@menu.messaging">
            <a href="?page=upload">
            <div class="icon">
            <i class="fa fa-upload" aria-hidden="true"></i>
            </div>
            <div class="title" style="color: #fff;">
            Upload File
            </div>
            </a>
          </li> 
            <?php 
            $pesan_baru=mysqli_query($con, "SELECT * FROM tb_pesan WHERE id_pengirim='$menu[id_dsn]' AND id_penerima='$data[id_mhs]' and status_pesan='belum'");
            $jumlah_pesan_baru=mysqli_num_rows($pesan_baru);

            if($jumlah_pesan_baru == 0){
                ?>
            <!--       <li class="@@menu.messaging">
                    <a href="?page=two&act=pesan&id_mhs=<?php echo $data['id_mhs'] ?>">
                    <div class="icon">
                    <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </div>
                    <div class="title" style="color: #fff;">Pesan (0)</div>
                    </a>
                  </li> -->
                <?php
            }
            else if($jumlah_pesan_baru > 0){
              ?>
               <!--    <li class="@@menu.messaging">
                    <a href="?page=two&act=pesan&id_mhs=<?php echo $data['id_mhs'] ?>">
                    <div class="icon">
                    <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </div>
                    <div class="title" style="color: #fff;">
                      Pesan Baru <span class="label label-success"><?php echo $jumlah_pesan_baru; ?></span>
                    </div>
                    </a>
                  </li> -->
                <?php

            }
            ?>
            

      <li class="dropdown ">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <div class="icon">
            <i class="fa fa-graduation-cap" aria-hidden="true"></i>
          </div>
          <div class="title" style="color: #fff;">Bimbingan</div>
        </a>
        <div class="dropdown-menu">
          <ul>
            <li class="section">
              <?php 
              $p2= mysqli_query($con,"SELECT * FROM tb_dsn WHERE id_dsn='$menu[id_dsn] '");
              $pd = mysqli_fetch_array($p2);
               ?>
              <i class="fa fa-graduation-cap" aria-hidden="true"></i> PEMBIMBING II</li>
            <li><a href="?page=two"> <img src="../assets/images/<?php echo $pd['foto'] ?>" width="40" height="40" class="img-circle"> <em><?php echo $pd['nama_dosen'] ?></em></a></li>
            <li class="line"></li>
             <?php 
              $p1= mysqli_query($con,"SELECT * FROM tb_pembone
                INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
               WHERE tb_pembone.id_mhs='$data[id_mhs] '");
              $ps = mysqli_fetch_array($p1);
               ?>
            <li class="section"><i class="fa fa-graduation-cap" aria-hidden="true"></i> PEMBIMBING I</li>
            <li><a href="?page=one"> <img src="../assets/images/<?php echo $ps['foto'] ?>" width="40" height="40" class="img-circle"><em> <?php echo $ps['nama_dosen'] ?></em></a></li>
          </ul>
        </div>
      </li>
         <li class="@@menu.messaging">
                    <a href="?page=kartu">
                    <div class="icon">
                    <i class="fa fa-file-o" aria-hidden="true"></i>
                    </div>
                    <div class="title" style="color: #fff;">
                      Cetak Kartu
                    </div>
                    </a>
                  </li>
          <?php
        }else{
          // Jangan Tampilkan apa apa ..
          // echo "Tampilan Kosong";
        }
       ?>
      
    </ul>
  </div>
  <div class="sidebar-footer" style="background-color:#ff0000;">
    <ul class="menu">
      <li>
        <a href="/" class="dropdown-toggle" data-toggle="dropdown">
          <!-- <i class="fa fa-cogs" aria-hidden="true"></i> -->
          FTI 2020 - UNIBBA
        </a>
      </li>
      <!-- <li><a href="#"><span class="flag-icon flag-icon-th flag-icon-squared"></span></a></li> -->
    </ul>
  </div>
</aside>

<script type="text/ng-template" id="sidebar-dropdown.tpl.html">
  <div class="dropdown-background">
    <div class="bg"></div>
  </div>
  <div class="dropdown-container">
    {{list}}
  </div>
</script>
<div class="app-container">
  <nav class="navbar navbar-default" id="navbar">
  <div class="container-fluid">
    <div class="navbar-collapse collapse in">
      <ul class="nav navbar-nav navbar-mobile">
        <li>
          <button type="button" class="sidebar-toggle">
            <i class="fa fa-bars"></i>
          </button>
        </li>
        <li class="logo">
          <a class="navbar-brand" href="#"><span class="highlight">Mahasiswa</span> Online</a>
        </li>
        <li>
          <button type="button" class="navbar-toggle">
            <img class="profile-img" src="../assets/img-mhs/<?php echo $data['fotomhs'] ?>">
          </button>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-left">
        <li class="navbar-title">
          <!-- <?php echo date('d F Y'); ?> -->
          <b style="color:#212121;"><img src="../assets/images/fti.png" width="75"> BIMBINGAN SKRIPSI ONLINE</b>
          
        </li>
        <li class="navbar-search hidden-sm">
          <!-- Online -->
 <!--          <input id="search" type="text" placeholder="Search..">
          <button class="btn-search"><i class="fa fa-search"></i></button> -->
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <!-- <li class="dropdown notification danger">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <div class="icon">
              <i class="fa fa-shopping-basket" aria-hidden="true"></i>
              <img class="img-circle" src="../assets/img-mhs/<?php echo $data['fotomhs'] ?>" width="40" height="40">
            </div>
            <div class="title">Pembimbing I</div>
            <div class="count">1</div>
          </a>
          <div class="dropdown-menu">
            <ul>
              <li class="dropdown-header">Pembimbing I</li>
               <li class="dropdown-empty">No New Ordered</li> 
                   <li>
                <a href="#">
                  <span class="badge badge-warning pull-right">5</span>
                  <div class="message">
                    <img class="profile" src="https://placehold.it/100x100">
                    <div class="content">
                      <div class="title">"Hello World"</div>
                      <div class="description">Marco  Harmon</div>
                    </div>
                  </div>
                </a>
              </li>
              <li class="dropdown-footer">
                <a href="#">View All <i class="fa fa-angle-right" aria-hidden="true"></i></a>
              </li>
            </ul>
          </div>
        </li>
          <li class="dropdown notification danger">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <div class="icon">
              <i class="fa fa-shopping-basket" aria-hidden="true"></i> 
              <img class="img-circle" src="../assets/img-mhs/<?php echo $data['fotomhs'] ?>" width="40" height="40">
            </div>
            <div class="title">Pembimbing II</div>
            <div class="count">2</div>
          </a>
          <div class="dropdown-menu">
            <ul>
              <li class="dropdown-header">Pembimbing II</li>
               <li class="dropdown-empty">No New Ordered</li> 
                   <li>
                <a href="#">
                  <span class="badge badge-warning pull-right">5</span>
                  <div class="message">
                    <img class="profile" src="https://placehold.it/100x100">
                    <div class="content">
                      <div class="title">"Hello World"</div>
                      <div class="description">Marco  Harmon</div>
                    </div>
                  </div>
                </a>
              </li>
              <li class="dropdown-footer">
                <a href="#">View All <i class="fa fa-angle-right" aria-hidden="true"></i></a>
              </li>
            </ul>
          </div>
        </li> -->

      
 
    
        <li class="dropdown profile">
       <b><?php echo $data['nama'] ?>
       </b> (<?php echo $data['nim'] ?>)
          <a href="/html/pages/profile.html" class="dropdown-toggle"  data-toggle="dropdown">
            <img class="profile-img" src="../assets/img-mhs/<?php echo $data['fotomhs'] ?>">
            <div class="title">Profile</div>
          </a>
          <div class="dropdown-menu">
            <div class="profile-info">
              <h4 class="username"><?php echo $data['nama'] ?></h4>
            </div>
            <ul class="action">
              <li>
                <a href="?page=kartu&act=change">
                  Ganti Password
                </a>
              </li>
              <li>
                <a href="logout.php">
                  Logout
                </a>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

  <?php 
  error_reporting();
  $page = $_GET['page'];
  $act= $_GET['act'];
  if ($page=='stepone') {
    if ($act=='') {
      include 'pages/action-stepone.php';
    }elseif ($act=='intopik') {
      include 'pages/ajukan_topik/input_topik.php';
    }elseif ($act=='listjudul') {
      include 'pages/ajukan_topik/list-judul.php';
    }
  }elseif ($page=='dosen') {
       if ($act=='') {
         include 'pages/list_dosen.php';
      }elseif ($act=='detail') {
        include 'pages/detail_dosen.php';
       }
  }elseif ($page=='judul') {
       if ($act=='') {
         include 'pages/judul_skripsi/list_judul.php';
       }
     }elseif ($page=='mhs') {
       if ($act=='detail') {
        include 'pages/judul_skripsi/detail_mhs.php';
      }
  }elseif ($page=='two') {
    if ($act=='') {
      include 'pages/bimbingan/open-two.php';
    }elseif ($act=='pesan') {
      include 'pages/bimbingan/list-pesan.php';
    }elseif ($act=='bukapesan') {
      include 'pages/bimbingan/buka-pesan.php';
    }elseif ($act=='proses') {
      include 'pages/bimbingan/proses_balas_pesan.php';
    }
  }elseif ($page=='one') {
    if ($act=='') {
      include 'pages/bimbingan1/open-one.php';
    }elseif ($act=='bukapesan') {
      include 'pages/bimbingan1/buka-pesan.php';
    }
  }elseif($page=='upload'){
    if ($act=='') {
     include 'pages/upload/upload-file.php';
    }elseif ($act=='del') {
      include 'pages/upload/delete-file.php';
    }

  }elseif ($page=='kartu') {
    if ($act=='') {
        include 'pages/kartu/kartu_bimbingan.php';
    }elseif ($act=='change') {
      include 'pages/profil/myprofile.php';
    }
  }elseif ($page=='') {
    $result = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]'
   -- AND disetujui_kajur='Disetujui' 
   ");
  $judulnyo = mysqli_fetch_array($result);
  if (empty($judulnyo['disetujui_kajur'])) {
     include 'info-utama.php';
  }elseif ($judulnyo['disetujui_kajur']=='Belum Diterima') {
     include 'info-utama.php';
  }else{
   include 'info-second.php';
  }
  }
  

   ?>

  </div>
</div>

  <script type="text/javascript" src="../assets/js/vendor.js"></script>
  <script type="text/javascript" src="../assets/js/app.js"></script>
    <script type="text/javascript" src="../assets/ckeditor/ckeditor.js"></script> 
   <script>
        
          CKEDITOR.replace('ckedtor1',{
             uiColor:'#FAFAFA',
            filebrowserImageBrowseUrl : '../assets/kcfinder'
        });
        
    </script> 




</body>
</html>