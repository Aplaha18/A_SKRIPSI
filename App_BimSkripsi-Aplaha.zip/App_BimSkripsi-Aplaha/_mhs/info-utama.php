<div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body app-heading">
          <img class="profile-img" src="../assets/img-mhs/<?php echo $data['fotomhs'] ?>">
          <div class="app-title">
            <h3><b>Selamat Datang ..</b></h3>
            <div class="title">
               <span class="highlight"><b><?php echo $data['nama']; ?></b> <small>(<?php echo $data['nim']; ?>)</small>
             <br>
            <!--  <code>Silahkan Ikuti Langkah Berikut Untuk Mengusulkan Judul Skripsi Anda !!</code> --></span></div>

            <?php 
            $pa = mysqli_query($con,"SELECT * FROM tb_pa
              INNER JOIN tb_mhs ON tb_pa.id_mhs=tb_mhs.id_mhs
              INNER JOIN tb_dsn ON tb_pa.id_dsn=tb_dsn.id_dsn WHERE tb_pa.id_mhs='$data[id_mhs]' ");
            $dosen_pa = mysqli_fetch_array($pa);
             ?>
          <?php
            if ($dosen_pa['id_dsn']=='') {
             // Tampilkan tombol Tambah??
              ?>
              <br>

                <div class="col-md-12 col-sm-12">
                  <div class="alert alert-info alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <h4 id="oh-snap!-you-got-an-error!"> Langkah 1<a class="anchorjs-link" href="#oh-snap!-you-got-an-error!"><span class="anchorjs-icon"></span></a><hr> Memilih Dosen Wali</h4>
                    <p>Untuk Mengusulkan Topik / Masalah, Mahasiwa Harus Memilih Dosen Wali .</p>
                    <p>
                    <a data-toggle="modal" data-target="#myModal" class="btn btn-danger"> <i class="fa fa-search"></i> Cari Dosen</a>                
                    </p>

                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                              <h4 class="modal-title">Pilih Dosen Wali</h4>
                            </div>
                            <form action="" method="POST"> 
                            <div class="modal-body"> 
                            <input type="hidden" name="id_mhs" value="<?php echo $data['id_mhs']; ?>">                                                        
                                <div class="form-group">
                                  <label for="Nama">Cari Dosen Wali</label> 
                                  <select name="id_dsn" class="form-control">
                                  <option value="" selected>- Pilih Dosen -</option>
                                  <?php
                                  $sql = mysqli_query($con, "select * from tb_dsn order by nama_dosen ASC");
                                  while($k=mysqli_fetch_array($sql)){
                                  ?>
                                  <option value="<?php echo $k['id_dsn']; ?>"><?php echo $k['nama_dosen']; ?></option>
                                  <?php
                                  }
                                  ?>
                                  </select>
                                </div> 
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
                              <button type="submit" name="pilih" class="btn btn-sm btn-success"> <i class="fa fa-save"></i> Pilih & Selesai</button>
                            </div>
                            </form>
                            <?php 
                            if (isset($_POST['pilih'])) {
                               $id_mhs = $_POST['id_mhs'];
                              $id_dsn = $_POST['id_dsn'];
                               mysqli_query($con,"INSERT INTO tb_pa VALUES(NULL,'$id_mhs','$id_dsn')");
                    echo "
                    <script type='text/javascript'>
                    setTimeout(function () {
                    swal({
                    title: 'TAHAP 1 SELESAI',
                    text:  'Lanjutkan Langkah selanjutnya ..',
                    type: 'success',
                    timer: 3000,
                    showConfirmButton: true
                    });     
                    },10);  
                    window.setTimeout(function(){ 
                    window.location.replace('index.php');
                    } ,3000);   
                    </script>";
                    
                            }


                             ?>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>

              <?php
            }else{
             ?>
            <div class="description">             
             <div class="row">
              <div class="col-md-6">
               <h4>Dosen Wali : <b><?php echo $dosen_pa['nama_dosen']; ?></b></h4>
             </div>

               
             </div>
           </div>
             <hr>
             <?php
           }
              ?>
              <?php 
              $qri = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$data[id_mhs]'");
              $judul = mysqli_fetch_array($qri);
              if (empty($judul['id_mhs'])) {
                // Jika belum ada id mhs , maka
                  ?>
               
                  <div class="col-md-12 col-sm-12">
                  <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <h4 id="oh-snap!-you-got-an-error!">Langkah 2<a class="anchorjs-link" href="#oh-snap!-you-got-an-error!"><span class="anchorjs-icon"></span></a> <hr> Mengusulkan Topik / Masalah</h4>
                    <p>
                      <ul>
                        <li>Siapkan 1 - 3 Topik yang ingin anda ajukan.</li>
                      </ul>
                   </p>
                    <p>
                    <a href="?page=stepone&act=intopik" class="btn btn-primary"> <i class="fa fa-file-o"></i> Ajukan Topik disini</a> 
                    
                    </p>
                  </div>
                </div>
<!-- 
                  Anda Belum Mengusulkan Topik ?
                  <a href="" class="btn btn-danger">Ajukan Topik ?</a> -->
                  <?php
              }else{
               // Jika Sudah ada judul, maka tampilkan disini ..
                ?> 
                   <!--  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <a class="card card-banner card-blue-light">
                      <div class="card-body">
                        <i class="icon fa fa-shopping-basket fa-4x"></i>
                        <div class="content">
                        <div class="title">Sale Today</div>
                        <div class="value"><span class="sign">$</span>420</div>
                        </div>
                      </div>
                    </a>
                  </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      Log Bimbingan
                  </div> -->
                  <div class="col-md-12 col-sm-12">
                  <div class="alert alert-warning alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <b>PENTING !</b> <b>Silahkan tunggu untuk persetujuan topik yang anda ajukan ..</b>
                    <p>Jika topik disetujui, maka fitur bimbingan akan ditampilkan oleh sistem sehingga anda dapat melihat pembimbing I , Pembimbing II dan dapat konsultasi langsung dengan masing-masing pembimbing.</p>
                    <p>
                      <a href="?page=stepone&act=listjudul" class="btn btn-success"><i class="fa fa-fast-forward"></i> Status Judul</a>
                    </p>
                  </div>
                </div>
                <?php
              }
              ?>
          </div>
        </div>
      </div>
    </div>

  </div>