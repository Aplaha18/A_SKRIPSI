<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Login Mahasiswa</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="assets/css/vendor.css">
  <link rel="stylesheet" type="text/css" href="assets/css/flat-admin.css">
  <!-- Theme -->
  <link rel="stylesheet" type="text/css" href="assets/css/theme/blue-sky.css">
  <link rel="stylesheet" type="text/css" href="assets/css/theme/blue.css">
  <link rel="stylesheet" type="text/css" href="assets/css/theme/red.css">
  <link rel="stylesheet" type="text/css" href="assets/css/theme/yellow.css">
  <link rel="stylesheet" type="text/css" href="assets/alert/css/sweetalert.css">
  <script src="assets/alert/js/jquery-2.1.4.min.js" type="text/javascript" charset="utf-8" async defer></script>
  <script src="assets/alert/js/sweetalert.min.js" type="text/javascript" charset="utf-8" async defer></script>
</head>
<body>
  <div class="app app-default">

<div class="app-container app-login">
  <div class="flex-center">
    <div class="app-header"></div>
    <div class="app-body">
      <div class="loader-container text-center">
          <div class="icon">
            <div class="sk-folding-cube">
                <div class="sk-cube1 sk-cube"></div>
                <div class="sk-cube2 sk-cube"></div>
                <div class="sk-cube4 sk-cube"></div>
                <div class="sk-cube3 sk-cube"></div>
              </div>
            </div>
          <div class="title">Logging in...</div>
      </div>
      <div class="app-block">
      <div class="app-form">
         <center>
           <img src="assets/images/fti.png" width="120">
         </center>
        <div class="form-header">

          <div class="app-brand"><span class="highlight"><i class="fa fa-users"></i> Mahasiswa</span> Login</div>
        </div>
        <form action="" method="POST">
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon1">
                <i class="fa fa-user" aria-hidden="true"></i></span>
              <input type="text" name="username" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
            </div>
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon2">
                <i class="fa fa-key" aria-hidden="true"></i></span>
              <input type="password" name="password" class="form-control" placeholder="Password" aria-describedby="basic-addon2">
            </div>
            <div class="text-center">
                <input type="submit" name="login_mhs" class="btn btn-success btn-submit" value="Login">
            </div>
        </form>
        <?php 
// Panggil Koneksi Databases
include 'config/databases.php';
if ($_SERVER['REQUEST_METHOD']=='POST') {
      $pass= md5($_POST['password']);
      $sqlCek = mysqli_query($con,"SELECT * FROM tb_mhs WHERE username='$_POST[username]' AND password='$pass' AND status_akun='Y'");
      $jml = mysqli_num_rows($sqlCek);
      $d = mysqli_fetch_array($sqlCek);

      if ($jml > 0) {
      $_SESSION['mahasiswa']= TRUE;
      $_SESSION['id']= $d['id_mhs'];
      $_SESSION['username']= $d['username'];
      $_SESSION['nama']= $d['nama'];
        echo "
        <script type='text/javascript'>
        setTimeout(function () {
        swal({
        title: 'LOGIN SUKSES ',
        text:  'Username dan Password Ditemukan ..',
        type: 'success',
        timer: 3000,
        showConfirmButton: true
        });     
        },10);  
        window.setTimeout(function(){ 
        window.location.replace('_mhs');
        } ,3000);   
        </script>";
      
      }else{
        echo "
        <script type='text/javascript'>
        setTimeout(function () { 

        swal({
        title: 'LOGIN GAGAL !!',
        text:  'Username Dan Password Tidak ditemukan, Ulang Lagi !! ',
        type: 'error',
        timer: 3000,
        showConfirmButton: true
        });     
        },10);  
        window.setTimeout(function(){ 
        window.location.replace('login.php');
        } ,3000);   
        </script>";
      }
      }
?>
        <div class="form-line">
          <div class="title">OR</div>
        </div>
        <div class="form-footer">
          <a href="javascript:history.back()" class="btn btn-danger btn-xs"> <i class="fa fa-chevron-left"></i> Kembali</a>
        </div>
      </div>
      </div>
    </div>
    <div class="app-footer">
    </div>
  </div>
</div>
  </div>
</body>
</html>