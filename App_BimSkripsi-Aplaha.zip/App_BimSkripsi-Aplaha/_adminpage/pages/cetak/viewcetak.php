 <div class="col-sm-12 col-xs-12">
      <div class="card">
        <div class="card-header"style="background-color: RGBA(12, 11, 11, 0.82);color: #fff;">
          <i class="fa fa-file-o"></i>&nbsp;LAPORAN JUDUL SKRIPSI MAHASISWA
        </div>
        <div class="card-body">
          <div class="section">
           <table class="datatable table table-striped primary table-hover" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Mahasiswa</th>
                        <th>Judul Skripsi</th>
                        <th>Tahun</th>
                        <th>
                            <a href="pages/cetak/print_judulsemua.php" class="btn btn-success btn-block" target="_blank"> <i class="fa fa-print"></i> CETAK DATA</a>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no= 1;
                     $judul = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul
                        INNER JOIN tb_mhs ON tb_pengajuanjudul.id_mhs=tb_mhs.id_mhs
                      WHERE tb_pengajuanjudul.disetujui_kajur='Disetujui' ORDER BY tb_pengajuanjudul.id_pengajuan DESC ") or die (mysqli_error($con)) ;
                     foreach ($judul as $data) { ?>                   
                    <tr>
                        <td><b><?php echo $no++; ?>.</b></td>
                        <td><?php echo $data['nama']; ?></td>
                        <td> <a href="?page=mhs&act=detail&id_mhs=<?php echo $data['id_mhs'];?>"><b><?php echo $data['judul_proposal']; ?></b></a></td>
                        <td><?php echo date('Y',strtotime($data['tgl_acc'])); ?></td>
                        <td align="center">
                            <a href="?page=mhs&act=detail&id_mhs=<?php echo $data['id_mhs'];?>" class="btn btn-danger btn-xs"> <i class="fa fa-print"></i> CETAK</a>
                        </td>
                    </tr>                 
                <?php } ?>

                </tbody>
                
            </table>

       </div>
   </div>
</div>
</div>
