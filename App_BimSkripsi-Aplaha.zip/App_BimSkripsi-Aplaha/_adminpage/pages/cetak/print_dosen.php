<?php include '../../../config/databases.php'; ?>
<style type="text/css">
    body{
        font-family: Verdana;
        font-size: 8px;
    }
</style>

<table width="100%" style="text-align: center;">
  <tr>
  <td>
  <img src="../../../assets/images/unibba.png" width="100">
  </td>
    <td>
    <h4 align="center"> LAPORAN DATA DOSEN PEMBIMBING DAN PENGUJI<br>PROGRAM STUDI TEKNIK INFORMATIKA <br> FAKULTAS TEKNOLOGI INFORMASI <br> UNIVERSITAS BALE BANDUNG <br> BANDUNG</h4>
    </td>
    <td>
      <img src="../../../assets/images/fti.png" width="100">
    </td>
  </tr>
</table>
<hr>

<table border="1" width="100%" style="border-collapse: collapse;" cellpadding="3">
<thead>
<tr style="height: 40px;background-color:#F5F5F5;">
    <th>No.</th>
    <th>Photo</th>
    <th>NIK</th>
    <th>Nama Dosen</th>
    <th>Jabatan</th>
    <th>Status</th>
   
</tr>
</thead>
<tbody>
<?php
$no= 1;
 $mhs = mysqli_query($con,"SELECT * FROM tb_dsn ORDER BY id_dsn ASC ") or die(mysqli_error($con)) ;
    while ($data= mysqli_fetch_array($mhs)) { ?>

<tr>
    <td><b><?php echo $no++; ?>.</b></td>
    <th><img src="../../../assets/images/<?php echo $data['foto']; ?>" width="40" height="40" style="border-radius: 100px;">
    </th>
    <td><?php echo $data['nip']; ?></td>
    <td><?php echo $data['nama_dosen']; ?></td>
    <td><?php echo $data['jabatan']; ?></td>
    <td>
        <?php if ($data['status_akundsn']=='Y') {
        echo "<b class='label label-success'>Aktif</b> ";
    }else{
        echo "<b class='label label-danger'>Blokir</b> ";
    }
    ?></td>
</tr>                 
<?php } ?>

</tbody>
</table>
                                    <br>
<table width="100%">
<tr>
<td align="right" colspan="6" rowspan="" headers="">
<p>Bandung, <?php echo date (" d F Y") ?>  <br> <br>
Ketua Jurusan </p> <br> <br> <br>
<p><strong><u>Yaya Suharya, S.kom., M.T.</u></strong> <br> <strong>NIDN. 0407047706</strong> </p>
</td>
</tr>
</table>
<script>
    window.print();
</script>