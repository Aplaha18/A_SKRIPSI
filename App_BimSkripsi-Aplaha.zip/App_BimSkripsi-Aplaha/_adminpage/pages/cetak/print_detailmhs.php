<link rel="stylesheet" type="text/css" href="../../../assets/css/vendor.css">
<?php 
include '../../../config/databases.php';
$id_mhs = $_GET['id_mhs'];
$mhs = mysqli_query($con,"SELECT * FROM tb_mhs WHERE id_mhs='$id_mhs' ") or die(mysqli_error($con));
foreach ($mhs as $data);
?>

<div class="row">
	<div class="col-md-12">
		<div class="card">
<!-- 		  <div class="card-header">
		    <div class="card-title"> -->
		    	<div class="card-body">
		    	<div class="row">
		    		<div class="col-md-3" align="right">
						<center><h4><b>PROFILE MAHASISWA</b></h4>
						<img src="../../../assets/img-mhs/<?php echo $data['fotomhs']; ?>" width="130" height="150" class="img-thumbnail">
						</center>
		    		</div>	
		    		<div class="col-md-6">
		    			<!-- <hr> -->
		    			<br>
		    			<br>
						<table class="table" style="font-weight: bold;color: black;">
							<tr>
								<td>Nama Mahasiwa</td>
								<td>:</td>
								<td><?php echo $data['nama']; ?></td>
							</tr>
							<tr>
								<td>Nim</td>
								<td>:</td>
								<td><?php echo $data['nim']; ?></td>
							</tr>
							<tr>
								<td>Tahun Angkatan</td>
								<td>:</td>
								<td><?php echo $data['tahun_angkatan']; ?></td>
							</tr>
							<tr>
								<td>Status Akun</td>
								<td>:</td>
								<td><?php
								if ($data['status_akun']=='Y') {
									echo "<b class='text-success'>Aktif</b>";
								}else{
									echo "<b class='btn btn-danger btn-block btn-xs'>Blokir</b>";
								}
								?></td>
							</tr>
						</table>
		    				    			
		    		</div>		    		
		    	</div>
<!-- 		    </div>
		  </div> -->
		  
		  	<center>
		  		<?php $jdl = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$id_mhs' AND disetujui_kajur='Disetujui' ") or die(mysqli_error($con));
		  		$judul = mysqli_fetch_array($jdl);
		  		 ?>
		  		<h4>JUDUL SKRIPSI <br><b>" <?php echo $judul['judul_proposal']; ?> "</b></h4>
		  	</center>
		  	<hr>
		  	    <div class="row">
		    		<div class="col-md-6 col-xs-12">
						<!-- pemb 1 -->
						<?php
						 $p1 = mysqli_query($con,"SELECT * FROM tb_pembone 
						 	INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
						 	WHERE tb_pembone.id_mhs='$id_mhs'
						 	") or die(mysqli_error($con));
						$dsn1 = mysqli_fetch_array($p1);
						?>
						<center><b>PEMBIMBING I</b></center> <br>
						<table style="font-weight: bold;color: black;" width="100%" class="table-striped">
							<tr>
								<td>Nama Dosen</td>
								<td>:</td>
								<td><?php echo $dsn1['nama_dosen']; ?></td>
							</tr>
							<tr>
								<td>NIK</td>
								<td>:</td>
								<td><?php echo $dsn1['nip']; ?></td>
							</tr>
							<tr>
								<td>Jabatan</td>
								<td>:</td>
								<td><?php echo $dsn1['jabatan']; ?></td>
							</tr>
						<!-- 	<tr>
								<td>Status Akun</td>
								<td>:</td>
								<td><?php
								if ($dsn1['status_akundsn']=='Y') {
									echo "<b class='text-success'>Aktif</b>";
								}else{
									echo "<b class='btn btn-danger btn-block btn-xs'>Blokir</b>";
								}
								?></td>
							</tr> -->
						</table>
					</div>
					<div class="col-md-6 col-xs-12">
						<center><b>PEMBIMBING II</b></center> <br>
							<!-- pemb 2 -->
						<?php
						 $p1 = mysqli_query($con,"SELECT * FROM tb_pembtwo 
						 	INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
						 	WHERE tb_pembtwo.id_mhs='$id_mhs'
						 	") or die(mysqli_error($con));
						$dsn1 = mysqli_fetch_array($p1);
						?>
						<table style="font-weight: bold;color: black;" width="100%" class="table-striped">
							<tr>
								<td>Nama Dosen</td>
								<td>:</td>
								<td><?php echo $dsn1['nama_dosen']; ?></td>
							</tr>
							<tr>
								<td>NIK</td>
								<td>:</td>
								<td><?php echo $dsn1['nip']; ?></td>
							</tr>
							<tr>
								<td>Jabatan</td>
								<td>:</td>
								<td><?php echo $dsn1['jabatan']; ?></td>
							</tr>
						<!-- 	<tr>
								<td>Status Akun</td>
								<td>:</td>
								<td><?php
								if ($dsn1['status_akundsn']=='Y') {
									echo "<b class='text-success'>Aktif</b>";
								}else{
									echo "<b class='btn btn-danger btn-block btn-xs'>Blokir</b>";
								}
								?></td>
							</tr> -->
						</table>
					</div>
				</div>
		  </div>
		</div>			
	</div>	
</div>
<script>
	window.print();
</script>