 <div class="col-sm-12 col-xs-12">
      <div class="card">
        <div class="card-header"style="background-color: RGBA(12, 11, 11, 0.82);color: #fff;">
          <i class="fa fa-file-o"></i>&nbsp; LAPORAN DOSEN PEMBIMBING
        </div>
        <div class="card-body">
          <div class="section">
            <table class="datatable table table-striped primary" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Photo</th>
                        <th>NIK</th>
                        <th>Nama Dosen</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                        <th>
                            <center>
                                <a href="pages/cetak/print_dosen.php" class="btn btn-primary" target="_blank"> <i class="fa fa-print"></i> CETAK SEMUA</a>
                            </center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no= 1;
                     $mhs = mysqli_query($con,"SELECT * FROM tb_dsn ORDER BY id_dsn ASC ") or die(mysqli_error($con)) ;
                        while ($data= mysqli_fetch_array($mhs)) { ?>
                   
                    <tr>
                    <a href="?page=bimbingan&act=riwayat2&id_mhs=<?php echo $data['id_mhs'];?> ">
                        <td><b><?php echo $no++; ?>.</b></td>
                        <th>
                            <a href="pages/dosen/printdetail_dosen.php?id_dsn=<?php echo $data['id_dsn'];?> " target="_blank"><img src="../assets/images/<?php echo $data['foto']; ?>" width="40" height="40" class="img-circle"></a>
                        </th>
                        <td><a href="pages/dosen/printdetail_dosen.php?id_dsn=<?php echo $data['id_dsn'];?> " target="_blank"><?php echo $data['nip']; ?></a></td>
                        <td><?php echo $data['nama_dosen']; ?></td>
                        <td><?php echo $data['jabatan']; ?></td>
                        <td>
                            <?php if ($data['status_akundsn']=='Y') {
                            echo "<b class='label label-success'>Aktif</b> ";
                        }else{
                            echo "<b class='label label-danger'>Blokir</b> ";
                        }
                        ?></td>
                        <td>
                            <center>

                            <a href="pages/dosen/printdetail_dosen.php?id_dsn=<?php echo $data['id_dsn'];?> " class="btn btn-danger btn-xs" target="_blank"> <i class="fa fa-print"></i> CETAK</a>
                             </center>
                        </td>
                    </a>
                    </tr>                 
                <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
</div>

