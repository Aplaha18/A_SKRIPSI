<?php include '../../../config/databases.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
    body{
        font-family: Verdana;
        font-size: 12px;
    }
</style>
</head>
<body>


<table width="100%" style="text-align: center;">
  <tr>
  <td>
  <img src="../../../assets/images/unibba.png" width="100">
  </td>
    <td>
    <h4 align="center"> LAPORAN DATA JUDUL SKRIPSI MAHASISWA<br>PROGRAM STUDI TEKNIK INFORMATIKA <br> FAKULTAS TEKNOLOGI INFORMASI <br> UNIVERSITAS BALE BANDUNG <br> BANDUNG</h4>
    </td>
    <td>
      <img src="../../../assets/images/fti.png" width="100">
    </td>
  </tr>
</table>
<hr>

<table cellpadding="3" width="100%" border="1" style="border-collapse: collapse;">
<thead>
    <tr style="height: 30px;background-color: #F5F5F5;">
        <th>No.</th>
        <th>Tanggal</th>
        <th>Nim</th>
        <th>Nama Mahasiswa</th>
        <th>Judul Skripsi</th>
        <th>Pembimbing</th>
        <th>Tahun</th>
      
    </tr>
</thead>
<tbody>
    <?php
    $no= 1;
     $judul = mysqli_query($con,"SELECT * FROM tb_pengajuanjudul
        INNER JOIN tb_mhs ON tb_pengajuanjudul.id_mhs=tb_mhs.id_mhs
      WHERE tb_pengajuanjudul.disetujui_kajur='Disetujui' ORDER BY tb_pengajuanjudul.id_pengajuan DESC ") or die (mysqli_error($con)) ;
     foreach ($judul as $data) { ?>                   
    <tr>
        <td align="center"><b><?php echo $no++; ?>.</b></td>
        <td><?php echo date('d-m-Y',strtotime($data['tgl_pengajuan'])); ?></td>
        <td><?php echo $data['nim']; ?></td>
        <td><?php echo $data['nama']; ?></td>
        <td><?php echo $data['judul_proposal']; ?></td>
         <td>
             <?php
        $pemb1 = mysqli_query($con,"SELECT * FROM tb_pembone
        INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
        WHERE tb_pembone.id_mhs='$data[id_mhs]'") or die(mysqli_error($con)) ;
        $dsn1= mysqli_fetch_array($pemb1)
        ?>
        <?php
        $pemb2 = mysqli_query($con,"SELECT * FROM tb_pembtwo
        INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
        WHERE tb_pembtwo.id_mhs='$data[id_mhs]'") or die(mysqli_error($con)) ;
        $dsn= mysqli_fetch_array($pemb2)
        ?>
        
             <ul style="list-style: none;">
                 <li>1. <?php echo $dsn1['nama_dosen']; ?></li>
                 <li>2. <?php echo $dsn['nama_dosen']; ?></li>
             </ul>
         </td>
        <td><?php echo date('Y',strtotime($data['tgl_acc'])); ?></td>
       
    </tr>                 
<?php } ?>

</tbody>                
</table>
                                    <br>
<table width="100%">
<tr>
<td align="right" colspan="6" rowspan="" headers="">
<p>Bandung, <?php echo date (" d F Y") ?>  <br> <br>
Ketua Jurusan </p> <br> <br> <br>
<p><strong><u>Yaya Suharya, S.kom., M.T.</u></strong> <br> <strong>NIDN. 0407047706</strong> </p>
</td>
</tr>
</table>
<script>
    window.print();
</script>

</body>
</html>


