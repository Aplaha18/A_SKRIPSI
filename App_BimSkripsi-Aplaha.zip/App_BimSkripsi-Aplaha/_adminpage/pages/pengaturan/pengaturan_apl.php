<?php
 $result = mysqli_query($con,"SELECT * FROM apl WHERE aktif='Y' ");
foreach ($result as $d)

$info = mysqli_query($con,"SELECT * FROM tb_info ORDER BY info_id DESC LIMIT 1 ");
foreach ($info as $di)


  ?>
<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4><i class="fa fa-cogs"></i> Pengaturan Sistem</h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-6">
              <form action="" method="POST" accept-charset="utf-8">
              <labe>Title Website</label>
                <input type="text" name="title" class="form-control" value="<?php echo $d['title'] ?>">
              <labe>Brand</label>
              <div class="input-group">
                <span class="input-group-addon" id="basic-addon1">
                  <i class="fa fa-graduation-cap" aria-hidden="true"></i></span>
                <input type="text" name="brand" class="form-control" value="<?php echo $d['brand'] ?>" aria-describedby="basic-addon1" value="">
              </div>
              <labe>Text Banner</label>
                <input type="text" name="banner" class="form-control" value="<?php echo $d['bannerText'] ?>">
              <labe>Tag Banner</label>
                <textarea name="tag" rows="3" class="form-control"><?php echo $d['bannerTag'] ?></textarea>
              <labe>Text Tengah</label>
                <input type="text" name="big" class="form-control" value="<?php echo $d['txtBig'] ?>">
              <labe>Text Keterangan</label>
                <textarea name="small" rows="3" class="form-control"><?php echo $d['txtSmall'] ?></textarea>
              <labe>Copy Right</label>
                <input type="text" name="copy" class="form-control" value="<?php echo $d['copy'] ?>">
              <labe>Footer</label>
                <input type="text" name="footer" class="form-control" value="<?php echo $d['footer'] ?>">
              <hr>
              <button type="submit" name="Update" class="btn btn-info"><i class="fa fa-pencil"></i> Update</button>
               <a href="javascript:history.back()" class="btn btn-danger"><i class="fa fa-times"></i> Batal</a>
               </form>
               <?php 
               if (isset($_POST['Update'])) {
                  echo "<pre>";
                  print_r ($_POST);
                  echo "</pre>";

                        $title = $_POST['title'];
                        $brand = $_POST['brand'];
                        $banner = $_POST['banner'];
                        $tag = $_POST['tag'];
                        $big = $_POST['big'];
                        $small = $_POST['small'];
                        $copy = $_POST['copy'];
                        $footer = $_POST['footer'];

                        mysqli_query($con,"UPDATE apl SET title='$title',brand='$brand',bannerText='$banner',bannerTag='$tag',txtBig='$big',txtSmall='$small',copy='$copy',footer='$footer' WHERE id=1 ");
                            ?>
            <script type='text/javascript'>
              setTimeout(function () {
              swal({
              title: 'DIUBAH',
              text:  'Berhasil Mengubah Data !  ',
              type: 'success',
              timer: 3000,
              showConfirmButton: true
              });     
              },10);  
              window.setTimeout(function(){ 
              window.location.replace('?page=set');
              } ,3000);   
            </script>
             <?php


               }

                ?>

             </div>
   <div class="col-md-6">
     <h4><b><i class="fa fa-file-o"></i> Syarat pengajuan judul skripsi</b></h4>
        <form action="" method="POST" accept-charset="utf-8">
          <textarea id="ckedtor1" name="isi">
            <?php echo $di['isi']; ?>
        </textarea>
       <div class="form-group">
        <label> Status Aktif</label>
           <select name="aktif" class="form-control" style="width: 250px;background-color: #212121;color: #fff">
          <option value="Y">Aktif</option>
          <option value="N">Tidak</option>
        </select>       
       </div>
       <br>
       <div class="form-group">
        <button type="submit" name="publish" class="btn btn-info"><i class="fa fa-pencil"></i> Publish</button>
       </div>
        </form>
        <?php 
        if (isset($_POST['publish'])) {
         

             $isi= $_POST['isi'];    
             $aktif= $_POST['aktif'];
             $date= date('Y-m-d');
             mysqli_query($con,"UPDATE tb_info SET isi='$isi',tgl_info='$date', aktif='$aktif' WHERE info_id=1 ");
             ?>
            <script type='text/javascript'>
              setTimeout(function () {
              swal({
              title: 'PUBLISH SUKSES',
              text:  'Berhasil Mengubah Data !  ',
              type: 'success',
              timer: 3000,
              showConfirmButton: true
              });     
              },10);  
              window.setTimeout(function(){ 
              window.location.replace('?page=set');
              } ,3000);   
            </script>
             <?php


        }
         ?>
    </div>
</div>
</div>
</div>
</div>
</div>
