
 <?php 
$idmhs = $_GET['idmhs'];
$id = $_GET['id'];
$status = $_GET['status'];
if ($status=='Disetujui') {
	$sql1=mysqli_query($con,"UPDATE tb_pengajuanjudul SET disetujui_kajur='Tidaksetuju' WHERE id_pengajuan='$id' ");
		if ($sql1 || $sql2) {
		echo "<script>
		window.location='?page=pengajuan&mhs=$idmhs';
		</script>";

		}
}


 ?>