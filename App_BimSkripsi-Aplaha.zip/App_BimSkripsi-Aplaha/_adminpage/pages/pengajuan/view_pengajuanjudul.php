<?php 
$mhs= $_GET['mhs'];
$qry = mysqli_query($con,"SELECT * FROM tb_mhs WHERE id_mhs='$mhs' ");
$row = mysqli_fetch_array($qry);
 ?>
<div class="row">
<div class="col-sm-12 col-xs-12">
    <a href="javascript:history.back()" class="btn btn-danger btn-xs"> <i class="fa fa-chevron-left"></i> Kembali </a>
      <div class="card">
        <div class="card-header" style="background-color:#FAFAFA;">
          <div class="col-lg-6 col-md-6 col-xs-12">
           <center>
             <h4> <b>Mahasiswa</b></h4>
             <hr>
           </center>
           <div class="table-responsive">
            <table class="table-condensed" width="100%" style="font-weight: bold;color: #212121;">
              <tr>
                <td rowspan="4">
                  <img class="img-thumbnail" src="../assets/img-mhs/<?php echo $row['fotomhs'] ?>" width="100" height="130" style="border-radius: 7px;border: 2px solid #FAFAFA;">
                </td>
              </tr>
               <tr>
                <td>Nama Mahasiswa</td>
                <td>:</td>
                <td><?php echo $row['nama'] ?></td>
              </tr>
              <tr>
                <td>NIM</td>
                <td>:</td>
                <td><?php echo $row['nim'] ?></td>
              </tr>
              <tr>
                <td>Tahun Angkatan</td>
                <td>:</td>
                <td><?php echo $row['tahun_angkatan'] ?></td>
              </tr>
          </table> 
          </div>           
          </div>
          <div class="col-lg-6 col-md-6 col-xs-12">
            <?php 
$mhs= $_GET['mhs'];
$qry = mysqli_query($con,"SELECT * FROM tb_pa
  INNER JOIN tb_dsn ON tb_pa.id_dsn=tb_dsn.id_dsn
 WHERE tb_pa.id_mhs='$mhs' ");
$row = mysqli_fetch_array($qry);
 ?>
            <center>
             <h4> <b>Dosen Wali</b></h4>
             <hr>
           </center>
           <div class="table-responsive">
            <table class="table-condensed" width="100%" style="font-weight: bold;color: #212121;">
              <tr>
                <td rowspan="4">
                  <img class="img-thumbnail" src="../assets/images/<?php echo $row['foto'] ?>" width="100" height="130" style="border-radius: 7px;border: 2px solid #FAFAFA;">
                </td>
              </tr>
               <tr>
                <td>Nama Dosen</td>
                <td>:</td>
                <td><?php echo $row['nama_dosen'] ?></td>
              </tr>
              <tr>
                <td>NIK</td>
                <td>:</td>
                <td><?php echo $row['nip'] ?></td>
              </tr>
              <tr>
                <td>Jabatan</td>
                <td>:</td>
                <td><?php echo $row['jabatan'] ?></td>
              </tr>
          </table> 
          </div>           
          </div>

        </div>
        <div class="card-body">
            <div class="section-body">
              <div class="step">
    <ul class="nav nav-tabs nav-justified" role="tablist">
    
        <li role="step" class="active">
            <a href="#step2" role="tab" id="step2-tab" data-toggle="tab" aria-controls="profile">
                <div class="icon fa fa-file-o"></div>
                <div class="heading">
                    <div class="title">Daftar Judul Yang Diajukan Mahasiswa</div>
                    <div class="description">Daftar Judul Yang Diajukan</div>
                </div>
            </a>
        </li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
     
        <div role="tabpanel" class="tab-pane active" id="step2">
         <!--    <b>Step2</b>
            <hr> -->
            <div class="table-responsive">
              <table class="table table-condensed table-striped">
                      <thead>
                        <tr>
                          <th>No.</th>
                          <th>Tanggal Pengajuan</th>
                          <th>Judul Proposal</th>
                          <th>Rekomendasi Dosen Wali</th>
                          <th>Disetujui Kaprodi</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $no=1; 
                        $query= mysqli_query($con,"SELECT * FROM tb_pengajuanjudul WHERE id_mhs='$mhs' ");
                        while ($row= mysqli_fetch_array($query)) { ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo date('d F Y',strtotime($row['tgl_pengajuan'])); ?></td>
                          <td><?php echo $row['judul_proposal']; ?></td>
                          <td><?php
                          if ($row['status_proposal']=='Rekomendasi') {
                            echo "<b class='label label-success'>Rekomendasi</b>";
                          }elseif ($row['status_proposal']=='Ditolak') {
                            echo "<b class='label label-danger'>Ditolak</b>";
                          }else{
                             echo "<b class='label label-warning'>".$row['status_proposal']."</b>";
                          }
                          
                            ?></td>
                                <td><?php
                          if ($row['disetujui_kajur']=='Disetujui') {
                            echo "<b class='label label-success'>Disetujui</b>";
                          }elseif ($row['disetujui_kajur']=='Tidaksetuju') {
                            echo "<b class='label label-danger'>Tidaksetuju</b>";
                          }else{
                             echo "<b class='label label-danger'>".$row['disetujui_kajur']."</b>";
                          }
                          
                            ?></td>
                          <td>
                            <?php
                          if ($row['disetujui_kajur']=='Disetujui') {
                            ?>
                            <a href="?page=pengajuan&act=setpbb&id_mhs=<?php echo $row['id_mhs'];?>&idjudul=<?php echo $row['id_pengajuan']; ?> " class="btn btn-success btn-xs">Tentukan Pembimbing >></a>
                            <a href="?page=pengajuan&act=batal&idmhs=<?php echo $row['id_mhs'];?>&id=<?php echo $row['id_pengajuan'];?>&status=<?php echo $row['disetujui_kajur']; ?>" class="btn btn-danger btn-xs">Batal</a>
                            <?php
                          }else{
                             ?>
                             <a data-toggle="modal" data-target="#<?php echo $row['id_pengajuan']; ?>" class="btn btn-primary btn-xs">Lihat >></a>
    <div class="modal fade bs-example-modal-lg" id="<?php echo $row['id_pengajuan']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><?php echo $row['judul_proposal']; ?></h4>
          </div>
          <form action="" method="POST" accept-charset="utf-8">
          <div class="modal-body">
            <b>POKOK MASALAH : </b>
            <p>
              <?php echo $row['masalah']; ?>
              <input type="hidden" name="status" value="Disetujui">
              <input type="hidden" name="statust" value="Tidaksetuju">
              <input type="hidden" name="id" value="<?php echo $row['id_pengajuan']; ?>">
            </p>
          </div>
          <div class="modal-footer">
            <center>
            <!--   <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button> -->
              <button type="submit" name="tidak" class="btn btn-danger"> <i class="fa fa-times"></i> TIDAK SETUJU</button>
            <button type="submit" name="rekomendasi" class="btn btn-primary"> <i class="fa fa-check"></i> SETUJU & TENTUKAN DOSEN PEMBIMBING !</button>
           <!--   <a href="?page=pengajuan&act=setuju&status=Disetujui&mhs=<?php echo $row['id_pengajuan']; ?> " class="btn btn-sm btn-info"> <i class="fa fa-check"></i> Setujui & Tentukan Dosen Pembimbing !</a> -->
            </center>
          </div>
          </form>
          <?php 
          if (isset($_POST['rekomendasi'])) {

            $id = $_POST['id'];
            $status = $_POST['status'];
            $today = date('Y-m-d');
            mysqli_query($con,"UPDATE tb_pengajuanjudul SET disetujui_kajur='$status',tgl_acc='$today' WHERE id_pengajuan='$id' ");

            echo "
            <script type='text/javascript'>
            setTimeout(function () {
            swal({
            title: 'REKOMENDASI SUKSES',
            text:  'Informasi ini Akan Disampaikan Ke KAPRODI ..',
            type: 'success',
            timer: 3000,
            showConfirmButton: true
            });     
            },10);  
            window.setTimeout(function(){ 
            window.location.replace('?page=pengajuan&mhs=$mhs');
            } ,3000);   
            </script>";

            
          }elseif (isset($_POST['tidak'])) {
            $id = $_POST['id'];
            $statust = $_POST['statust'];
            $today = date('Y-m-d');
            mysqli_query($con,"UPDATE tb_pengajuanjudul SET disetujui_kajur='$statust',tgl_acc='$today' WHERE id_pengajuan='$id' ");

            echo "
            <script type='text/javascript'>
            setTimeout(function () {
            swal({
            title: 'SUKSES',
            text:  'Informasi ini Akan Disampaikan Ke Mahasiswa ..',
            type: 'success',
            timer: 3000,
            showConfirmButton: true
            });     
            },10);  
            window.setTimeout(function(){ 
            window.location.replace('?page=pengajuan&mhs=$mhs');
            } ,3000);   
            </script>";

            
          }
           ?>

        </div>
      </div>
    </div>
                             <?php
                          }
                          
                            ?>

                            

                          </td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>
                      </div>
        </div>
    </div>
</div>
            </div>
          </div>
        </div>
      </div>
 </div>

