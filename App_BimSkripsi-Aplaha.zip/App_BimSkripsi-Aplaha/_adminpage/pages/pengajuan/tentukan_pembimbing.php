<?php 
$id_mhs = $_GET['id_mhs'];
$idjudul = $_GET['idjudul'];

$sqlu=mysqli_query($con, "SELECT * FROM tb_pengajuanjudul WHERE id_pengajuan='$idjudul' ");
$data=mysqli_fetch_array($sqlu);

 ?>

 <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
         <h4><b>FORM PENENTUAN DOSEN PEMBIMBING</b></h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
            	<center>
            	<form action="" method="POST" accept-charset="utf-8">
						<label>Ketikkan : NIK , Nama Dosen</label>
						<select name="iddsn" class="select2" required>
						<option>........... Cari Dosen ...........</option>
						<?php
						$sql=mysqli_query($con, "SELECT * FROM tb_dsn ORDER BY id_dsn ASC");
						while($g=mysqli_fetch_array($sql)){
						echo "<option value='$g[id_dsn]'>$g[nip]-$g[nama_dosen]</option>";
						}
						?>
						</select>
						<input type="hidden" name="idmhs" value="<?php echo $data['id_mhs'] ?>">
						<input type="hidden" name="idjudul" value="<?php echo $data['id_pengajuan'] ?>">
						<?php 
						$pb1=mysqli_query($con, "SELECT * FROM tb_pembone
						INNER JOIN tb_dsn ON tb_pembone.id_dsn=tb_dsn.id_dsn
						WHERE tb_pembone.id_mhs='$data[id_mhs]' ");
						$pemb=mysqli_fetch_array($pb1);
						?>

						<?php 
						if (empty($pemb['id_mhs'])) {
							?>
							
							<button type="submit" name="pem1" class="btn btn-primary"><i class="fa fa-user"></i> PILIH SEBAGAI PEMBIMBING I</button>	
							<?php
						}

						 ?>
							<?php 
							$pb2=mysqli_query($con, "SELECT * FROM tb_pembtwo
							INNER JOIN tb_dsn ON tb_pembtwo.id_dsn=tb_dsn.id_dsn
							WHERE tb_pembtwo.id_mhs='$data[id_mhs]' ");
							$pemb2=mysqli_fetch_array($pb2);
							?>
							<?php 
						if (empty($pemb2['id_mhs'])) {
							?>
							<button type="submit" name="pem2" class="btn btn-warning"><i class="fa fa-users"></i> PILIH SEBAGAI PEMBIMBING II</button>
							<?php
						}else{
							?>
							<center>
								<a href="index.php" class="btn btn-success"><i class="fa fa-check"></i> Selesai</a>
							</center>
							<?php
						}

						 ?>
				</form> 
					<?php 
					if (isset($_POST['pem1'])) {
					$idmhs = $_POST['idmhs'];
					$iddsn = $_POST['iddsn'];
					$idjudul = $_POST['idjudul'];
					$tgl =date('Y-m-d');
					mysqli_query($con,"INSERT INTO tb_pembone VALUES (NULL,'$idmhs','$iddsn','$idjudul','$tgl','Belum Konfirmasi')");
					echo "
						<script type='text/javascript'>
						setTimeout(function () {
						swal({
						title: 'PEMBIMBING I TELAH DIPILH',
						text:  '',
						type: 'success',
						timer: 3000,
						showConfirmButton: true
						});     
						},10);  
						window.setTimeout(function(){ 
						window.location.replace('?page=pengajuan&act=setpbb&id_mhs=$data[id_mhs]&idjudul=$data[id_pengajuan]');
						} ,3000);   
						</script>
					";

					}elseif (isset($_POST['pem2'])) {
					$idmhs = $_POST['idmhs'];
					$iddsn = $_POST['iddsn'];
					$idjudul = $_POST['idjudul'];
					$tgl =date('Y-m-d');
					mysqli_query($con,"INSERT INTO tb_pembtwo VALUES (NULL,'$idmhs','$iddsn','$idjudul','$tgl','Belum Konfirmasi')");
					echo "
						<script type='text/javascript'>
						setTimeout(function () {
						swal({
						title: 'PEMBIMBING II TELAH DIPILH',
						text:  '',
						type: 'success',
						timer: 3000,
						showConfirmButton: true
						});     
						},10);  
						window.setTimeout(function(){ 
						window.location.replace('?page=pengajuan&act=setpbb&id_mhs=$data[id_mhs]&idjudul=$data[id_pengajuan]');
						} ,3000);   
						</script>
					";
					}

					?>
				</center>
				<br>
				<br>
				
            </div>

              <div class="col-md-12">
            	<center>
            		<h4>Judul Skripsi</h4>
            		<h4>" <b style="color: #E91E63;"><?php echo $data['judul_proposal']; ?></b> "</h4></center>

            		<div class="row">
            			<div class="col-md-6">
            				<?php 
            				if ($pemb['ket_one']=='Belum Konfir' || $pemb['ket_one']=='Bersedia') {
            					

            					?>
            					<table class="table" width="100%" style="font-weight: bold;">
					  <tr>
					  	<td align="center"><b>PEMBIMBING I</b> </td>
					    <td>
					    	<?php
					    	if (empty($pemb['foto'])) {					    		
					    	}else{
					    		?>
					    		<img class="img-thumbnail" src="../assets/images/<?php echo $pemb['foto'] ?>" width="80" height="80">
					    		<?php
					    	}
					    	?>
					    	
					    </td>
					  </tr>					
					  <tr>
					    <td>Nama Dosen </td>
					    <td><?php echo $pemb['nama_dosen']; ?></td>
					  </tr>
					  <tr>
					    <td>NIK</td>
					    <td><?php echo $pemb['nip']; ?></td>
					  </tr>
					   <tr>
					    <td>Persetujuan</td>
					    <td>
							<?php
							if ($pemb['ket_one']=='Belum Konfir') {
								echo "<b class='label label-danger'style='font-size:18px;'>Belum Konfirmasi</b>";
							}else{
								echo "<b class='label label-success'style='font-size:18px;'>Bersedia</b>";
							}
							?>					      	
					      </td>
					  </tr>
					</table>
            					<?php




            				}else{

            						?>
									<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong>Pembimbing I</strong> Belum ditentukan
									</div>
            					<?php
            					
            				}

            				 ?>
            		
            	</div>

            		<div class="col-md-6">
            			<!-- PEMB II -->
            				<?php
            				if ($pemb2['ket_two']=='Belum Konfir' || $pemb2['ket_two']=='Bersedia') {
            					// echo "<b class='label label-danger'style='font-size:18px;'>Belum Ada Pembimbing</b>";

            					?>

            					<table class="table" width="100%" style="font-weight: bold;">
					  <tr>
					  	<td align="center"><b>PEMBIMBING II</b></td>
					    <td>
					    		<?php
					    	if (empty($pemb2['foto'])) {
					    		
					    	}else{
					    		?>
					    		<img class="img-thumbnail" src="../assets/images/<?php echo $pemb2['foto'] ?>" width="80" height="80">
					    		<?php
					    	}
					    	?>
					    	</td>
					  </tr>			
					  <tr>
					    <td>Nama Dosen </td>
					    <td><?php echo $pemb2['nama_dosen']; ?></td>
					  </tr>
					  <tr>
					    <td>NIK</td>
					    <td><?php echo $pemb2['nip']; ?></td>
					  </tr>
					   <tr>
					    <td>Persetujuan</td>
					    <td>
						<?php
						if ($pemb2['ket_two']=='Belum Konfir') {
						echo "<b class='label label-danger'style='font-size:18px;'>Belum Konfirmasi</b>";
						}elseif ($pemb2['ket_two']=='Bersedia') 
						echo "<b class='label label-success'style='font-size:18px;'>Bersedia</b>";
						else{
						echo "<b class='label label-danger'style='font-size:18px;'>Belum Ditentukan</b>";
						}
						?>					    		
					    	</td>
					  </tr>
					</table>

            					<?php

            				}else{
            					?>
									<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong>Pembimbing II</strong> Belum ditentukan
									</div>
            					<?php
            					

            				}
						?>

     
            		
            				
            		</div>
            			
            		</div>
            </div>
        </div>
    </div>
</div>
</div>
</div>




