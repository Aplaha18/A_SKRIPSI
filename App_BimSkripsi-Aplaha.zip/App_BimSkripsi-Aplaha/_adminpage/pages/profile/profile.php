<div class="row">
	<div class="col-md-4 col-md-offset-3">
		<div class="card">
	        <div class="card-header">
	         	PROFIL ADMIN
	        </div>
	        <div class="card-body">
	        	<form action="" method="POST" enctype="multipart/form-data">
	        		<div class="form-group">
	        			<label> Username</label>
	        			<input type="hidden" name="id" value="<?php echo $data['id'] ?>" class="form-control">
	        			<input type="text" name="username" value="<?php echo $data['username'] ?>" class="form-control">
	        		</div>
	        		<div class="form-group">
	        			<label> Password Baru</label>
	        			<input type="text" name="password" placeholder="Password Baru .." class="form-control">
	        		</div>
	        		<div class="form-group">
	        			<label> Nama Admin</label>
	        			<input type="text" name="nama" value="<?php echo $data['nama_admin'] ?>" class="form-control">
	        		</div>
	        		<div class="form-group">
	        			<label> Foto</label>
	        			<input type="file" name="foto" class="form-control">
	        		</div>
	        		<div class="form-group">
	        			<button type="submit" name="edit" class="btn btn-success"><i class="fa fa-pencil"></i> Ubah Profile </button>
	        			<a href="javascript:history.back()" class="btn btn-danger"><i class="fa fa-times"></i> Batal </a>
	        		</div>
	        	</form>
	        	<?php 
	        	if (isset($_POST['edit'])) {
	        		$id = $_POST['id'];
	        		$user = $_POST['username'];
	        		$pass = md5($_POST['password']);
	        		$nama = $_POST['nama'];

	        		$gambar = @$_FILES['foto']['name'];
				if (!empty($gambar)) {
				move_uploaded_file($_FILES['foto']['tmp_name'],"../assets/images/$gambar");
				$ganti = mysqli_query($con,"UPDATE tb_admin SET img='$gambar' WHERE id='$id' ");
				}

	        		mysqli_query($con,"UPDATE tb_admin SET username='$user',password='$pass',nama_admin='$nama' WHERE id='$id' ") or die(mysqli_error($con));
	        		echo "<script>
	        		alert('Data Sudah di Ubah !!');
	        		window.location='index.php';
	        		</script>";
	        	}

	        	 ?>

	        </div>
        </div>			
	</div>	
</div>